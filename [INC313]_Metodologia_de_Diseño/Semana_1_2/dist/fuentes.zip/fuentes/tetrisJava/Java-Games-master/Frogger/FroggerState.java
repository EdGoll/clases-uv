public enum FroggerState
{
	MOVING, HIT, WON;
}