public class JoinGame
{
	public static void main(String[] args)
	{
		(new Pong(false)).makeTestWindow();
	}
}