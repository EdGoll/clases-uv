public class MakeGame
{
	public static void main(String[] args)
	{
		(new Pong(true)).makeFullScreenWindow();
	}
}