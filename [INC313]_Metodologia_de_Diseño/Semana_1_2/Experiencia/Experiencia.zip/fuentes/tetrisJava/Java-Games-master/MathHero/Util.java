public class Util
{
	public static final int MAX_R = 250;
	public static final int PLAYER_RADIUS = 10;
	public static final int ARROW_LENGTH = 5;
	public static final double ARROW_SPEED = 7;
	public static final double ENEMY_FREQUENCY = .01;
}