import java.awt.Color;


public class Long extends TetrisBlock{	
	public Long(){
		//llama a constructo de padre con par�metros conocidos
		super(new boolean[][]{{true, true, true, true}}, Color.RED);		
	}

}
