public enum CrapsState
{
	START, ROLLING, WON, LOST;
}