
public class ChoroPortenho {
	
	public String golpear(){
		return("ALETAZO MARINO!!!");
	}
	
	public String patear(){
		return("PATADA DE LA JAIBAAAAA!!!");
	}

	public String saltar(){
		return("PIQUERO INFERNAAAAAL!!!");
	}
	
	public String LanzarPoder(){
		return("SHIAAAAAAAAAAAA!!!");
	}
	
	
}
