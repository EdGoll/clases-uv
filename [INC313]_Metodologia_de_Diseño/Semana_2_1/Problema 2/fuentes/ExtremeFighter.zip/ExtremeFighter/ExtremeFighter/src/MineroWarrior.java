
public class MineroWarrior {
	public String golpear(){
		return("PU�O DEL PIRQUINEROOOO!!!");
	}
	
	public String patear(){
		return("PATADA DEL CATEADOOOOOOR!!!");
	}

	public String saltar(){
		return("SALTO EXPLOSIVOOOOO!!!");
	}
	
	public String LanzarPoder(){
		return("EXPLOSION A TAJO ABIERTOOOOOO!!!");
	}
	

}
