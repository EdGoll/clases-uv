
public class PanchoDelSur extends Luchador {
	public PanchoDelSur(){
		this.nombre="PANCHO DEL SUR!!!!";		
	}
	
	public String golpear(){
		return("PU�O DEL HOCICON!!!");
	}
	
	public String patear(){
		return("PATADA SATELITEEE!!!");
	}

	public String saltar(){
		return("JOJOI!!!");
	}
	
	public String atacarRapido(){
		return null;
	}
		
	public String agarrar(){
		return("QUE SE LE MOJA LA CANOAAA!!!");
	}
	
}
