
public class GorrionDeConchali extends Luchador{
	public GorrionDeConchali(){
		this.nombre="GORRION DE CONCHALI!!!!";		
	}
	
	public String golpear(){
		return("PU�O CEBOLLERO!!!");
	}
	
	public String patear(){
		return("PATADA LACRIMOGENA!!!");
	}

	public String saltar(){
		return("PIQUERO ROMANTICO!!!");
	}
	
	public String atacarRapido(){
		return("LAGRIMA EN LA GARRGANTAAAA!!!");
	}

	public String agarrar(){
		return null;
	}
	
}
