
public class MineroWarrior extends Luchador implements ILanzadorPoderes{
	public MineroWarrior(){
		this.nombre="MINERO WARRIORRR!!!";
	}
	public String golpear(){
		return("PU�O DEL PIRQUINEROOOO!!!");
	}
	
	public String patear(){
		return("PATADA DEL CATEADOOOOOOR!!!");
	}

	public String saltar(){
		return("SALTO EXPLOSIVOOOOO!!!");
	}
	
	public String lanzarPoder(){
		return("EXPLOSION A TAJO ABIERTOOOOOO!!!");
	}
	
	public String atacarRapido() {
		return null;
	}
	public String agarrar(){
		return null;
	}

}
