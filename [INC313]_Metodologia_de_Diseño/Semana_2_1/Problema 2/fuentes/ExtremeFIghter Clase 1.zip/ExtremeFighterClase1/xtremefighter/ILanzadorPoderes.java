
public interface ILanzadorPoderes {
	public String lanzarPoder(); 
}
