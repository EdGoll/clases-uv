
public class ChoroPortenho extends Luchador implements ILanzadorPoderes{
	public ChoroPortenho(){
		this.nombre="CHORO PORTENHO!!!!";		
	}
	
	public String golpear(){
		return("ALETAZO MARINO!!!");
	}
	
	public String patear(){
		return("PATADA DE LA JAIBAAAAA!!!");
	}

	public String saltar(){
		return("PIQUERO INFERNAAAAAL!!!");
	}
	
	public String lanzarPoder(){
		return("SHIAAAAAAAAAAAA!!!");
	}

	public String atacarRapido() {
		return null;
	}
	
	public String agarrar(){
		return null;
	}
	
}
