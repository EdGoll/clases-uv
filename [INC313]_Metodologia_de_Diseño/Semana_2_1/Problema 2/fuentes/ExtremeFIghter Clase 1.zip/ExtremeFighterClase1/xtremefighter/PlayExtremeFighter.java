
public class PlayExtremeFighter {
	public static void main(String[] args){
	     new FightEngine();
	}
}
