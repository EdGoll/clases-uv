import java.util.Scanner;

public class FightEngine {
	public FightEngine(){
		String luchadorPlayer1;
		String accionLuchadorIn;
		int accionLuchador;
		String opcionChoroPortenho = new String("1");
		String opcionMineroWarrior = new String("2");
		
	    System.out.println("Empieza el juego!!!");
		System.out.println("Selecciona tu luchador (1 o 2): 1-Choro Portenho 2-Minero Warrior ");
		
		Scanner seleccion = new Scanner(System.in);
		
		luchadorPlayer1 = seleccion.nextLine();
	
		System.out.println(luchadorPlayer1);
		
		Luchador player1= null;
		
		if (luchadorPlayer1.equals(opcionChoroPortenho))
			player1 = new ChoroPortenho();
		if (luchadorPlayer1.equals(opcionMineroWarrior))
			player1 = new MineroWarrior();
	
		System.out.println(player1.nombre + " inicia a batalla!");

				System.out.println("Ingresa tu accion! :1-Golpe 2-Patada 3-Salto 4-LANZAR PODER");

				accionLuchadorIn =seleccion.nextLine();
				accionLuchador = Integer.parseInt(accionLuchadorIn);
				
				switch(accionLuchador) {
					case 1: System.out.println(player1.golpear());
							break;
					case 2: System.out.println(player1.patear());
							break;
					case 3: System.out.println(player1.saltar());
							break;
					case 4: System.out.println(player1.lanzarPoder());
							break;
					case 5: System.out.println(player1.agarrar());
					break;
					
				}
		
				
		System.out.println("FIN DEL JUEGO. 2...");

	}

}
