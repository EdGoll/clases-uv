
public abstract class Luchador {
	public String nombre;
	public abstract String golpear();
	public abstract String patear();
	public abstract String saltar();
	public abstract String atacarRapido();
	public abstract String agarrar();
}
