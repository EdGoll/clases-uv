package luchadores;

public class GorrionDeConchali extends Luchador{
	public GorrionDeConchali(){
		this.nombre="GORRION DE CONCHALI!!!!";		
	}
	
	public String golpear(){
		return("PU�O CEBOLLERO!!!");
	}
	
	public String patear(){
		return("PATADA LACRIMOGENA!!!");
	}

	public String saltar(){
		return("PIQUERO ROMANTICO!!!");
	}
	

}
