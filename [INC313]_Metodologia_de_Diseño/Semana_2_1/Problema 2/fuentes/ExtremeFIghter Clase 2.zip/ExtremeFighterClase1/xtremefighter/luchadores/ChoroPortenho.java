package luchadores;

public class ChoroPortenho extends Luchador{
	public ChoroPortenho(){
		this.nombre="CHORO PORTENHO!!!!";		
	}
	
	public String golpear(){
		return("ALETAZO MARINO!!!");
	}
	
	public String patear(){
		return("PATADA DE LA JAIBAAAAA!!!");
	}

	public String saltar(){
		return("PIQUERO INFERNAAAAAL!!!");
	}
	
	

	
}
