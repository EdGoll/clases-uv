package luchadores;

public class PanchoDelSur extends Luchador{
	public PanchoDelSur(){
		this.nombre="PANCHO DEL SUR!!!!";		
	}
	
	public String golpear(){
		return("PU�O DEL HOCICON!!!");
	}
	
	public String patear(){
		return("PATADA SATELITEEE!!!");
	}

	public String saltar(){
		return("JOJOI!!!");
	}
}
