package poderes;

public class AtacadorRapido extends MovimientoEspecial{
	public String ejecutarMovimientoEspecial(){
		return "RAPIDO Y FURIOSOOOOOOO!!!";
	}
}
