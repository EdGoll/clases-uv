package poderes;

public class LanzaPoderes extends MovimientoEspecial{
	public String ejecutarMovimientoEspecial(){
		return "SHI������HHH!!!";
	}
	
}
