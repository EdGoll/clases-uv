package poderes;

public abstract class MovimientoEspecial {
	public abstract String ejecutarMovimientoEspecial();
}
