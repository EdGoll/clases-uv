package poderes;

public class Agarrador extends MovimientoEspecial{
	public String ejecutarMovimientoEspecial(){
		return "SUPEEER AAGARRRON";
	}
}
