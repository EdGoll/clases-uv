

public class Suerte {
	
	public int getNumero(int rango) {
		return (int)(Math.random()*rango);
	}
}
