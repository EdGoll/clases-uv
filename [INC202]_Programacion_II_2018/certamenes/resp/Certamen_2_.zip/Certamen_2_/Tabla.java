import java.awt.*;
import javax.swing.*;

public class Tabla extends JFrame {
    
    public Tabla(){
    super("Juego - Certamen 2");
    }
}
