
	public class Personajes {
	String nombre="";
	int energia=0;
	int danio=0;
	public Personajes(String nombre, int energia) {
		this.nombre=nombre;
		this.energia=energia;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEnergia() {
		return energia;
	}
	public void setEnergia(int energia) {
		this.energia = energia;
	}
	
	public void alimentarse(int nEnergia) {
		energia = energia + nEnergia;		
	}
	public void consumirEnergia(int gEnergia) {
		energia= energia - gEnergia;
	}

}
