
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * @author andreszapata
 */
public class Principal {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(new JFrame(), "preparate para jugar");
        Gato g = new Gato();
    }
}
