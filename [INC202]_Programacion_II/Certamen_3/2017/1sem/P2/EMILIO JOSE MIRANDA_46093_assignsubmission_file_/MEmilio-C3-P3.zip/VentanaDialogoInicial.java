import javax.swing.*;

public class VentanaDialogoInicial{
    
    public VentanaDialogoInicial(){
    JOptionPane.showMessageDialog(null, "¡Que comience el juego!", "¡Información!", JOptionPane.INFORMATION_MESSAGE);
    }
    
}
