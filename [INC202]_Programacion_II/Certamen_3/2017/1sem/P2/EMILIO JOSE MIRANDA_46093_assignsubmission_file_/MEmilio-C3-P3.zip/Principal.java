public class Principal{
   
    public static void main(String[] args){
        VentanaDialogoInicial vdi=new VentanaDialogoInicial();
        Gato gato=new Gato();
    }
    
}
