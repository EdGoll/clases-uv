package certamen2;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
	public static void Main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String nombreArchivo = "movies.csv";
		List<String> lineas = FuenteDeDatos.leerArchivo(nombreArchivo);
		Movie mov;
		StringTokenizer st;
        
		System.out.println("Películas de género 'Adventure': ");
		for (String linea : lineas) {
			st = new StringTokenizer(linea, ";");
			if (st.hasMoreTokens()) {
				mov = new Movie();
				mov.setMovieId(st.nextToken());
				mov.setTitle(st.nextToken());
				mov.setGenre(st.nextToken());

				StringTokenizer st2 = new StringTokenizer(mov.getGenre(), "|");

				while (st2.hasMoreElements()) {
					if (st2.nextElement().equals("Adventure")) {
						System.out.println(mov.getTitle());
					}
				}
			}
		}
		System.out.println("----------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------");
        
		System.out.println("Películas de género 'Thriller' y 'Crime': ");
		for (String linea : lineas) {
			st = new StringTokenizer(linea, ";");
			if (st.hasMoreTokens()) {
				mov = new Movie();
				mov.setMovieId(st.nextToken());
				mov.setTitle(st.nextToken());
				mov.setGenre(st.nextToken());

				StringTokenizer st2 = new StringTokenizer(mov.getGenre(), "|");

				while (st2.hasMoreElements()) {
					if (st2.nextElement().equals("Crime")) {
						while (st2.hasMoreElements()) {
							if (st2.nextElement().equals("Thriller")) {
								System.out.println(mov.getTitle());
							}
						}
					}
				}
			}
		}
		System.out.println("----------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------");
        
		System.out.println("Indique un año para búsqueda de peliculas: ");
		String userInput = sc.nextLine();
		for (String linea : lineas) {
			st = new StringTokenizer(linea, ";");
			if (st.hasMoreTokens()) {
				mov = new Movie();
				mov.setMovieId(st.nextToken());
				mov.setTitle(st.nextToken());
				mov.setGenre(st.nextToken());

				StringTokenizer st2 = new StringTokenizer(mov.getTitle(), "(");

				while (st2.hasMoreElements()) {
					if (st2.nextElement().equals(userInput + ")")) {
						System.out.println(mov.getTitle());
					}
				}
			}
		}
		System.out.println("----------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------");
        
		System.out.println("Ingrese un rating para buscar peliculas: ");
		String ratingUser = sc.nextLine();
		String nombreArchivo2 = "ratings.csv";
		List<String> lineasR = FuenteDeDatos.leerArchivo(nombreArchivo2);
		Rating rating;
		for (String lineaR : lineasR) {
			if (lineaR.equals("userId;movieId;rating"))
				continue;
			st = new StringTokenizer(lineaR, ";");
			if (st.hasMoreTokens()) {
				rating = new Rating();
				rating.setUserId(st.nextToken());
				rating.setMovieId(st.nextToken());
				rating.setRating(st.nextToken());

				float uRating = Float.parseFloat(ratingUser);
				float mRating = Float.parseFloat(rating.getRating());

				if (mRating >= uRating) {
			
					for (String linea : lineas) {
						if (linea.contains(rating.getMovieId())){
							st = new StringTokenizer(linea, ";");
							if (st.hasMoreTokens()) {
								mov = new Movie();
								mov.setMovieId(st.nextToken());
								mov.setTitle(st.nextToken());
								mov.setGenre(st.nextToken());
								System.out.println(mov.getTitle());
								break;
							}
						}
						
					}
				}

			}
		}
		System.out.println("----------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------");
        
		System.out.println("Ingrese un rating para buscar peliculas 'Comedy': ");
		String inputUser = sc.nextLine();
		Rating rating2;
			for (String lineaR : lineasR) {
			if (lineaR.equals("userId;movieId;rating"))
				continue;
			st = new StringTokenizer(lineaR, ";");
			if (st.hasMoreTokens()) {
				rating2 = new Rating();
				rating2.setUserId(st.nextToken());
				rating2.setMovieId(st.nextToken());
				rating2.setRating(st.nextToken());

				float uRating = Float.parseFloat(inputUser);
				float mRating = Float.parseFloat(rating2.getRating());

				if (mRating >= uRating) {
					for (String linea : lineas) {
						if (linea.contains(rating2.getMovieId()) && linea.contains("Comedy")){
							st = new StringTokenizer(linea, ";");
							if (st.hasMoreTokens()) {
								mov = new Movie();
								mov.setMovieId(st.nextToken());
								mov.setTitle(st.nextToken());
								mov.setGenre(st.nextToken());
								System.out.println(mov.getTitle());
								break;
							}
						}
					}
				}
			}
		}
        System.out.println("FIN");
	}
}
