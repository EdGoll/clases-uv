import java.util.List;
public class Movies {
    private String idmovie;
    private String titulo;
    private List<String> genero;
    
    public Movies(){
    }
    
    public Movies (String idmovie, String titulo, List<String> genero){
        this.genero = genero;
        this.idmovie = idmovie;
        this.titulo = titulo;
    
    }

    public String getIdmovie() {
        return idmovie;
    }

    public void setIdmovie(String idmovie) {
        this.idmovie = idmovie;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public List<String> getGenero() {
        return genero;
    }

    public void setGenero(List<String> genero) {
        this.genero = genero;
    }
    
}
