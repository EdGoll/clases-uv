public class promRatings {
    private float promedioTotal;
    private String id;
    
    public promRatings(String id, float valor, int cont){
        this.id = id;
        promedioTotal = valor / cont;
    }
    

    public float getPromedioTotal() {
        return promedioTotal;
    }

    public void setPromedioTotal(int promedioTotal) {
        this.promedioTotal = promedioTotal;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
}
