public class Ratings {
    private String id_usuario;
    private String id_pelicula;
    private String rating;
    
    public Ratings() {
    }

    public Ratings(String id_usuario, String id_pelicula, String rating) {
        this.id_usuario = id_usuario;
        this.id_pelicula = id_pelicula;
        this.rating = rating;
    }

    public String getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(String id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getId_pelicula() {
        return id_pelicula;
    }

    public void setId_pelicula(String id_pelicula) {
        this.id_pelicula = id_pelicula;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
    
}
