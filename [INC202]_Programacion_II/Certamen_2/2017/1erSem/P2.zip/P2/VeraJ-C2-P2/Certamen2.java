import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Certamen2 extends FuenteDeDatos{
    private List<Movies> peliculas;
    private List<Ratings> ratings;
    
    public Certamen2(){
        peliculas = new ArrayList<>();
        ratings = new ArrayList<>();
        cargar();
    }
    
    private void cargar(){
        List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
	Movies m;
        List<String> genero;
	StringTokenizer st,ts;
        lineas.remove(0);
	for(String l: lineas){
            st = new StringTokenizer(l,";");
            genero = new ArrayList<>();
            if(st.hasMoreTokens()){
                String idmov = st.nextToken();
                String titulo = st.nextToken();
                ts = new StringTokenizer(st.nextToken(),"|");
                while(ts.hasMoreTokens()){
                    genero.add(ts.nextToken());
                }
                m = new Movies (idmov, titulo, genero);
                peliculas.add(m);
            }
	}
        lineas = FuenteDeDatos.leerArchivo("ratings.csv");
	Ratings r;
	lineas.remove(0);
	for(String l: lineas){
            st = new StringTokenizer(l,";");
            if(st.hasMoreTokens()){
		r = new Ratings (st.nextToken(), st.nextToken(), st.nextToken());
		ratings.add(r);
            }
	}
    }
    public void adventure(){
        List<String> nom = new ArrayList<>();
        nom.add("\n\n**********  Peliculas de aventura  **********\n\n");
        FuenteDeDatos.escribirArchivo("resultados.txt", nom, false);
        for (Movies j : peliculas) {
            nom = new ArrayList<>();
            nom.add(j.getTitulo());
            
            if (j.getGenero().contains("Adventure")) {
                FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
            }
        }
    }
    
    
    public void thrillerCrime(){
        List<String> nom = new ArrayList<>();
        nom.add("\n\n**********  Peliculas de thriller y crimen  **********\n\n");
        FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
        for (Movies j : peliculas) {
            nom = new ArrayList<>();           
            nom.add(j.getTitulo());
            if (j.getGenero().contains("Thriller") && j.getGenero().contains("Crime")) {
                FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
            }
 
        }

    }
    public void listadoAño(int año){
        List<String> nom = new ArrayList<>();
        String cadena = String.valueOf(año);
        String trampa = "\n\n**********  Peliculas del año "+cadena+"  **********\n\n";
        nom.add(trampa);
        FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
        for (Movies j : peliculas) {
            nom = new ArrayList<>();           
            nom.add(j.getTitulo());
                if(j.getTitulo().contains(cadena)){
                    FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
                }
            }

    }
    public List<promRatings> promRatings(){
        List<promRatings> promedio = new ArrayList<>();
        promRatings k;
        float sumatot = 0;
        int contador = 0;
        
        for (Movies l : peliculas) {
            for (Ratings r : ratings) {
                if (r.getId_pelicula().equals(l.getIdmovie())) {
                        sumatot += Float.parseFloat(r.getRating());
                        contador ++;
                        
                        
               }
            }
            k = new promRatings(l.getIdmovie(),sumatot, contador);
            promedio.add(k);
        } 
        return promedio;
    }

    
    
    public void ratingMayor(int rating){
        List<String> nom = new ArrayList<>();
        String cadena = String.valueOf(rating);
        String trampa = "\n\n**********  Peliculas de rating igual o superior a: "+cadena+"  **********\n\n";
        nom.add(trampa);
        FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
        List<promRatings> pr = promRatings();
        for (promRatings r : pr) {
            if (r.getPromedioTotal() >= rating) {
                for (Movies m : peliculas) {
                    if(m.getIdmovie().equals(r.getId())){
                        nom = new ArrayList<>();
                        nom.add(m.getTitulo());
                        FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
                    
                    }
                }
                
            }
        }
        
    }
    public void ratingMayorComedy(int rating){
        List<String> nom = new ArrayList<>();
        String cadena = String.valueOf(rating);
        String trampa = "\n\n**********  Peliculas de comedia con rating igual o superior a: "+cadena+"  **********\n\n";
        nom.add(trampa);
        FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
        List<promRatings> pr = promRatings();
        for (promRatings r : pr) {
            if (r.getPromedioTotal() >= rating) {
                for (Movies m : peliculas) {
                    if(m.getIdmovie().equals(r.getId())&&m.getGenero().contains("Comedy")){
                        nom = new ArrayList<>();
                        nom.add(m.getTitulo());
                        FuenteDeDatos.escribirArchivo("resultados.txt", nom, true);
                    
                    }
                }
                
            }
        }
        
    }
}
