import java.util.Scanner;
public class Certamen2Impl {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el año de la pelicula: ");
        int año = sc.nextInt();
        System.out.println("ingrese el rating de las peliculas: ");
        int rating = sc.nextInt();
        System.out.println("ingrese el rating de las peliculas de comedia: ");
        int ratingcomedy = sc.nextInt();
        Certamen2 movie = new Certamen2();
        movie.adventure();
        movie.thrillerCrime();
        movie.listadoAño(año);
        movie.ratingMayor(rating);
        movie.ratingMayorComedy(ratingcomedy);
    }
    
}
