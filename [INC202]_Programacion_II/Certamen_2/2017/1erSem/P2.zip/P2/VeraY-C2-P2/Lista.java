
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.io.InputStreamReader;

/**Esta clase contiene los metodos
 *
 * @author yianv
 */
public class Lista {
    private final List<Movie> pelicula;
    private final List<Rating> rating;
    
    
    public Lista() {
        pelicula = new ArrayList<>();
	cargarMovie();
        rating = new ArrayList<>();
        cargarRating();
        
    }
    
    private void cargarMovie(){//Mapeo del archivo ""movies.csv"
	List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
	Movie j;
	StringTokenizer st;
	lineas.remove(0);
	for(String l: lineas){
		st = new StringTokenizer(l,";");
		if(st.hasMoreTokens()){
                    j = new Movie (st.nextToken(), st.nextToken(), st.nextToken());
                    pelicula.add(j);
		}
	}
    }
    private void cargarRating(){//Mapeo del archivo "ratings.cvs"
	List<String> lineas = FuenteDeDatos.leerArchivo("ratings.csv");
	Rating k;
	StringTokenizer st;
	lineas.remove(0);
	for(String l: lineas){
		st = new StringTokenizer(l,";");
		if(st.hasMoreTokens()){
                    k = new Rating (st.nextToken(), st.nextToken(),st.nextToken());
                    rating.add(k);
			}
		}
	}
    
    public void genAdventure() throws IOException { // Metodo para listar las peliculas de genero Adventure
        FileWriter fw = new FileWriter("resultados.txt",true);
        fw.write("\r\n#############################  Peliculas del genero adventure   ###################################### \r\n");
        
        for(Movie p : pelicula){
            String[] darray= p.getGenres().split("\\|");
            for(String dats : darray){
                //System.out.println(dats);
                if("Adventure".equals(dats)){
                  //System.out.println(p.getTitle()); 
                  fw.write(p.getTitle()+"\r\n");
                }   
            }
        }
        fw.close();
        System.out.println("Se ha añadido la lista de peliculas de genero Adventure en el archivo resultados.txt");
    } 

  
    public void genThrillerCrime() throws IOException{ // Meotodo para listar las peliculas de genero Thriller y Crime
        FileWriter fw = new FileWriter("resultados.txt",true);
        fw.write("\r\n\n #############################  Peliculas del genero Thriller y Crime A la vez   ############################## \r\n");
       
        for(Movie p : pelicula){
            String[] darray1= p.getGenres().split("\\|");
            int cont= 0;
            for(String dats : darray1){
                if("Crime".equals(dats)){
                   cont++;
                }
                if("Thriller".equals(dats)){
                    cont++;
                }
                if(cont==2){
                   fw.write(p.getTitle()+"\r\n");
                }   
            }   
        }
        fw.close();
        System.out.println("Se ha añadido la lista de peliculas de genero thriller y crime en el archivo resultados.txt");
    }
  
    public void allMovieAge() throws IOException{// Metodo para listar todas las peliculas del año ingresado 
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
          
        System.out.println("Ingrese año para listar las peliculas: ");
        String año = br.readLine();
        FileWriter fw = new FileWriter("resultados.txt",true);
        PrintWriter fw1 = new PrintWriter(fw);
        fw1.write("\r\n\n ##################################  Peliculas del "+año+"   ######################################### \r\n");
        for(Movie p : pelicula){
            String[] darray2= p.getTitle().split("\\(");
            for(String dats : darray2){
                //System.out.println(dats);
                if((año+")").equals(dats)){
                    //System.out.println(p.getTitle());
                    fw1.write(p.getTitle()+"\r\n");
                }
            }
       }
       fw.close();
       System.out.println("Se ha añadido la lista de peliculas del año "+año+" en el archivo resultados.txt");
    }
    
    public void allMovieRating() throws IOException{// Metodo para listar todas las peliculas iguales o mayores al rating ingresado
      
      FileWriter fw = new FileWriter("resultados.txt",true);
      PrintWriter fw3 = new PrintWriter(fw);
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Ingrese valor para buscar peliculas con el mismo o mayor rating, ej:1.5 o ej: 1.0  : ");
      String valor = br.readLine();
      fw3.write("\r\n\n #############################  Peliculas de Raating igual o mayor a  "+valor+"   ############################## \r\n");
     float v1=(float) Float.parseFloat(valor);
     
        
    /* for(Rating r : rating){
          float v2 = (float) Float.parseFloat(r.getValorRating());
          String temp=r.getMovieId();
          if (v1 >= v2){
              
             for(Movie p: pelicula){
                 if(temp.equals(p.getMovieId())){
                     
                     fw3.write(p.getTitle()+" Rating: "+r.getValorRating()+"\r\n");
                  
                }   
             }  
         }   
      }*/
      fw.close();
      System.out.println("Se ha añadido la lista de peliculas de Rating igual o mayor a "+valor+" ,resultados en el archivo resultados.txt");
    }
    
    public void allMovRaComedy(){//Metodo para listar todas las pelicula iguales o mayores de genero comedia al rating ingresado
      System.out.println("Se ha añadido la lista de peliculas de rating igual o mayor al valor ingresado de genero comedy en el archivo resultados.txt");
    }


}
