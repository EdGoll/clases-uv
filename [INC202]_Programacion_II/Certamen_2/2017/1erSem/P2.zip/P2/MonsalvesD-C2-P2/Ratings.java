
public class Ratings {
    private int userId;
    private float rating; 

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public Ratings(int userId, float rating) {
        this.userId = userId;
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Ratings{" + "userId=" + userId + ", rating=" + rating + '}';
    }
    
}
