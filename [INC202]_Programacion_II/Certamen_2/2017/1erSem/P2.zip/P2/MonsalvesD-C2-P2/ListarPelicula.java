/*

El archivo Respuestas.txt, esta identado y con salto de líneas respectivamente,
en donde al ejecutarse en el netbeans queda todo ordenado, en cambio cuando se
ejecuta el archivo java en la consola, el .txt al hacer doble clic para abrirlo
queda desordenado. Un caso extraño, manteniendo el último caso, si se ejecuta el .txt
en la consola con more, nano o un editor de texto (sublime text, Atom, notepad++),
el archivo Respuestas.txt, se ve ordenado.
Es un comentario para cuando revise el archivo resultante del programa.

*/
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
public class ListarPelicula {
    private List<Movies> pelicula;
    private List<Ratings> ratings;
    private List<Movies> peliculaconratings;
    private final String rutaMovies = "movies.csv";
    private final String rutaratings = "ratings.csv";
    private final String archivoWrite ="Respuestas.txt" ;

    public ListarPelicula(){
        pelicula = new ArrayList<>();
        ratings = new ArrayList<>();

        peliculaconratings = new ArrayList<>();
        cargarMovie();
        cargarRatings();
    }
    private void cargarMovie(){
        List<String> lineas;
        lineas = FuenteDeDatos.leerArchivo(rutaMovies);
        int cont = 0;
        for (String l : lineas){
            ArrayList <String> genero = new ArrayList<>();
            List <String> a = new ArrayList<>();
            StringTokenizer tr = new StringTokenizer(l,";");
            if (cont == 0) {
                cont++;
                continue;
            }
            while(tr.hasMoreTokens()){
                a.add(tr.nextToken());
            }
            StringTokenizer gn = new StringTokenizer(a.get(2),"|");
            while(gn.hasMoreTokens()){
               genero.add(gn.nextToken());
            }
            Movies m = new Movies(Integer.parseInt(a.get(0)), a.get(1), genero);
            pelicula.add(m);
        }
    }
    private void cargarRatings(){
        List<String> lineas;
        lineas = FuenteDeDatos.leerArchivo(rutaratings);
        int cont = 0;
        for(String l : lineas){
            List <String> a = new ArrayList<>();
            StringTokenizer tr = new StringTokenizer(l,";");
            if (cont == 0) {
                cont++;
                continue;
            }
            while(tr.hasMoreTokens()){
                a.add(tr.nextToken());
            }
            Ratings ra = new Ratings(Integer.parseInt(a.get(1)), Float.parseFloat(a.get(2)));
            ratings.add(ra);
        }
    }
    public void peliculaAdventure(){
        List <String> titulo = new ArrayList<>();
        titulo.add("Listado de las pelicula que son del Genero Adventure:\n");
        List <String> peli = new ArrayList<>();
        FuenteDeDatos.escribirArchivo( archivoWrite , titulo, true);
        for(Movies m : pelicula){
            if (m.getGenero().contains("Adventure")) {
                peli.add("\t\t"+m.getTitulo().substring(0, m.getTitulo().indexOf("(")));                
            }
        }
        FuenteDeDatos.escribirArchivo(archivoWrite,peli , true);
    }
    public void peliculasThrilleryCrime(){
        List <String> titulo = new ArrayList<>();
        titulo.add("\n\nListado de las pelicula que son del Genero Thriller y Crime:\n\n");
        List <String> peli = new ArrayList<>();
        FuenteDeDatos.escribirArchivo( archivoWrite, titulo, true);
        for(Movies m : pelicula){
            if ((m.getGenero().contains("Crime")) && ((m.getGenero().contains("Thriller")))) {
                peli.add("\t\t"+m.getTitulo().substring(0, m.getTitulo().indexOf("(")));                
            }
        }
        FuenteDeDatos.escribirArchivo(archivoWrite,peli , true);
    }
    public void peliculasListadasPorAño(){
        System.out.print("Ingrese el año de la pelicula que desea buscar:\t");
        Scanner sc = new Scanner(System.in);
        String año;
        año = sc.nextLine();
        List <String> titulo = new ArrayList<>();
        titulo.add("\n");
        titulo.add("\nListado de las pelicula del año "+año+":");
        titulo.add("\n");
        List <String> peli = new ArrayList<>();
        FuenteDeDatos.escribirArchivo( archivoWrite, titulo, true);
        for(Movies m : pelicula){
            if (m.getTitulo().contains("("+año+")")){
                if (m.getTitulo().contains("(")) {
                    peli.add("\t\t"+m.getTitulo().substring(0, m.getTitulo().indexOf("(")));                
                }
                else{
                    peli.add("\t\t"+m.getTitulo());
                }
            }
        }
        FuenteDeDatos.escribirArchivo(archivoWrite,peli , true);
    }
    public void  enviarId(){
        for (int i = 0; i < pelicula.size(); i++) {
            int id = pelicula.get(i).getMovieId();
            peliculasConRatings(id);
        }
    }
    public void peliculasConRatings(int id){
        int idbuscar = id;
        float sumaratings = 0;
        float promedioratings = 0;
        int cont = 0;
        String titulo = null;
        for (Ratings l : ratings){
            if (l.getUserId() == idbuscar) {
                sumaratings = sumaratings + l.getRating();
                cont++;
            }
        }
        for (Movies l : pelicula){
            if (l.getMovieId()== idbuscar) {
                titulo = l.getTitulo();
                if(l.getTitulo().contains("(")){
                titulo = titulo.substring(0, titulo.indexOf("(")).trim();
                }
            }
        }
        if(cont>=1){
        promedioratings = sumaratings/cont;
        }
        Movies m = new Movies(idbuscar, titulo ,promedioratings);
        peliculaconratings.add(m);
    }
    public void peliculasratingsusuario(){
        float r;
        System.out.print("Ingrese el Ratings de las peliculas a buscar:\t");
        Scanner sc = new Scanner(System.in);
        r = sc.nextFloat();
        List <String> titulo = new ArrayList<>();
        titulo.add("\n");
        titulo.add("\nListado de las pelicula con ratings mayor igual a "+r+" :");
        titulo.add("\n");
        List <String> peli = new ArrayList<>();
        FuenteDeDatos.escribirArchivo( archivoWrite, titulo, true);
        for(Movies m : peliculaconratings ){
            if (m.getRatings() >= r) {
                peli.add("\t\t"+m.getTitulo()+"\t\tRatings: "+m.getRatings());
            }
        }
        FuenteDeDatos.escribirArchivo(archivoWrite,peli , true);
    }
    public void peliratingComedy(){
        float r;
        System.out.print("Ingrese el Ratings de las peliculas de categoria Comedy a buscar:\t");
        Scanner sc = new Scanner(System.in);
        r = sc.nextFloat();
        List <String> titulo = new ArrayList<>();
        titulo.add("\n");
        titulo.add("\nListado de las pelicula con ratings mayor igual a "+r+" y genero Comedy :");
        titulo.add("\n");
        List <String> peli = new ArrayList<>();
        FuenteDeDatos.escribirArchivo( archivoWrite, titulo, true);
        for(Movies m : peliculaconratings ){
            if (m.getRatings()>= r){
                for(Movies l : pelicula){
                    if((l.getGenero().contains("Comedy")) && (l.getMovieId() == m.getMovieId())){
                        peli.add("\t\t"+m.getTitulo()+"\t\tRatings: "+m.getRatings()+"\tGenero:"+l.getGenero());

                    }
                }
            }
        }
        FuenteDeDatos.escribirArchivo(archivoWrite,peli , true);
    }        
}