
import java.util.ArrayList;

public class Movies {
    private int movieId;
    private String titulo;
    private ArrayList <String> genero;
    private float ratings;

    public float getRatings() {
        return ratings;
    }

    public void setRatings(float ratings) {
        this.ratings = ratings;
    }

    public int getMovieId() {
        return movieId;
    }    

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public ArrayList<String> getGenero() {
        return genero;
    }

    public void setGenero(ArrayList<String> genero) {
        this.genero = genero;
        
    }

    public Movies(int movieId, String titulo, ArrayList<String> genero) {
        this.movieId = movieId;
        this.titulo = titulo;
        this.genero = genero;
    }

    public Movies(int movieId, String titulo, float ratings) {
        this.movieId = movieId;
        this.titulo = titulo;
        this.ratings = ratings;
    }
    

    @Override
    public String toString() {
        return "Movies{" + "movieId=" + movieId + ", titulo=" + titulo + ", ratings=" + ratings + '}';
    }
    
    
    
}
