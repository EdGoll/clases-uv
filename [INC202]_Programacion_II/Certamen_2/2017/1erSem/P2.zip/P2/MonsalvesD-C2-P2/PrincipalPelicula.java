public class PrincipalPelicula {
    public static void main(String[] args) {
        ListarPelicula c1 = new ListarPelicula();
        c1.peliculaAdventure();
        c1.peliculasThrilleryCrime();
        c1.peliculasListadasPorAño();
        c1.enviarId();
        c1.peliculasratingsusuario();
        c1.peliratingComedy();
    }
    
}
