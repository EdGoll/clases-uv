public class Rating
{
	private int id;
	private double rating;
	private int userId;
	
	public Rating(int userId, int id, double rating)
	{
		this.id = id;
		this.rating = rating;
		this.userId = userId;
	}
	
	public int getMovieId()
	{
		return id;
	}
	
	public int getUserId()
	{
		return userId;
	}
	
	public double getRating()
	{
		return rating;
	}
}
