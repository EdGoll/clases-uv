import java.util.List;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Lista
{
	public ArrayList<Movie> movies = new ArrayList<>();
	public ArrayList<Rating> ratings = new ArrayList<>();
	private String year;
	private double rating;
	public List<String> output = new ArrayList<>();
	
	public Lista(int year, double rating)
	{
		this.year = Integer.toString(year);
		this.rating = rating;
	}
	
	public void readMovies()
	{
		List<String> lines = FuenteDeDatos.leerArchivo("movies.csv");
		lines.remove(0);

		for(String line: lines){			
			String[] splitted = line.split(";");
			
			int id = Integer.parseInt(splitted[0]);
			String title = splitted[1];
			
			Matcher m = Pattern.compile("\\(([0-9]+)\\)").matcher(title);
			
			String year = m.find() ? m.group(1) : "Sin registro de anio";
			
			List<String> genres = new ArrayList<>();			
			String[] splittedGenres = splitted[2].split("\\|");
			
			for(String genre: splittedGenres){
				genres.add(genre);
			}
			
			movies.add( new Movie(id, title, genres, year) );
		}
	}
	
	public void readRatings()
	{
		List<String> lines = FuenteDeDatos.leerArchivo("ratings.csv");
		lines.remove(0);
		
		for(String line: lines){
			String[] splitted = line.split(";");
			int userId = Integer.parseInt(splitted[0]);
			int id = Integer.parseInt(splitted[1]);
			double rating = Double.parseDouble(splitted[2]);
			
			ratings.add( new Rating(userId, id, rating) );
			//System.out.println(id+" "+rating);
		}
		
		averageRatings();
	}
	
	public void getAdventureMovies()
	{
		output.add("PELICULAS DEL GENERO ADVENTURE:");
		output.add("\n");		
		int count = 0;
		
		for(int i = 0; i < movies.size(); i++){
						
			List<String> genres = movies.get(i).getGenres();
			
			for( int j = 0; j < genres.size(); j++ ){				
				if( genres.get(j).equals("Adventure") ){
					output.add(movies.get(i).getTitle());
					count++;
				}				
			}
		}
		
		output.add("\n");
		output.add("TOTAL: "+count);
		output.add("\n");
	}
	
	public void getThrillerCrimeMovies()
	{
		output.add("PELICULAS DEL GENERO THRILLER-CRIME:");
		output.add("\n");		
		int count = 0;
		
		for(int i = 0; i < movies.size(); i++){			
			List<String> genres = movies.get(i).getGenres();
			
			for( int j = 0; j < genres.size(); j++ ){
				if( genres.get(j).equals("Crime") ){
					for(j = j+1; j < genres.size(); j++){
						if( genres.get(j).equals("Thriller") ){
							output.add(movies.get(i).getTitle());
							count++;
						}
					}
				}
			}
		}
		
		output.add("\n");
		output.add("TOTAL: "+count);
		output.add("\n");
	}
	
	public void getYearMovies()
	{
		output.add("PELICULAS DEL ANIO INGRESADO:");
		output.add("\n");		
		int count = 0;
		
		for(int i = 0; i < movies.size(); i++){			
			String movieYear = movies.get(i).getYear();
			if(year.contains(movieYear)){
				output.add(movies.get(i).getTitle());
				count++;
			}
		}
		
		output.add("\n");
		output.add("TOTAL: "+count);
		output.add("\n");
	}

	public void getSpecifiedRating()
	{
		output.add("RATING MAYOR O IGUAL AL INGRESADO:");
		output.add("\n");
		
		int count = 0;
		for(int i = 0; i < movies.size(); i++){
			if(movies.get(i).getRating() >= rating){
				output.add(movies.get(i).getRating()+" "+movies.get(i).getTitle());
				count++;
			}
		}
		
		output.add("\n");
		output.add("TOTAL: "+count);
		output.add("\n");
	}
	
	public void getSpecifiedRatingAndGenre()
	{
		output.add("RATING MAYOR O IGUAL AL INGRESADO Y GENERO COMEDIA:");
		output.add("\n");
		
		int count = 0;
		for(int i = 0; i < movies.size(); i++){
			if(movies.get(i).getRating() >= rating && checkGenre(i, "Comedy") == true){
				output.add(movies.get(i).getRating()+" "+movies.get(i).getTitle());
				count++;
			}
		}
		
		output.add("\n");
		output.add("TOTAL: "+count);
		output.add("\n");
	}
	
	public void averageRatings()
	{
		for(int i = 0; i < movies.size(); i++){
			int id = movies.get(i).getId();
			int count = 0;
			double average = 0;
			
			for(int j = 0; j < ratings.size(); j++){
				if(id == ratings.get(j).getMovieId()){
					count += 1;
					average += ratings.get(j).getRating();
				}
			}
			
			if(count != 0){
				average = average / count;
				average = Math.round(average*100);
				average = average / 100;
			}
			
			movies.get(i).setRating(average);
			movies.get(i).setVotedUsers(count);
		}
	}
	
	public boolean checkGenre(int id, String genreName)
	{
		List<String> genres = movies.get(id).getGenres();
		
		for(String genre: genres){
			if(genre.equals(genreName)){
				return true;
			}
		}
		
		return false;
	}
}
