import java.util.List;
import java.util.ArrayList;

public class Movie
{
	private int id;
	private List<String> genres = new ArrayList<>();
	private String title;
	private String year;
	private int votedUsers;
	private double rating;
	
	public Movie(int id, String title, List<String> genres, String year)
	{
		this.id = id;	
		this.title = title;
		this.year = year;
		setGenres(genres);
	}
	
	public void setGenres(List<String> genres)
	{
		for(int i = 0; i < genres.size(); i++){
			this.genres.add(genres.get(i));
		}
	}
	
	public void setRating(double rating)
	{
		this.rating = rating;
	}
	
	public void setVotedUsers(int users)
	{
		this.votedUsers = users;
	}
	
	public double getRating()
	{
		return rating;
	}
	
	public int getVotedUsers()
	{
		return votedUsers;
	}
	
	public int getId()
	{
		return id;
	}
	
	public List<String> getGenres()
	{
		return genres;
	}
	
	public String getTitle()
	{
		return title;
	}
	
	public String getYear()
	{
		return year;
	}
}
