import java.util.Locale;
import java.util.Scanner;

public class Impl
{
	public static void main(String[] args)
	{
		// Locale US para poder ingresar decimales con un punto, no con una coma
		Scanner sc = new Scanner(System.in).useLocale(Locale.US);
		
		System.out.print("Ingrese anio de las peliculas a listar: ");
		int anio = sc.nextInt();
		
		System.out.print("Ingrese rating de las peliculas a listar (de 1.0 a 5.0): ");
		double rating = sc.nextDouble();
		
		sc.close();
		
		Lista l = new Lista(anio, rating);
		
		l.output.add("------------------------ NUEVA BUSQUEDA ------------------------");
		l.output.add("\n");
		
		l.readMovies();	
		l.readRatings();
		l.getAdventureMovies();
		l.getThrillerCrimeMovies();
		l.getYearMovies();		
		l.getSpecifiedRating();
		l.getSpecifiedRatingAndGenre();
		
		l.output.add("\n");
		l.output.add("------------------------ FIN BUSQUEDA ------------------------");
		l.output.add("\n");
		
		FuenteDeDatos.escribirArchivo("resultados.txt", l.output, true);
		
		System.out.println("Trabajo finalizado");
	}
}
