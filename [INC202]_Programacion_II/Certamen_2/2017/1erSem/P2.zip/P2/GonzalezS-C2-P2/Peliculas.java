import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Peliculas {
	private List<Movies> film;
	
	public Peliculas(){
		film = new ArrayList<>();
		cargar();
	}

	private void cargar() {
		List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
		Movies j;
		String[] datos;
		lineas.remove(0);
		for(String l:lineas){
			datos = l.split(";");
				j = new Movies (datos[0],datos[1], datos[2]);
				film.add(j);
				
			}
	}
	
	public void genreAdventure(){
		
		for(Movies m : film){		
			if(m.getGenres().contains("Adventure")){
				 System.out.println("Las peliculas Adventure son: " + m.getTitle());
			}
		}
	}

	public void genreThillerAndCrime(){
		for(Movies m : film){		
			if(m.getGenres().contains("Thriller") && m.getGenres().contains("Crime")){
				System.out.println("Las peliculas de Thriller and Crime son: " + m.getTitle());
			}
		
		}
	
 	}

	public void anhioIngresado(){
		String anhio;
		Scanner sc = new Scanner(System.in);	
		System.out.print("Ingreso un anhio para mostrar las peliculas correspondientes: ");
		anhio = sc.nextLine();
		for(Movies m : film){		
			if(m.getTitle().contains(anhio)){
				System.out.println("Las peliculas del anhio correspondiente son :  "+ anhio + "  " + m.getTitle());
			}
		}	
	}

	public void ratngSuperiorOigual(){
	}
		
	public void ratngSupriorOigualGneroComedia(){

	}
	//public void escribirResultado(){
	//	List<> lineas1 = FuenteDeDatos.escribirArchivo("C:\\resultados.txt",film,true);
	//}


}


