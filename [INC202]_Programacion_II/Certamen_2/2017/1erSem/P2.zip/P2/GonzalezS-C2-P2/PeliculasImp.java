public class PeliculasImp {

	public static void main(String[] args) {
		Peliculas cine = new Peliculas();

		cine.genreAdventure();
		cine.genreThillerAndCrime();
		cine.anhioIngresado();
		cine.ratngSuperiorOigual();
		cine.ratngSupriorOigualGneroComedia();
		//cine.escribirResultado();
	}

}
