public class MoviImp {
    
    public static void main(String[] args) {
        Lista a = new Lista();
        a.separar();
        a.separarRating();
        a.generoAdventure();
        a.generoxdos();
        a.anioIngresado();
        a.superiorRating();
        a.ratisupComedy();
       //Lo deje comentado para que a la hora de compilar no ejecute todo a la vez
    }
}
