
public class Rating {
    private String userld;
    private String movield;
    private String rating;

    public String getUserld() {
        return userld;
    }

    public void setUserld(String userld) {
        this.userld = userld;
    }

    public String getMovield() {
        return movield;
    }

    public void setMovield(String movield) {
        this.movield = movield;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public Rating(String userld, String movield, String rating) {
        this.userld = userld;
        this.movield = movield;
        this.rating = rating;
    }
    
}
