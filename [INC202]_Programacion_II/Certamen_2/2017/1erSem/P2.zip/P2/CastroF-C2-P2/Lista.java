import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Lista {
    private List<Movies> muvi = null;
    private List<Rating> rati = null;
    
    public Lista(){
    muvi = new ArrayList<>();
    rati = new ArrayList<>();
    
}
    public void separar(){
        List <String> lista;
        lista = FuenteDeDatos.leerArchivo("");
        String[] a;
        Movies plp;
        for(String l : lista){
            a = l.split(";");           
            plp = new Movies(a[0], a [1], a[2]);
            muvi.add(plp);  
        }
        
     
    }
    
    public void separarRating(){
        List <String> lista;
        lista = FuenteDeDatos.leerArchivo(""); 
        String[] a;       
        Rating plp;
        lista.remove(0);
        for(String l : lista){          
            a = l.split(";");
            plp = new Rating(a[0], a[1], a[2]);
            rati.add(plp);   
       }
     
    }
    public void generoAdventure(){
        int count = 0;
        String [] b;
        for(Movies j:muvi){
            count ++;
            if(count > 0){           
            j.getGenero();
            b = j.getGenero().split("\\|");
            int n = b.length;
            for( int i = 0; i<n; i++){
                if(b[i].toUpperCase().contains("ADVENTURE")){
                    System.out.println(j.getNombre());
                    //Imprime todas las peliculas que contienen el genero Adventure//
                   /* File archivo;
                    FileWriter w;
                    BufferedWriter bw;
                    PrintWriter wr;
                    try{
                    archivo = new File("C:\\Users\\anime\\Desktop\\Nueva carpeta (2)\\texto.txt");
                    if(archivo.createNewFile()){
                        System.out.println("Se ha creado el archivo");
                    }else{
                        w = new FileWriter(archivo);
                        bw = new BufferedWriter(w);
                        wr = new PrintWriter(bw);
                        wr.write(j.getNombre());
                        wr.close();
                        bw.close();
                        
                        
                        
                    
                        
                    }
                    }catch(IOException e){
                        
                    }*/
                }
            }
            }
        }
    }
                
                
    
    
public void generoxdos(){
         int count = 0;
        String [] b;
        for(Movies j:muvi){
            count ++;
            if(count > 0){
            j.getGenero();
            b = j.getGenero().split("\\|");
            int n = b.length;
            for( int i = 0; i<n; i++){
                for(int h = 0; h <n; h++){
                if(b[i].toUpperCase().contains("THRILLER")){
                    if(b[h].toUpperCase().contains("CRIME")){
                        System.out.println(j.getNombre());
                        //Imprime todas las peliculas cuyos generos son THRILLER Y CRIME
                    }
                    }
            }
            }
            }
        }
    }
    public void anioIngresado(){
        Scanner numero = new Scanner(System.in);
        System.out.println("Ingrese el anio que desea buscar: ");
        int i = numero.nextInt();
        int count = 0;
        String cadena ="";
        cadena= Integer.toString(i);
        for(Movies j:muvi){
            count ++;
            if(j.getNombre().contains(cadena)){
                //System.out.println("gg");
                System.out.println(j.getNombre());
                //Imprime las peliculas dependiendo del anio Ingresado(tiene un pequenio error 
                //al imprimir tambien imprime las peliculas cuyos nombre ontenga el numero ingresado, por ejemplo 2000
            }   
        }
    }
    
  public void superiorRating(){
   Scanner numero = new Scanner(System.in);
   //List c = new ArrayList<>();
   //List d = new ArrayList<>();
   //int count = 0;
   double i = numero.nextDouble();
        for(Rating j:rati){
           String b=j.getRating();
           double a = Double.parseDouble(b);
           if(a >= i){
           //count++;
           
           for(Movies s : muvi){
              if(j.getMovield().equals(s.getId())){
                    System.out.println(s.getNombre());
                     break;
                     //Imprime las peliculas cuyo Rating sea igual o mayor al solicitado
                 }
             }
           }
   }
  }
  public void ratisupComedy(){
        Scanner numero = new Scanner(System.in);
        double i = numero.nextDouble();
        String x[];
        for(Rating j:rati){
           String b=j.getRating();
           double a = Double.parseDouble(b);
           if(a >= i){
           //count++;
           for(Movies s : muvi){
              if(j.getMovield().equals(s.getId())){
                    //System.out.println(s.getNombre());
                    x = s.getGenero().split("\\|");
                    int gg = x.length;
                    if(gg == 1){
                        
                    
                    if(x[0].toUpperCase().contains("COMEDY")){
                        System.out.println(s.getNombre());
                    }
                     //System.out.println(gg);
                    }//Imprime las peliculas cuyo ranting sea mayor o igual al solicitado y que solo 
                    //sean de genero Comedy
                    }
             }
           }
   }
      
  } 
  
 
}
                    
              

            
      