import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TDAList{
	private List<EntidadMovie> lista1;
	private List<EntidadRating> lista2;

	public TDAList(){
		lista1 = new ArrayList<>();
		lista2 = new ArrayList<>();
		cargar1();
		cargar2();
	}
	private void cargar1(){
		List<String> lineas1 = FuenteDeDatos.leerArchivo("movies.csv");
		EntidadMovie j;
		String[] datos;
		lineas1.remove(0);
		for(String l: lineas1){
			datos = l.split(";");
			j= new EntidadMovie (datos[0], datos[1], datos[2]);
			lista1.add(j);
		}
	}
	private void cargar2(){
		List<String> lineas2 = FuenteDeDatos.leerArchivo("ratings.csv");
		EntidadRating y;
		String[] datos;
		lineas2.remove(0);
		for(String l: lineas2){
			datos = l.split(";");
			y= new EntidadRating (datos[0],datos[1],datos[2]);
			lista2.add(y);
		}
	}
	public void pregunta1(){
		for (EntidadMovie g : lista1) {
			if(g.getGenres().contains("Adventure")) {
				System.out.println("Pelicula con genero Adventure: "+ g.getTitle());
			} 
		}
	}
	public void pregunta2(){
		for (EntidadMovie g : lista1) {
			if (g.getGenres().contains("Thriller") && g.getGenres().contains("Crime")) {
				System.out.println("Pelicula con genero Thriller y Crime: "+ g.getTitle());
			}
		}
	}
	public void pregunta3(){
		String ano;
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese un ano que desea buscar:");
		ano = sc.nextLine();
		for (EntidadMovie g : lista1) {
			if(g.getTitle().contains(ano)){
				System.out.println("Pelicula del ano "+ano+": "+ g.getTitle());
			}
		}
	}
	public void pregunta4(){
		float ranking;
		Scanner sr = new Scanner(System.in);
		System.out.println("Ingrese el Rating: ");
		ranking = sr.nextFloat();
		String user;
		ArrayList<String> a = new ArrayList<String>();
		for (EntidadRating t : lista2) {
			if (ranking <= Float.parseFloat(t.getRating())) {
				user = t.getMovieId();
				if (a.size() == 0) {
					a.add(user);
				}
				else{
					int cont = 0;
					for (int i=0; i<a.size();i++) {
						if (!a.get(i).equals(user)){
							cont ++;
						}
					}
					if (cont == a.size()) {
						a.add(user);
					}
				}
			}
		}
		for (EntidadMovie g : lista1) {
			for (int i=0;i<a.size();i++ ) {
				if (a.get(i).equals(g.getMovieId())) {
					System.out.println(g.getTitle());
				}
			}
		}
	}
	public void pregunta5(){
		float ranking;
		Scanner sr = new Scanner(System.in);
		System.out.println("Ingrese el Rating: ");
		ranking = sr.nextFloat();
		String user;
		ArrayList<String> a = new ArrayList<String>();
		for (EntidadRating t : lista2) {
			if (ranking <= Float.parseFloat(t.getRating())) {
				user = t.getMovieId();
				if (a.size() == 0) {
					a.add(user);
				}
				else{
					int cont = 0;
					for (int i=0; i<a.size();i++) {
						if (!a.get(i).equals(user)){
							cont ++;
						}
					}
					if (cont == a.size()) {
						a.add(user);
					}
				}
			}
		}
		for (EntidadMovie g : lista1) {
			for (int i=0;i<a.size();i++ ) {
				if ((a.get(i).equals(g.getMovieId())) && (g.getGenres().equals("Comedy"))) {
					System.out.println(g.getTitle());
				}
			}
		}
	}
}