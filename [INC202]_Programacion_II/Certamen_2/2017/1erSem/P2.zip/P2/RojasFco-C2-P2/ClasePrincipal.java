public class ClasePrincipal{
	public static void main(String [] args){
		TDAList pelicula = new TDAList();
		pelicula.pregunta1();
		pelicula.pregunta2();
		pelicula.pregunta3();
		pelicula.pregunta4();
		pelicula.pregunta5();
	}
}
