

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;


public class Lista {
	private List<String> lineas;
	private List<Movie> listPeliculas;
	private List<Rating> listRating;
	private List<String> listAdventure = new ArrayList<>();
	private List<String> listThriCrim = new ArrayList<>();
	private List<String> listAnios = new ArrayList<>();
	private List<String> listRatings = new ArrayList<>();
	private List<String> listRatingsComedy = new ArrayList<>();
	private Movie movie;
	private Rating rating;

	
	public Lista(){
		cargarPeliculas();
		cargarRating();
	}
	
	private void cargarPeliculas(){
	System.out.println("cargando peliculas\n");
		ArrayList<String> listGeneros ;
		ArrayList<String> anio_invertido ;
		BaseDatos f1 = new BaseDatos();
		listPeliculas = new ArrayList<Movie>();
		lineas = new ArrayList<String>();
		lineas = f1.leerArchivo("movies.csv");
		lineas.remove(0);
		StringTokenizer st,st1 ;
		for (String linea : lineas) {
			String anio = "",title="",nombre_anio="",generos="";
			anio_invertido = new ArrayList<>();
			listGeneros = new ArrayList<>();
			st = new StringTokenizer(linea);
			movie = new Movie();
			try {
				movie.setMovieId(Integer.parseInt(st.nextToken(";")));
				
			} catch (Exception e) {
				System.out.println("Error en setear anio");
			}
			nombre_anio = st.nextToken(";");
			try {
				title= title + nombre_anio.substring(0, nombre_anio.length()-7);

			} catch (Exception e) {
				System.out.println("Error en tamanio de nombre");
			}
			try {
				movie.setTitle(title);
			} catch (Exception e) {
				System.out.println("Error en setear nombre");
			}
			try {
				for(int i= nombre_anio.length()-1; i > (nombre_anio.length()-7) ; i--){
					anio_invertido.add(String.valueOf(nombre_anio.charAt(i)));	
					
				}
			} catch (Exception e) {
				System.out.println("Error en tamanio anio");
			}
			
			
			for(int i = anio_invertido.size()-2; i >= 1; i--){
				anio = anio + anio_invertido.get(i); 
				
			}
			try {
				movie.setAnio(Integer.parseInt(anio));
				
			} catch (Exception e) {
				System.out.println("Error en setear anio");
			}
			
			generos = st.nextToken();
			st1 = new StringTokenizer(generos,"|");
			while (st1.hasMoreElements()) {
				listGeneros.add((String) st1.nextElement());
			}
			movie.setListaGeneros(listGeneros);
			listPeliculas.add(movie);
		}	
	}
	private void cargarRating(){
		BaseDatos f1 = new BaseDatos();
		listRating = new ArrayList<Rating>();
		lineas = new ArrayList<String>();
		lineas = f1.leerArchivo("ratings.csv");
		lineas.remove(0);
		
		StringTokenizer st;
		for (String linea : lineas) {
			st = new StringTokenizer(linea , ";");
			rating = new Rating();
			rating.setUserId(Integer.parseInt(st.nextToken()));
			rating.setMovieId(Integer.parseInt(st.nextToken()));
			rating.setRating(Float.parseFloat(st.nextToken()));
			listRating.add(rating);
		}
	}
	public void mostrarAventura() {
		for (Movie movie : listPeliculas) {
			for (int i = 0; i < movie.getListaGeneros().size() ;i++) {
				if(movie.getGeneros(i).equals("Adventure")){
					System.out.println(movie.toString());
					listAdventure.add(movie.toString());
				}
			}
		}
		BaseDatos f1 = new BaseDatos();
		f1.escribirArchivo("adventure.csv", listAdventure);
	}
	public void mostrarMostrarTriCri() {
		for (Movie movie : listPeliculas) {
			boolean thriller=false, crime=false;
			for (int i = 0; i < movie.getListaGeneros().size() ;i++) {
				if(movie.getGeneros(i).equals("Thriller")){
					thriller = true;
				}
				if (movie.getGeneros(i).equals("Crime")) {
					crime=true;
				}
			}
			if (thriller&&crime) {
				System.out.println(movie.toString());
				listThriCrim.add(movie.toString());
			}
		}
		BaseDatos f1 = new BaseDatos();
		f1.escribirArchivo("Thriller-Crime.csv", listThriCrim);
	}
	public void mostrarAnio(int anio){
		for (Movie movie : listPeliculas) {
			if (movie.getAnio()== anio) {
				System.out.println(movie.toString());
				listAnios.add(movie.toString());		
			}
				
		}
		BaseDatos f1 = new BaseDatos();
		f1.escribirArchivo("Anios.csv", listAnios);
	}
	private Movie buscarPeliculaId(int id) {
		for (Movie movie : listPeliculas) {
			if (movie.getMovieId() == id) {
				return movie;
			}
		}
		return null;
		
	}
	public void mostrarRating(int rat){
			for (Rating rating : listRating) {
				if (rating.getRating()>= rat) {
					System.out.println("UserID "+rating.getUserId()+" Rating"+rating.getRating()+" Movie: " +buscarPeliculaId(rating.getMovieId()));
					Movie movie = buscarPeliculaId(rating.getMovieId());
					listRatings.add(movie.toString()+";"+rating.getRating());
				}
			}
			BaseDatos f1 = new BaseDatos();
			f1.escribirArchivo("RatingMayores.csv", listRatings);
		
	}
	public void mostrarRatingComedy(int rat){
			for (Rating rating : listRating) {
				if (rating.getRating()>= rat) {
					Movie movie = buscarPeliculaId(rating.getMovieId());
					for (int i = 0; i < movie.getListaGeneros().size() ;i++) {
						if(movie.getGeneros(i).equals("Comedy")){
							System.out.println("UserID "+rating.getUserId()+" Rating"+rating.getRating()+" Movie: " +buscarPeliculaId(rating.getMovieId()));
							listRatingsComedy.add(movie.toString());
						}
					}
				}
			}
			BaseDatos f1 = new BaseDatos();
			f1.escribirArchivo("Ratings-Comedy.csv", listRatingsComedy);
			
		
	}
}
