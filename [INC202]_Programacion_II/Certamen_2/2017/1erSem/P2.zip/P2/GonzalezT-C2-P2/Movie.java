

import java.util.ArrayList;

public class Movie {
	private int movieId;
	private String title;
	private int anio;
	private ArrayList<String> listaGeneros = new ArrayList<>();

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}
	
	public String getGeneros(int i) {
		return this.listaGeneros.get(i);
	}
	public ArrayList<String> getListaGeneros() {
		return listaGeneros;
	}

	public void setListaGeneros(ArrayList<String> listaGeneros) {
		this.listaGeneros = listaGeneros;
	}
	
	public String mostrarGeneros() {
		String generos="";
		for (int i = 0; i < this.listaGeneros.size(); i++) {
			generos= generos + "|"+this.listaGeneros.get(i);
		}	
	return generos;	
	}
	@Override
	public String toString() {
		return movieId + ";" + title + "(" + anio + ")" + ";"+mostrarGeneros();
	}
	
	
}
