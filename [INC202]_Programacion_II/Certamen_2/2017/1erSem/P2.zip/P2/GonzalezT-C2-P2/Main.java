

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Lista lista = new Lista();
		System.out.println("\nLISTA DE PELICULAS DE GENERO ADVENTURE:\n");
		lista.mostrarAventura();
		System.out.println("\n*************************************************************************\n");
		System.out.println("\nLISTA DE PELICULAS DE GENERO THRILLER Y CRIME\n");
		lista.mostrarMostrarTriCri();
		System.out.println("\n*************************************************************************\n");
		Scanner sc = new Scanner(System.in);
		System.out.println("\nIngrese anio:\n");
		lista.mostrarAnio(sc.nextInt());
		System.out.println("\nLISTA DE PELICULAS DEL ANIO INGRESADO POR EL USUARIO\n");
		System.out.println("\n*************************************************************************\n");
		System.out.println("\nIngrese Rating\n");
		lista.mostrarRating(sc.nextInt());
		System.out.println("\nLISTA DE PELICULAS SEGUN RATING INGRESADO POR EL USUARIO\n");
		System.out.println("\n*************************************************************************\n");
		System.out.println("\nIngrese Rating para Comedy\n");
		lista.mostrarRatingComedy(sc.nextInt());
		System.out.println("\nLISTA DE PELICULAS SEGUN RATING INGRESADO POR EL USUARIO Y DE GENERO COMEDY\n");
		System.out.println("\n*************************************************************************\n");
		sc.close();
	}

}
