import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Peli{
	private List<Persona> persona;
	private List<Persona1> persona1;
	public Peli(){
		persona = new ArrayList<>();
		cargar();
		persona1 = new ArrayList<>();
		cargar1();
	}

	private void cargar(){//SPLIT
		List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
		Persona j;
		String[] datos;
		lineas.remove(0);
		for(String l: lineas){
			datos = l.split(";");
			j = new Persona (datos[0], datos[1], datos[2]);
			persona.add(j);
		}
	}
	private void cargar1(){//SPLIT
		List<String> lineas = FuenteDeDatos.leerArchivo("ratings.csv");
		Persona1 j;
		String[] datos;
		lineas.remove(0);
		for(String l: lineas){
			datos = l.split(";");
			j= new Persona1 (datos[0], datos[1], datos[2]);
			persona1.add(j);
		}
	}
	public void generoAd(){
		for(Persona p : persona){
			if(p.getGE().contains("Adventure")){
				System.out.println("las peliculas Adventure son :"+p.getTI());			
			}
		}
	}
	public void generoTHyCR(){
		for(Persona p : persona){
			if(p.getGE().contains("Thriller") && p.getGE().contains("Crime")){
				System.out.println("las peliculas Thriller y Crime son :"+p.getTI());

			}
		}
	}
	public void anoE(){
		String anno;
		Scanner sc = new Scanner(System.in);
  		System.out.println("Ingrese un ano que desea buscar:");
  		anno = sc.nextLine();
  		for(Persona p :persona ){
			if(p.getTI().contains(anno)){
				System.out.println("las peliculas de año"+anno+" son :"+p.getTI());

			}
		}
	}
	public void rAtings(){
		double ratings;
		Scanner sc = new Scanner(System.in);
  		System.out.println("ingrese un ratings:");
  		ratings = sc.nextDouble();
  		String id;
  		ArrayList<String> a = new ArrayList<String>();
  		for (Persona1 r : persona1) {
  			if (ratings<=Double.parseDouble(r.getRA())){
  				id=r.getM();
  				if(a.size() == 0){
  					a.add(id);
  				}	
  				else{
  					int con=0;
  					int i = 0;
  					while(i<a.size()){
  						if(!a.get(i).equals(id)){
  							con++;
  						}	
  						i++;
  					}
  					if(con == a.size()){
  						a.add(id);
  					}
  				}
  			}	
		}
		for(Persona p : persona ){
			int i =0;
			while(i<a.size()){
				if(a.get(i).equals(p.getMO())){
					System.out.println("numero de ratings"+ratings+ ":"+p.getTI());
				}
				i++;
			}
		}
	}
	public void rAtings1(){
		double ratings;
		Scanner sc = new Scanner(System.in);
  		System.out.println("ingrese un ratings:");
  		ratings = sc.nextDouble();
  		String id;

  		ArrayList<String> a = new ArrayList<String>();
  		for (Persona1 r : persona1) {
  			if (ratings<=Double.parseDouble(r.getRA())){
  				id=r.getM();
  				if(a.size() == 0){
  					a.add(id);
  				}	
  				else{
  					int con=0;
  					int i = 0;
  					while(i<a.size()){
  						if(!a.get(i).equals(id)){
  							con++;
  						}	
  						i++;
  					}
  					if(con == a.size()){
  						a.add(id);
  					}
  				}
  			}	
		}
		for(Persona p : persona ){
			int i =0;
			int cont=0;
			while(i<a.size()){
				if(a.get(i).equals(p.getMO()) && p.getGE().contains("Comedy")){
					cont++;
					System.out.println("numero es   "+ratings+"y su listado:"+p.getTI());

					
				}
				i++;

			}
		}
	}
	public void escribirResultado(){
		List<String> lineas = FuenteDeDatos.leerArchivo("resultado.txt");
		FuenteDeDatos.escribirArchivo("resultado.txt",lineas,true);
	}
	
}
