public class Persona1{
	private String userId;
	private	String movieId; 
	private String rating;

	
	public Persona1(){

	}
	public Persona1(String userId, String movieId, String rating){
		this.userId = userId.trim();
		this.movieId = movieId.trim();
		this.rating = rating.trim();

	}
	public void setUS(String userId){
		this.userId = userId;
	}	
	public String getUS(){
		return userId;
	}
	public void setM(String movieId){
		this.movieId = movieId;
	}	
	public String getM(){
		return movieId;
	}
	public void setRA(String rating){
		this.rating = rating;
	}	
	public String getRA(){
		return rating;
	}

}