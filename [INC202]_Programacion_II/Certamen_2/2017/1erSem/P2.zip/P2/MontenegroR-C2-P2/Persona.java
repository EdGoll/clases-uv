public class Persona{
	private String movieId;
	private	String title; 
	private String genres;

	
	public Persona(){

	}
	public Persona(String movieId, String title, String genres){
		this.movieId = movieId.trim();
		this.title = title.trim();
		this.genres = genres.trim();

	}
	public void setMO(String movieId){
		this.movieId = movieId;
	}	
	public String getMO(){
		return movieId;
	}
	public void setTI(String title){
		this.title = title;
	}	
	public String getTI(){
		return title;
	}
	public void setGE(String genres){
		this.genres = genres;
	}	
	public String getGE(){
		return genres;
	}

}