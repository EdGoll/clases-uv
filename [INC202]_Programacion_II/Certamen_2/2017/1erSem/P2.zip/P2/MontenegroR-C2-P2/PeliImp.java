public class PeliImp{

	public static void main(String [] args){
	Peli cartelera = new Peli();
	cartelera.generoAd();
	cartelera.generoTHyCR();
	cartelera.anoE();
	cartelera.rAtings();
	cartelera.rAtings1();
	cartelera.escribirResultado();
	}
}
