import java.util.List;
import java.util.ArrayList;

public class Movie{
	private String movieId;
	private String title;
	private List<String> genres;

	public Movie(){
            genres=new ArrayList<>();
        }

	public void setMovieId(String movieId){
		this.movieId=movieId;
	}
	public String getMovieId(){
		return movieId;
	}
	public void setTitle(String title){
		this.title=title;
	}
	public String getTitle(){
		return title;
	}
	public void setGenres(String genres){
		this.genres.add(genres);
	}
	public List<String> getAListGenres(){
		return genres;
	}
	public String getStrGenres(int x){
		return genres.get(x);
	}
}