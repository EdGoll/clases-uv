public class ListaImp{
	public static void main(String[] args){
		Lista lista=new Lista();
		lista.listarGeneroAdventure();
		lista.listarGeneroThrillerCrime();
		lista.listarAñoEspecifico();
		lista.listarRatingEspecifico();
	}
}