public class Rating{
	private String userId;
	private String movieId;
	private String rating;
        
        public Rating(){}
	public Rating(String userId, String movieId, String rating){
		this.userId=userId;
		this.movieId=movieId;
		this.rating=rating;
	}
	public void setUserId(String userId){
		this.userId=userId;
	}
	public String getUserId(){
		return userId;
	}
	public void setMovieId(String movieId){
		this.movieId=movieId;
	}
	public String getMovieId(){
		return movieId;
	}
	public void setRating(String rating){
		this.rating=rating;
	}
	public String getRating(){
		return rating;
	}
}