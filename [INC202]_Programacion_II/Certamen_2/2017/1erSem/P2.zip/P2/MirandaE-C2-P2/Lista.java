import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Scanner;

public class Lista{
	private List<String> lineas;
	private StringTokenizer st1;
	private StringTokenizer st2;
	private List<Movie> movies;
	private List<Rating> ratings;

	public Lista(){
		cargarMovies();
		cargarRatings();
	}

	private void cargarMovies(){
		lineas=FuenteDeDatos.leerArchivo("movies.csv");
		movies=new ArrayList<>();
		Movie m=null;
		for(String linea:lineas){
			st1=new StringTokenizer(linea, ";");
			st2=new StringTokenizer(linea, "|");
			if(st1.hasMoreElements()){
				m=new Movie();
				m.setMovieId(st1.nextToken());
				m.setTitle(st1.nextToken());
				while(st2.hasMoreElements()){
					m.setGenres(st2.nextToken());
				}
				movies.add(m);
			}
		}
	}
	private void cargarRatings(){
		lineas=FuenteDeDatos.leerArchivo("ratings.csv");
		ratings=new ArrayList<>();
		Rating r=null;
		for(String linea:lineas){
			st1=new StringTokenizer(linea, ";");
			if(st1.hasMoreElements()){
				r=new Rating();
				r.setUserId(st1.nextToken());
				r.setMovieId(st1.nextToken());
				r.setRating(st1.nextToken());
				ratings.add(r);
			}
		}
	}
	public void listarGeneroAdventure(){
		List<String> l=new ArrayList<>();
		for(int x=0;x<movies.size();x++){
			for(int y=0;y<movies.get(x).getAListGenres().size();y++){
				if(movies.get(x).getStrGenres(y).equals("Adventure")){
					l.add(movies.get(x).getTitle());
				}
			}
		}
		FuenteDeDatos.escribirArchivo("A.txt", l, true);
	}
	public void listarGeneroThrillerCrime(){
		List<String> l=new ArrayList<>();
		int cont;
		for(int x=0;x<movies.size();x++){
			cont=0;
			for(int y=0;y<movies.get(x).getAListGenres().size();y++){
				if(movies.get(x).getStrGenres(y).equals("Crime")){
					cont++;
				}
				if(movies.get(x).getStrGenres(y).equals("Thriller")){
					cont++;
				}
				if(cont==2){
					l.add(movies.get(x).getTitle());
				}
			}
		}
		FuenteDeDatos.escribirArchivo("B.txt", l, true);
	}
	public void listarAñoEspecifico(){
		List<String> l=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		String respuesta="";
		String temp;
		try{
			System.out.println("Ingrese un año de referencia para buscar película");
			respuesta=sc.nextLine();
		}
		catch(Exception e){
			System.out.println("Error");
		}
                for(int x=0;x<movies.size();x++){
			st2=new StringTokenizer(movies.get(x).getTitle(), "[]");
			if(st2.hasMoreElements()){
				temp=st2.nextToken();
				if(respuesta.equals(st2.nextToken())){
					l.add(movies.get(x).getTitle());
				}
			}
		}
		FuenteDeDatos.escribirArchivo("C.txt", l, true);
	}
	public void listarRatingEspecifico(){
		List<String> l=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		float respuesta=0;
		float temp=0;
		try{
			System.out.println("Ingrese un Rating");
			respuesta=sc.nextFloat();
		}
		catch(Exception e){
			System.out.println("Error");
		}
		for(int x=0;x<ratings.size();x++){
			 temp=Float.parseFloat(ratings.get(x).getRating());
			if(temp>=respuesta){
				l.add(movies.get(x).getTitle());
			}
		}
		FuenteDeDatos.escribirArchivo("D.txt", l, true);
	}
}