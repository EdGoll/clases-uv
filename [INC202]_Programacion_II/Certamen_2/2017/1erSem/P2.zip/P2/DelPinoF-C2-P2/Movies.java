import java.util.ArrayList;
import java.util.List;

public class Movies {
	private String MovieId;
	private String Title;
	private String Genres;

//	public Movies(){};

	public String getMovieId(){
		return MovieId;
	}
	public String getTitle(){
		return Title;
	}
	public String getGenres(){
		return Genres;
	}
	public void setMovieId(String MovieId){
		this.MovieId = MovieId;
	}
	public void setTitle(String Title){
		this.Title = Title;
	}
	public void setGenres(String Genres){
		this.Genres = Genres;
	}
	public Movies (String MovieId, String Title, String Genres){
		this.MovieId = MovieId;
		this.Title = Title;
		this.Genres = Genres;
	}
}

