import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;

public class Lista{
	private List<Movies> movie;
	private List<Rating> rating;
	public Lista(){
		movie = new ArrayList<>();
		rating = new ArrayList<>();
		CargarPeliculas();
                CargarRating();
	}
	private void CargarPeliculas(){
            List <String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
            String [] A;
            Movies J;
            for(String l : lineas){
		A  = l.split(";");
		J = new Movies(A[0], A[1], A[2]);
		movie.add(J);
            }
        }
        public void GeneroAdventure() {
            List <String> lista = new ArrayList<>();
            for(Movies m : movie){
                String[] genero = m.getGenres().split("\\|");
                if(m.getGenres().contains("Adventure")){
                    lista.add("Adventure Movies: "+m.getTitle()+m.getGenres());
                    FuenteDeDatos.escribirArchivo("Fernando.txt", lista, true);
                    //System.out.println(m.getMovieId() + m.getTitle() + m.getGenres());
                }
            }
        }
        public void GeneroThrilleryCrime(){
            List <String> lista = new ArrayList<>();
            for(Movies m: movie){
                String[] genero = m.getGenres().split("\\|");
                if(m.getGenres().contains("Thriller")){
                    if(m.getGenres().contains("Crime")){
                        lista.add("T&C Movies: "+m.getTitle()+m.getGenres());
                        FuenteDeDatos.escribirArchivo("Fernando.txt", lista, true);
                       // System.out.println(m.getMovieId() + m.getTitle() + m.getGenres());
                    }
                }
            }
        }
        public void AnioPelicula(){
            List <String> lista = new ArrayList<>();
            List <String> st = new ArrayList<>();
            Scanner sc = new Scanner(System.in);
            String Anio;
            System.out.print("Ingrese el año de las peliculas que busca: ");
            Anio = sc.nextLine();
            for(Movies m : movie){
                if(m.getTitle().contains(Anio)){
                    lista.add(m.getTitle());
                    FuenteDeDatos.escribirArchivo("Fernando.txt", lista, true);
                }
            }
        }
        public void CargarRating(){
            
            List <String> tineas = FuenteDeDatos.leerArchivo("ratings.csv");
            String [] B;
            Rating W;
            for(String k : tineas){
		B = k.split(";");
		W = new Rating(B[0], B[1], B[2]);
		rating.add(W);
                //System.out.println(W.getMovieId());
            }
        }
}/*
        public void RatingPeliculas(){
            List<String> st = new ArrayList<>();
            Scanner sc = new Scanner(System.in);
            Double ratingg;
            String PeliculaId;
            System.out.print("Ingrese el rating de peliculas que busca: ");
            ratingg = sc.nextDouble();
            for(Rating r : rating){
                if(ratingg <= Double.parseDouble(r.getRating())){
                    PeliculaId = r.getMovieId();
                        System.out.println(PeliculaId);//r.getUserId() + r.getMovieId() + r.getRating());
                        //for(Movies m : movie){
                        //System.out.println(r.getUserId() + r.getMovieId() + r.getRating());
                        //System.out.println("---" + m.getMovieId());
                        }
                    }
                }
            }
        
                   // if(r.getMovieId().equals(m.getMovieId())){
                   /* //String id = r.getMovieId();
                    float ratin;
                    try {
                        ratin = Float.parseFloat(r.getRating());

                   //System.out.println(ratingg);
                         if((ratin >= (ratingg))){
                            System.out.println(m.getMovieId()) ;
                         /*
                            PeliculaId = r.getRating();
                            System.out.println(PeliculaId + "--" + id +"--");
                            for(Movies m: movie){
                                if(id == m.getMovieId()){
                                    System.out.println(m.getMovieId());// +" ___ "+m.getMovieId());
                            //for(Movies m : movie){
                           // if(r.getMovieId().equals(m.getMovieId())){

                                }
                            }
                         
                    
                    
                
                catch (NumberFormatException e) {
                    System.out.println("numberStr is not a number");
                }
                //String reitin = (r.getRating());
                //float ratin = Float.parseFloat(reitin);
                //if(ratin >= (ratingg)){
                  ////    System.out.println(m.getMovieId() + m.getTitle() + m.getGenres());
                    //}
                //}
                }
*/

        

