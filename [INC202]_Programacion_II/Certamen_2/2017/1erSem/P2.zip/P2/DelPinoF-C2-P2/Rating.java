import java.util.ArrayList;
import java.util.List;

public class Rating {
	private String UserId;
	private String MovieId;
	private String Rating;

//	public Movies(){};

	public String getUserId(){
		return UserId;
	}
	public String getMovieId(){
		return MovieId;
	}
	public String getRating(){
		return Rating;
	}
	public void setUserId(String UserId){
		this.UserId = UserId;
	}
	public void setMovieId(String MovieId){
		this.MovieId = MovieId;
	}
	public void setRating(String Rating){
		this.Rating = Rating;
	}
        public Rating (String UserId, String MovieId, String Rating){
		this.UserId = UserId;
		this.MovieId = MovieId;
		this.Rating = Rating;
                
	}
}