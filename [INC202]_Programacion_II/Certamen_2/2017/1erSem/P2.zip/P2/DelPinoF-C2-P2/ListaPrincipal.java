public class ListaPrincipal {
	public static void main(String [] args) {
		Lista p1 = new Lista();
		p1.GeneroAdventure();
        p1.GeneroThrilleryCrime();
        p1.AnioPelicula();
    }
}