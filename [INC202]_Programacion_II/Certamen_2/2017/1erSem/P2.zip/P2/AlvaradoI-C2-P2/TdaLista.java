import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class TdaLista {
    private List<Peliculas> movie;
    public TdaLista(){
        movie = new ArrayList<>();
        cargar();
    }
    
    private void cargar(){
		List<String> lines = FuenteDeDatos.leerArchivo("movies.csv");
		Peliculas lista ;
		StringTokenizer band;
		lines.remove(0);
		for(String l: lines){
			band = new StringTokenizer(l,";");
			if(band.hasMoreTokens()){
				lista = new Peliculas (band.nextToken(), band.nextToken(), band.nextToken());
				movie.add(lista);
			}
		}
    }
    public void PeliculasAventura(){
        List<String> adventure = new ArrayList<>();
        String nameMovie;
        adventure.add("Peliculas de Aventura :");
        adventure.add("");
        for(Peliculas p : movie){
            if(p.getGenresMovie().contains("Adventure")){
                nameMovie = p.getTittleMovie();
                adventure.add(nameMovie);
        } 
        }
        FuenteDeDatos.escribirArchivo("Lista_de_peliculas.txt", adventure, true);
}
    public void PeliculasCrimenThriller(){
        List<String> crimenThriller = new ArrayList<>();
        String namesMovie;
        crimenThriller.add("Peliculas de Crimen y Thriller :");
        for(Peliculas p : movie){
            if(p.getGenresMovie().contains("Crime|Thriller")){
                namesMovie = p.getTittleMovie();
                crimenThriller.add(namesMovie);
        }
        }
        FuenteDeDatos.escribirArchivo("Lista_de_peliculas.txt", crimenThriller, true);
}
    public void PeliculasA�o(String anio1) {
       List<String> year = new ArrayList<>();
       String yearMovie;
       year.add("Peliculas del a�o  "+ anio1 +" :  ");
       for(Peliculas p : movie) {
           if(p.getTittleMovie().contains(anio1)) {
               yearMovie = p.getTittleMovie();
               year.add(yearMovie);
           }
       }
    FuenteDeDatos.escribirArchivo("Lista_de_peliculas.txt", year, true);   
    }
}