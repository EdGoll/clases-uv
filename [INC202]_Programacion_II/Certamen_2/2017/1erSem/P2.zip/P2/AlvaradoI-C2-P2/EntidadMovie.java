public class EntidadMovie {
    private String idMovie;
    private String tittleMovie;
    private String genresMovie;
    
    public EntidadMovie() {
    }
    
    public EntidadMovie(String idMovie, String tittleMovie, String genresMovie) {
    this.idMovie = idMovie;
    this.tittleMovie = tittleMovie;
    this.genresMovie = genresMovie;
    }


    public String getIdMovie() {
        return idMovie;
    }

    public String getTittleMovie() {
        return tittleMovie;
    }

    public String getGenresMovie() {
        return genresMovie;
    }

    public void setIdMovie(String idMovie) {
        this.idMovie = idMovie;
    }

    public void setTittleMovie(String tittleMovie) {
        this.tittleMovie = tittleMovie;
    }


    public void setGenresMovie(String genresMovie) {
        this.genresMovie = genresMovie;
    }
}
