import java.util.Scanner;
public class PeliculasImp{
public static void main(String [] args){
        Scanner entrada = new Scanner(System.in);
	TdaLista pelis = new TdaLista();
        pelis.PeliculasAventura();
        pelis.PeliculasCrimenThriller();
        System.out.println("Ingrese el ano que quiera buscar = ");
        String anio = entrada.next();
        pelis.PeliculasAnio(anio);
}
}