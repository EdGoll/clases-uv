public class EntidadRating {
    private int rating;
    private String idMovie2;
    private int idUser;
    
    public EntidadRating(){}
    
    public EntidadRating(int rating, String idMovie2, int idUser){
        this.rating = rating;
        this.idMovie2 = idMovie2;
        this.idUser = idUser;

    }

    public int getRating() {
        return rating;
    }

    public String getIdMovie2() {
        return idMovie2;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }


    public void setIdMovie2(String idMovie2) {
        this.idMovie2 = idMovie2;
    }


    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }
    
    
}