import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Lista {
	private static List<Muvie> pelis;
	private static List<Rating> estadis;
	private static String name;


	public static void nombreArchivo(String name){
		Lista.name = name;
	}
	
	public static void datos(String ruta1, String ruta2){
		ratingsPelis(ruta2);
		Peliculas(ruta1);

	}
	
	private static void Peliculas(String ruta){
		pelis = new ArrayList<>();
		List<String> lineas = FuenteDeDatos.leerArchivo(ruta);
		StringTokenizer st;
		Muvie pelicula;
		
		int k = 0;
		String genero,name,anio;
		String[] AUX;
		for(String i : lineas){
			if(k!=0){
				pelicula = new Muvie();
				st = new StringTokenizer(i,";");
				
				pelicula.setMuvieId(Integer.parseInt(st.nextToken()));
				name = st.nextToken();
				if(name.contains("(") && name.contains(")")){
					AUX = name.split(" ");
					anio = AUX[AUX.length-1].substring(1,AUX[AUX.length-1].length()-1);
					pelicula.setAnio(anio);
				} 
				pelicula.setTitle(name);
				
				genero = st.nextToken();
				if(genero.contains("|")){
					st = new StringTokenizer(genero,"|");
					while(st.hasMoreTokens()){
						pelicula.setGenres(st.nextToken());
					}
				}else pelicula.setGenres(genero);
	
				
				pelis.add(pelicula);
				
			}else k++;
		}
		boolean encont;
		for(Muvie j : pelis){
			for(Rating p : estadis){
				if(p.getMuvieId().contains(j.getMuvieId())){
					encont = false;
					k=0;
					while(!encont){
						if(j.getMuvieId() == p.getMuvieId().get(k)){
							encont = true;
							j.setRatings(p.getRating().get(k));
						}
						k++;
					}
				}
			}
		}

	}
	
	private static void ratingsPelis(String ruta){
		estadis = new ArrayList<>();
		List<String> lineas = FuenteDeDatos.leerArchivo(ruta);
		StringTokenizer st;
		Rating rat;
		boolean repeat;
		int k = 0;
		for(String i : lineas){
			if(k!=0){
				repeat= false;
				k=0;
				st = new StringTokenizer(i,";");
				
				rat = new Rating();
				rat.setUserId(Integer.parseInt(st.nextToken()));
				rat.setMuvieId(Integer.parseInt(st.nextToken()));
				rat.setRating(Float.parseFloat(st.nextToken()));
				
				
				while(!repeat && k<estadis.size()){
					if(estadis.get(k).equals(rat)) repeat = true;
					else k++;
				}
				if(!repeat) estadis.add(rat);	
			} 
			k++;
		}
		
		
	}
	
	
	public static void genAdven(){
		
		String genero = "Adventure";
		List<String> lineas = new ArrayList<>();
		lineas.add("\nPELICULAS DE GENERO ADVENTURE:\n\n");
		for(Muvie i : pelis){
			if(i.getGenres().contains(genero)){
				lineas.add(i.getTitle());
			}
		}
		FuenteDeDatos.escribirArchivo(name, lineas, false);

	}
	
	public static void genThiyCr(){
		String[] generos = {"Thriller","Crime"};
		List<String> lineas = new ArrayList<>();
		
		lineas.add("\nPELICULAS DE GENERO THRILLER Y CRIME:\n\n");

		for(Muvie i : pelis){
			if(i.getGenres().contains(generos[0]) && i.getGenres().contains(generos[1])){
				lineas.add(i.getTitle());
			}
		}
		FuenteDeDatos.escribirArchivo(name, lineas, true);

	}
	
	public static void pelisAnio(){
		String anio;
		
		System.out.println("\nINGRESA EL ANO: ");
		anio = new Scanner(System.in).next();
		List<String> lineas = new ArrayList<>();
		
		lineas.add("\nPELICULAS CON EL ANO INGRESADO:\n\n");

		for(Muvie i : pelis){
			if(i.getAnio()!=null){
				if(i.getAnio().equals(anio)){
					lineas.add(i.getTitle());
				}
			}
		}
		FuenteDeDatos.escribirArchivo(name, lineas, true);
		
	}
	
	public static void ratingsMay(){
		List<String> lineas = new ArrayList<>();
		float num = 5;
		boolean esta;
		int k;
		
		lineas.add("\nPELICULAS CON RATING MAYOR O IGUAL AL VALOR INGRESADO:\n\n");

		for(Muvie i : pelis){
			if(i.getRatings().size()!=0){
				esta = false;
				k=0;
				while(k<i.getRatings().size()-1 && !esta){
					if(num <= i.getRatings().get(k)){
						lineas.add(i.getTitle());
						esta=true;

					}
					k++;
				}
			}
		}
		FuenteDeDatos.escribirArchivo(name, lineas, true);
	}
	
	public static void ratingCateg(){
		List<String> lineas = new ArrayList<>();
		float num = 3;
		boolean esta;
		int k;
		lineas.add("\nPELICULAS CON RATING MAYOR O IGUAL AL VALOR INGRESADO Y DE GENERO COMEDY:\n\n");
		String categoria = "Comedy";
		for(Muvie i : pelis){
			if(i.getRatings().size()!=0 && i.getGenres().size()==1){
				esta = false;
				k=0;
				while(k<i.getRatings().size()-1 && !esta){
					if(num <= i.getRatings().get(k) && i.getGenres().get(0).equals(categoria)){

						lineas.add(i.getTitle());
						esta=true;
					}
					k++;
				}
			}
		}
		FuenteDeDatos.escribirArchivo(name, lineas, true);
	}
}
