import java.util.ArrayList;
import java.util.List;

public class Rating {
	private int userId;
	private List<Integer> muvieId;
	private List<Float> rating;

	public Rating(){
		userId = 0;
		muvieId = new ArrayList<>();
		rating = new ArrayList<>();
	}
	
	public Rating(int userId, ArrayList<Integer> muvieId, ArrayList<Float> rating){
		this.userId = userId;
		this.muvieId = muvieId;
		this.rating = rating;	
	}
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int user) {
		this.userId = user;
	}

	public List<Integer> getMuvieId() {
		return muvieId;
	}

	public void setMuvieId(int muvieId) {
		this.muvieId.add(muvieId);
	}

	public List<Float> getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating.add(rating);
	}
	
	@Override
	public boolean equals(Object rating2){
		if(rating2 instanceof Rating){
			Rating rat2 = (Rating)rating2;
			if(rat2.getUserId() == this.getUserId()){
				this.setRating(rat2.getRating().get(0));
				this.setMuvieId(rat2.getMuvieId().get(0));
				return true;
			}
		}
		
		return false;
	}

}
