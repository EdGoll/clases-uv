public class ClasePrincipal {
		public static void main(String args[]){
			String peliculas = "movies.csv";
			String ratings = "ratings.csv";
			
			Lista.nombreArchivo("Certamen2.txt");
			Lista.datos(peliculas, ratings);

			Lista.genAdven();
			Lista.genThiyCr();
			Lista.pelisAnio();
			Lista.ratingCateg();
			Lista.ratingsMay();
		}
}
