import java.util.ArrayList;
import java.util.List;

public class Muvie {
	private int muvieId;
	private String anio;
	private String title;
	private List<String> genres;
	private List<Float> ratings;
	
	public Muvie(){
		title = anio = null;
		ratings = new ArrayList<>();
		genres = new ArrayList<>();
		muvieId = 0;
	}
	
	public Muvie(int muvieId, String anio, String title, ArrayList<String> genres, ArrayList<Float> ratings){
		this.muvieId = muvieId;
		this.anio = anio;
		this.title = title;
		this.genres = genres;
		this.ratings = ratings;
	}

	public int getMuvieId() {
		return muvieId;
	}

	public void setMuvieId(int muvieId) {
		this.muvieId = muvieId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<String> getGenres() {
		return genres;
	}

	public void setGenres(String genres) {
		this.genres.add(genres);
	}

	public String getAnio() {
		return anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public List<Float> getRatings() {
		return ratings;
	}

	public void setRatings(float ratings) {
		this.ratings.add(ratings);
	}

}
