
/**
 *
 * @author andreszapata
 */
public class Rating {
    private int userid;
    private String movieid;
    private float rating;

    public Rating(int userid, String movieid, float rating) {
        this.userid = userid;
        this.movieid = movieid;
        this.rating = rating;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getMovieid() {
        return movieid;
    }

    public void setMovieid(String movieid) {
        this.movieid = movieid;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
    
}
