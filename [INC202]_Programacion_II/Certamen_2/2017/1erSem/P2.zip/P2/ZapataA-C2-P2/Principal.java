
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author andreszapata
 */
public class Principal {
    public static void main(String[] args) {
        Lista l = new Lista();
        
        Scanner s = new Scanner(System.in);
        List<String> generos = new ArrayList();
        
        generos.add("Adventure");
        System.out.println("Filtrando peliculas Adventure...");
        l.getResultados(l.busquedaGenero(generos));
        generos.remove(0);
        
        generos.add("Thriller");
        generos.add("Crime");
        System.out.println("Filtrando peliculas Thriller-Crime...");
        l.getResultados(l.busquedaGenero(generos));
        generos.remove(0);
        generos.remove(0);
        
        System.out.print("Escriba el año que quiere filtrar: ");
        l.getResultados(l.busquedaAno(s.nextInt()));
        
        System.out.print("Escriba el rating que quiere filtrar: ");
        l.getResultados(l.busquedaRating(s.nextFloat()));
        
        generos.add("Comedy");
        System.out.print("Escriba el rating que quiere filtrar con Comedia: ");
        l.getResultados(l.compararlistas(l.busquedaGenero(generos), s.nextFloat()));
    }
}
