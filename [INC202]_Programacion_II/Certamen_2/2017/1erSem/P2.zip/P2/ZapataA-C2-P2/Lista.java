
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Lista {
    private List<Rating> listaRatings = new ArrayList();
    private List<Movie> listaPeliculas = new ArrayList();

    public Lista() {
        crearListaRatings();
        crearLista();
    }



    public void crearListaRatings(){
        List<String> lineas = FuenteDeDatos.leerArchivo("ratings.csv");
        Rating r;
        String[] arreglolinea;
        for(int i = 1; i<lineas.size();i++){
                String linea = lineas.get(i);
                arreglolinea = linea.split(";");
                int x = Integer.parseInt(arreglolinea[0]);
                String y = arreglolinea[1];
                float z = Float.parseFloat(arreglolinea[2]);
                r = new Rating(x, y, z);
                listaRatings.add(r);
        }
    }

    public void crearLista(){
        List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
        Movie m;
        String[] arreglolinea;
        int nume=0;
        for(String linea : lineas){
                arreglolinea = linea.split(";");
                String[] x = arreglolinea[2].split("\\|");
                List listgen = new ArrayList(Arrays.asList(x));

                float promedio_rating=0;
                int contador=0;
                Rating g;
                for(int i=0; i<listaRatings.size(); i++){
                    g = listaRatings.get(i);
                    if(arreglolinea[0].equals(g.getMovieid())){
                        promedio_rating = promedio_rating + g.getRating();
                        contador++;
                    }
                }

                float promedio = (promedio_rating/contador);

                m = new Movie(arreglolinea[0], arreglolinea[1], listgen, promedio);
                System.out.println("Cargando Pelicula "+nume);
                listaPeliculas.add(m);
                nume++;
        }

    }

    public List<Movie> busquedaGenero(List genero){
        List<Movie> nuevalista = new ArrayList();
        int contador=0;

        for(int j=0; j<listaPeliculas.size();j++){
            Movie pelicula = listaPeliculas.get(j);
            List lista_temporal = pelicula.getGenre();
            int bandera = 0;

            for(int i = 0; i < lista_temporal.size() ;i++){
                for(int k=0; k<genero.size();k++){
                    if ((lista_temporal.get(i)).equals(genero.get(k))){
                        bandera++;
                    }
                }
            }

            if(bandera == genero.size()){
                contador++;
                nuevalista.add(pelicula);
            }
        }

        String nombre_archivo = "";
        for(int s=0 ; s < genero.size(); s++){
            nombre_archivo = nombre_archivo + genero.get(s);
        }
        return nuevalista;
    }

    public List<Movie> busquedaAno(int ano){
        //List<String> listaAno = new ArrayList();
        List<Movie> nuevalista = new ArrayList();
        int contador=0;
        for(int j=0; j<listaPeliculas.size();j++){
            Movie pelicula = listaPeliculas.get(j);

            String[] partes = pelicula.getTitle().split(" ");
            String x = partes[(partes.length - 1)].replace('(',' ');
            x = x.replace(')',' ');
            x = x.trim();
            try{
                int year = Integer.parseInt(x);

                if(ano == year){
                    contador++;
                    nuevalista.add(pelicula);
                }
            }
            catch(java.lang.NumberFormatException n){
            }

        }
    return nuevalista;
    }

    public List<Movie> busquedaRating(float rate){
        List<Movie> nuevalista = new ArrayList();
        Movie m;
        for(int i=0; i<listaPeliculas.size();i++){
            m = listaPeliculas.get(i);

            if(rate <= m.getRating()){
                nuevalista.add(m);
            }

        }

        return nuevalista;
    }

    public List<Movie> compararlistas(List<Movie> genero, float rate){
        List<Movie> nuevalista = new ArrayList();

        Movie m;

        for(int i=0; i < genero.size(); i++){
            m = genero.get(i);

            if(rate <= m.getRating()){
                nuevalista.add(m);
            }

        }


        return nuevalista;
    }

    public void getResultados(List<Movie> lista){
        List<String> nuevalista = new ArrayList();
        Movie m;
        for(int i=0; i<lista.size(); i++){
            m = lista.get(i);
            nuevalista.add(m.getMovieid()+";"+m.getTitle()+";"+m.getRating());
        }
        FuenteDeDatos.escribirArchivo("Resultados.txt", nuevalista, true);
        System.out.println("Los resultados se han archivado en Resultados.txt");
    }
}
