import java.util.ArrayList;
import java.util.List;


public class Movie {
    private String movieid;
    private String title;
    private List<String> genre;
    private float rating;

    public Movie(String movieid, String title, List<String> genre, float rating) {
        this.movieid = movieid;
        this.title = title;
        this.genre = genre;
        this.rating = rating;
    }
    
    
    public String getMovieid() {
        return movieid;
    }

    public void setMovieid(String movieid) {
        this.movieid = movieid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getGenre() {
        return genre;
    }

    public void setGenre(List<String> genre) {
        this.genre = genre;
    }
    
    public float getRating() {
        return rating;
    }
    
    public void setRating(float rating){
        this.rating = rating;
    }
}
