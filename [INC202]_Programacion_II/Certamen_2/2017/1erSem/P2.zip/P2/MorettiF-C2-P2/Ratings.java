
package claseprincipal;


public class Ratings {
    private String userId;
    private String movieID;
    private String rating;
    
    public Ratings(){}

    public Ratings(String userId, String movieId, String rating) {
        this.userId = userId.trim();
        this.movieID = movieId.trim();
        this.rating = rating.trim();
    }

    public String getUserId() {
        return userId;
    }

    public String getMovieID() {
        return movieID;
    }

    public String getRating() {
        return rating;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setMovieID(String movieID) {
        this.movieID = movieID;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
    
}
