
package claseprincipal;

public class Movie {
    private String movieId;
    private String title;
    private String generes;
    
    public Movie() {}
    
    public Movie(String movieId, String title, String generes) {
    this.movieId = movieId.trim();
    this.title = title.trim();
    this.generes = generes.trim();
    }


    public String getMovieId() {
        return movieId;
    }

    
    public String getTitle() {
        return title;
    }

    
    public String getGeneres() {
        return generes;
    }

    
    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

   
    public void setTitle(String title) {
        this.title = title;
    }

    
    public void setGeneres(String generes) {
        this.generes = generes;
    }
    
}
