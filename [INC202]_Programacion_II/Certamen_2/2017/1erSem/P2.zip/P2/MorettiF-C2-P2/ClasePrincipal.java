
package claseprincipal;

import java.util.Scanner;

public class ClasePrincipal {

    
    public static void main(String[] args) {
        
        Peliculas a = new Peliculas();
        a.Adventure();            //Parte a
        a.CrimeAndThriller();     //Parte b
        


        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el año de estreno de Peliculas a mostrar: ");      //Parte c
        String c = sc.nextLine();
        a.AnioIngresado(c);


        
        Scanner cs = new Scanner(System.in);
        System.out.println("Ingrese nivel de Rating de las Peliculas a mostrar: ");     //Parte d
        String x = cs.nextLine();
        a.RatingDelUsuario(x);


        
        Scanner st = new Scanner(System.in);
        System.out.println("Ingrese nivel de Rating para las Peliculas de genero Comedy a mostrar");    //Parte e
        String z = st.nextLine();
        a.RatingsDeComedias(z);
    }
    
}
