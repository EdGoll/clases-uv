
package claseprincipal;

import java.util.List;
import java.util.ArrayList;


public class Peliculas {
    private List<Movie> movie;
    private List<Ratings> ratings;
    
    public Peliculas(){
        movie = new ArrayList<>();
        ratings = new ArrayList<>();
        cargaPeliculas();
        cargaRatings();
    }
    

    private void cargaPeliculas(){

	//Se carga las Peliculas
	List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
	Movie m;
	String[] dato;
	lineas.remove(0);
	for(String l: lineas){
		dato = l.split(";");
		m = new Movie (dato[0], dato[1], dato[2]);
		movie.add(m);	
        }
    }
    	
    private void cargaRatings(){     //Se carga los Ratings
        List<String> lineas = FuenteDeDatos.leerArchivo("ratings.csv");
	Ratings r;
	String[] datos;
	lineas.remove(0);
	for(String l: lineas){
		datos= l.split(";");
		r = new Ratings (datos[0], datos[1], datos[2]);
		ratings.add(r);	
        }
        
    } 
            

    
    
    
    public void Adventure(){  //Parte a:
       
        List<String> adventure = new ArrayList<>();
        String nombre;
        adventure.add("Peliculas con genero Adventure:  \n");
        
        for(Movie m : movie){
            if(m.getGeneres().contains("Adventure")){      //Peliculas de genero Adventure
                nombre = m.getTitle();
                adventure.add(nombre);
                
            } 
        }
        FuenteDeDatos.escribirArchivo("Archivo_De_Resultados.txt", adventure, true);   //Se guarda en un archivo de texto 
        
    }
    
    



    public void CrimeAndThriller(){ //Parte b:
        
        List<String> crime = new ArrayList<>();
        String nombre;
        crime.add("\n");
        crime.add("Peliculas de genero Thriller y Crime: \n");
        
        for(Movie m : movie){
            if(m.getGeneres().contains("Crime") && m.getGeneres().contains("Thriller")){  //Peliculas que contengan esos generos
            nombre = m.getTitle();
            crime.add(nombre);
        }
        }
        FuenteDeDatos.escribirArchivo("Archivo_De_Resultados.txt", crime, true);       //Se guarda en el archivo de texto
        
}
    
    



    
    public void AnioIngresado(String c) { //Parte c:
        List<String> anio = new ArrayList<>();
       String nombre;
       String l;
       String[] dato;
       anio.add("\n");
       anio.add("Peliculas del año ingresado: \n");
       
       for(Movie m : movie){
           if(m.getTitle().contains(c)){
               l = m.getTitle();		//Se guarda el nombre de la Pelicula con el año
               dato = l.split("(");		//Se separa el nombre para luego guardarlo
               nombre = dato[0];
               anio.add(nombre);               
           }
       }
    FuenteDeDatos.escribirArchivo("Archivo_De_Resultados.txt", anio, true);  //Se guarda en el archivo de texto
    }
    
    
    



    
    public void RatingDelUsuario(String x) {         //Parte d
       List<String> usuario = new ArrayList<>();
       String ID;
       String Titulo;
       usuario.add("");
       usuario.add("Peliculas con Rating especificado: \n");
       
       for(Ratings r : ratings) {
           if(Integer.parseInt(r.getRating()) >= Integer.parseInt(x)){      //Ratings especificado
               ID = r.getMovieID();		//Se obtiene el ID de la pelicula
               for(Movie m : movie) {
                    if(m.getMovieId().equals(ID)){
                        Titulo = m.getTitle();			//Titulo de la pelicula
                        usuario.add(Titulo);
                    }
                }    
            }
        }
    FuenteDeDatos.escribirArchivo("Archivo_De_Resultados.txt", usuario, true);      //Se guarda en el archivo de texto
    }






    public void RatingsDeComedias(String z) {       //Parte e:
        List<String> comedy = new ArrayList<>();
        String ID;
        String Titulo;
        comedy.add("");
        comedy.add("Peliculas de genero Comedy con Rating especificado: \n");

        for(Ratings r : ratings) {
            if(Integer.parseInt(r.getRating()) >= Integer.parseInt(z)){             //Ratings mayores o igual al ingresado
                ID = r.getMovieID();
                for(Movie m : movie) {
                    if((m.getMovieId().equals(ID)) && (m.getGeneres().contains("Comedy"))){    //Peliculas Comedy con Rating especificado
                            Titulo = m.getTitle();
                            comedy.add(Titulo);
                    }
                }
            }

        }

	FuenteDeDatos.escribirArchivo("Archivo_De_Resultados.txt", comedy, true);      //Se guarda en el archivo de texto
    }
    
}