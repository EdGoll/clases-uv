package prueba2;

public class Movies{
	private String movieId;
	private String nombre;
	private String genero;

	public Movies(){

	}
	public Movies(String movieId, String nombre, String genero){
		this.movieId = movieId.trim(); 
		this.nombre = nombre.trim();
		this.genero = genero.trim();
	}

	public void setMovieId(String movieId){
		this.movieId = movieId;
	}
	public void setNombre(String nombre){
		this.nombre = nombre;
	}
	public void setGenero(String genero){
		this.genero = genero;
	}
	public String getMovieId(){
		return movieId;
	}
	public String getNombre(){
		return nombre;
	}
	public String getGenero(){
		return genero;
	}
}
