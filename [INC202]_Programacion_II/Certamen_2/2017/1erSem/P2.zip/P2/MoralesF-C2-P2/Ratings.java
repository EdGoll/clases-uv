package prueba2;

public class Ratings{
	private String userId;
	private String movieId;
	private String rating;

	public Ratings(){}

	public Ratings(String userId, String movieId, String rating){
		this.userId = userId.trim();
		this.movieId = movieId.trim();
		this.rating = rating.trim();
	}

	public void setUserId(String userId){
		this.userId = userId;
	}
	public void setMovieId(String movieId){
		this.movieId = movieId;
	}
	public void setRating(String rating){
		this.rating = rating;
	}
	public String getUserId(){
		return userId;
	}
	public String getMovieId(){
		return movieId;
	}
	public String getRating(){
		return rating;
	}
}