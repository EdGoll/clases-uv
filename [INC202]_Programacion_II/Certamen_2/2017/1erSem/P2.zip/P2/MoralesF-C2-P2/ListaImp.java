package prueba2;

//import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListaImp{
	
	public static void main(String [] args) {
		Lista peliculasF = new Lista();
		System.out.println("Buenas usuario, a iniciado el programa Lista.");
		System.out.println("Ingrese el nombre del archivo en el cual quiere escribir las listas");
		Scanner lector1 = new Scanner(System.in);
		String nombreEscritura = lector1.nextLine();
		//lector1.close();
		List<String> a = peliculasF.aventuras();
		List<String> b = peliculasF.trillerYcrime();
		
		System.out.print("Ingrese el ano que quiere usar para la pregunta C: ");
		Scanner lector2 = new Scanner(System.in);
		String fecha = lector2.nextLine();
		List<String> c = peliculasF.fechaPelicula(fecha);
		
		System.out.println("Ingrese el rating que quiere usar para la pregunta D: ");
		Scanner lector3 = new Scanner(System.in);
		float rating1 = lector3.nextFloat();
		//lector3.close();
		List<String> d = peliculasF.ratingS(rating1);
		
		System.out.println("Ingrese el rating que quiere usar para la pregunta E: ");
		Scanner lector4 = new Scanner(System.in);
		float rating2 = lector4.nextFloat();
		//lector4.close();
		List<String> e = peliculasF.ratingSs(rating2);
		
		List<String> peli = peliculasF.escrituraArchivo(a, b, c, d, e);
		
		FuenteDeDatos.escribirArchivo(nombreEscritura, peli, true);
		lector1.close();
		lector2.close();
		lector3.close();
		lector4.close();
		
	}
}
