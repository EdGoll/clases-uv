package prueba2;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
//import java.util.Scanner;

public class Lista{
	private List<Movies> pelicula;
	private List<Ratings> rating;

	public Lista(){
		pelicula = new ArrayList<>();
		rating = new ArrayList<>();
		mapear();
	}
	
	private void mapear(){
		List<String> lineas1 = FuenteDeDatos.leerArchivo("C:\\Users\\felipe\\Desktop\\FELIPE\\Programacion\\prueba\\movies.csv");
		List<String> lineas2 = FuenteDeDatos.leerArchivo("C:\\Users\\felipe\\Desktop\\FELIPE\\Programacion\\prueba\\ratings.csv");
		Movies m;
		Ratings r;
		StringTokenizer st1;
		StringTokenizer st2;
		lineas1.remove(0);
		lineas2.remove(0);
		for(String l : lineas1){
			st1 = new StringTokenizer(l,";");
			if(st1.hasMoreTokens()){
				m = new Movies (st1.nextToken(), st1.nextToken(), st1.nextToken());
				pelicula.add(m);
			}
		}
		for(String l : lineas2){
			st2 = new StringTokenizer(l,";");
			if(st2.hasMoreTokens()){
				r = new Ratings (st2.nextToken(), st2.nextToken(), st2.nextToken());
				rating.add(r);
			}
		}
	}

	public List<String> aventuras(){
		
		ArrayList<String> listado1 = new ArrayList<>();
		for(Movies p : pelicula){
			if((p.getGenero().indexOf("Adventure") - 1) != 0){
				listado1.add(p.getNombre());
			}
		}
		return listado1;
	}

	public List<String> trillerYcrime(){
		ArrayList<String> listado2 = new ArrayList<>();
		for(Movies p : pelicula){
			if((p.getGenero().indexOf("Triller") - 1) != 0 && (p.getGenero().indexOf("Crime") - 1)!= 0){
				listado2.add(p.getNombre());
			}
		}
		return listado2;
	}

	public List<String> fechaPelicula(String fecha){
		ArrayList<String> listado3 = new ArrayList<>();
		for(Movies p : pelicula){
			if(p.getNombre().indexOf(fecha) != 0){
				listado3.add(p.getNombre());
			}
		}
		return listado3;
	}

	public List<String> ratingS(float rating1){
		ArrayList<String> listado4 = new ArrayList<>();
		for(Movies p : pelicula){
			for(Ratings t : rating){
				if(p.getMovieId().equals(t.getMovieId())){
					if(Float.parseFloat(t.getRating()) >= rating1){
						listado4.add(p.getNombre());
					}
				}	
			}
		}
		return listado4;
	}

	public List<String> ratingSs(float rating2){
		ArrayList<String> listado5 = new ArrayList<>();
		for(Movies p : pelicula){
			for(Ratings t : rating){
				if(p.getMovieId().equals(t.getMovieId())){
					if(Float.parseFloat(t.getRating()) >= rating2){
						if((p.getGenero().indexOf("Comedy") - 1) != 0){
							listado5.add(p.getNombre());
						}
					}
				}
			}
		}
		return listado5;
	}
	
	public List<String> escrituraArchivo(List<String> listado1, List<String> listado2, List<String> listado3, List<String> listado4, List<String> listado5){
		List<String> prueba = null;
		prueba = new ArrayList<>();
		for(int i = 0; i <= listado1.size(); i++){
			prueba.add(listado1.get(i));
		}
		for(int i = 0; i <= listado2.size(); i++){
			prueba.add(listado2.get(i));
		}
		for(int i = 0; i <= listado3.size(); i++){
			prueba.add(listado3.get(i));
		}
		for(int i = 0; i <= listado4.size(); i++){
			prueba.add(listado4.get(i));
		}
		for(int i = 0; i <= listado5.size(); i++){
			prueba.add(listado5.get(i));
		}
		return prueba;
	}
	
	
}
