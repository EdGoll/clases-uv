
//datos dentro del archivo ratings
public class Ratings {
	private String userld;
	private String movield;
	private String rating;
	
	public String getUserld(){
		return userld;
	}
	
	public void setUserld(String userld) {
		this.userld= userld;
	}
	
	public String getMovield(){
		return movield;
	}
	
	public void setMovield(String movield){
		this.movield= movield;
	}
	
	public String getRating(){
		return rating;
	}
	
	public void setRating(String rating){
		this.rating= rating;
	}

	@Override 
	public String toString(){
		return String.format(" (%s) %s %s ", userld, movield, rating);
		
	}

}
