import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.io.PrintWriter;
import java.io.File;
import java.io.BufferedReader;
import java.util.ArrayList;


public class Peliculas {

	//lectura del archivo movies 
	public static List<String> leerArchivo(String nombreArchivo){
		File file= null;
		FileReader fileReader = null;
		String linea= null;
		List<String> lineas = null;
		try{
			file= new File(nombreArchivo);
			fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			lineas = new ArrayList<>();
			while((linea = bufferedReader.readLine()) != null) {
				lineas.add(linea);
			}
		}
		catch (IOException ex){
			System.out.println(ex.getCause());
		} finally {
			if (fileReader != null){
				try{
					fileReader.close();
				} 
				catch(IOException ex){
					System.out.println(ex.getCause());
				}
			}
		}
		return lineas;
	}
	
	//escritura del archivo movies
	public static void escribirArchivo(String nombreArchivo, List<String> lineas, boolean opcion) {
		FileWriter fileWriter = null;
		PrintWriter printWriter = null;
		try{
			fileWriter = new FileWriter(nombreArchivo, opcion);
			printWriter = new PrintWriter(fileWriter);
			for (String linea : lineas) {
				printWriter.println(linea);
			}
		} catch(IOException ex){
			System.out.println(ex.getCause());
		} finally {
			try {
				fileWriter.close();
			} catch(IOException ex) {
				System.out.println(ex.getCause());
			}
		}
	}
	
	//lectura del archivo ratings
	public static List<String> leerArch(String nomArchivo){
		File file= null;
		FileReader fileReader = null;
		String linea= null;
		List<String> lin = null;
		try{
			file= new File(nomArchivo);
			fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			lin = new ArrayList<>();
			while((linea = bufferedReader.readLine()) != null) {
				lin.add(linea);
			}
		}
		catch (IOException ex){
			System.out.println(ex.getCause());
		} finally {
			if (fileReader != null){
				try{
					fileReader.close();
				} 
				catch(IOException ex){
					System.out.println(ex.getCause());
				}
			}
		}
		return lin;
	}
	
	//escritura del archivo reatings
	public static void escribirArch(String nomArchivo, List<String> lin, boolean opcion) {
		FileWriter fileWriter = null;
		PrintWriter printWriter = null;
		try{
			fileWriter = new FileWriter(nomArchivo, opcion);
			printWriter = new PrintWriter(fileWriter);
			for (String linea : lin) {
				printWriter.println(linea);
			}
		} catch(IOException ex){
			System.out.println(ex.getCause());
		} finally {
			try {
				fileWriter.close();
			} catch(IOException ex) {
				System.out.println(ex.getCause());
			}
		}
	}
	
}
