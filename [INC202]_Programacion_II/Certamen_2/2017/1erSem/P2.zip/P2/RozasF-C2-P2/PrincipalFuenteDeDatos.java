import java.util.List;

public class PrincipalFuenteDeDatos {
	public static void main(String[] args) {
		String nombreArchivo = "movies.txt";
		List<String> lineas= Peliculas.leerArchivo(nombreArchivo);
		Peliculas.escribirArchivo(nombreArchivo, lineas, false);
		
		String nomArchivo = "ratings.txt";
		List<String> lin= Peliculas.leerArch(nomArchivo);
		Peliculas.escribirArch(nomArchivo, lin, false);
	}

}
