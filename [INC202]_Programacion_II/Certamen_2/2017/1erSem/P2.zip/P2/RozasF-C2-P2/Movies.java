
// datos dentro del archivo movies
public class Movies {
	protected String movield;
	protected String title;
	protected String genres;
	
	public String getMovield(){
		return movield;
	}
	
	public void setMovield(String movield) {
		this.movield= movield;
	}
	
	public String getTitle(){
		return title;
	}
	
	public void setTitle(String title){
		this.title= title;
	}
	
	public String getGenres(){
		return genres;
	}
	
	public void setGenres(String genres){
		this.genres= genres;
	}

	@Override 
	public String toString(){
		return String.format(" (%s) %s %s ", movield, title, genres);
		
	}

	public static void add(Movies nuevoMovies) {
		
	}
}
