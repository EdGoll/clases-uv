import java.io.*;
import java.util.*;

// recorremos el archivo movies y guardamos el genero en una lista
public class Entidad {
	
	        List<Movies> listMovies = null;
	        File f = null;
	        FileReader fr =null;
	        BufferedReader br = null;
	        try {
	        f = new File ("movies.txt");
	        fr = new FileReader (f);
	        br = new BufferedReader (fr);
	        listMovies = new List<Movies> ();
	        String linea;
	        while ( (linea = br.readLine()) != null ) {
	            String[] partesDelString = linea.split("_");
	            String s = partesDelString[1];
	            Movies nuevoMovies = new Movies ();
	            Movies.add(nuevoMovies);
	        }
	        }
	        catch (FileNotFoundException fnfe) {System.out.println("error1"); } catch (IOException ioe) {System.out.println("error2");}
	        finally {
	            try{
	                if (fr != null)
	            fr.close();}
	            catch (IOException ioe) {System.out.println("error3");}
	            if (listMovies != null)
	            for (Movies movies : listMovies) {
	            System.out.println (" Nombre :   "+ movies.getGenres());
	        }
	        }
	    }
	}


