
public class Lista extends Movies {
	
	public Lista(){
		super.genres= genres;
		super.movield= movield;
		super.title= title;
		
	}

}
