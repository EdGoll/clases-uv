import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class ListaPeliculas {
    private List<Pelicula> peliculas;
    private List<Rating> ratings;
    private List<String> ejercicio1;
    private List<String> ejercicio2;
    private List<String> ejercicio3;
    private List<String> ejercicio4;
    private List<String> ejercicio5;
    public ListaPeliculas(){
        peliculas=new ArrayList();
        ratings=new ArrayList();
        cargarLista();
    }
    private void cargarLista(){
        StringTokenizer st;
        List<String> lineas;
        lineas=FuenteDeDatos.leerArchivo("C:\\Users\\IanCarlos\\Desktop\\movies.csv");
        List<String> rankings;
        rankings=FuenteDeDatos.leerArchivo("C:\\Users\\IanCarlos\\Desktop\\ratings.csv");
        lineas.remove(0);
        rankings.remove(0);
        for(String linea : lineas){
           st=new StringTokenizer(linea, ";");
           if(st.hasMoreTokens()){
               Pelicula p=new Pelicula();
               p.setId(st.nextToken());
               p.setMovie(st.nextToken());
               p.setGenre(st.nextToken());
               peliculas.add(p);
           }
        }
        for(String linea : rankings){
            st=new StringTokenizer(linea, ";");
            if(st.hasMoreTokens()){
                Rating r=new Rating();
                r.setUserId(st.nextToken());
                r.setMovieId(st.nextToken());
                r.setRating(st.nextToken());
                ratings.add(r);
            }
        }
    }
    public void peliculasAdventure(){
        ejercicio1=new ArrayList<>();
        for(Pelicula p : peliculas){
            if(p.getGenre().toUpperCase().contains("ADVENTURE")){
                String m= p.getId() + ";" + p.getMovie() + ";" + p.getGenre();
                ejercicio1.add(m);
            }
        }
        for(int i=0; i<ejercicio1.size(); i++){
            FuenteDeDatos.escribirArchivo("C:\\Users\\IanCarlos\\Desktop\\resultado.csv", ejercicio1, false);
        }
    }
    public void peliculasThrillerCrime(){
        ejercicio2=new ArrayList<>();
        for(Pelicula p : peliculas){
            if(p.getGenre().toUpperCase().contains("THRILLER")){
                if(p.getGenre().toUpperCase().contains("CRIME")){
                    String m=p.getId() + ";" + p.getMovie() + ";" + p.getGenre();
                    ejercicio2.add(m);
                }
            }
        }
        for (int i=0; i<ejercicio2.size(); i++){
            FuenteDeDatos.escribirArchivo("C:\\Users\\IanCarlos\\Desktop\\resultado.csv", ejercicio2, true);
        }
    }
    public void peliculas_X_Ano(String ano){
        ejercicio3=new ArrayList<>();
        for(Pelicula p : peliculas){
            if(p.getMovie().contains(ano)){
                String m= p.getId() + ";" + p.getMovie() + ";" + p.getGenre();
                ejercicio3.add(m);
            }
        }
        for(int i=0; i<ejercicio3.size(); i++){
            FuenteDeDatos.escribirArchivo("C:\\Users\\IanCarlos\\Desktop\\resultado.csv", ejercicio3, true);
        }
    }
    public void peliculas_X_Ranking(String rating){
        ejercicio4=new ArrayList<>();
        ArrayList temp1=new ArrayList();
        for (Rating r : ratings){
            double num=Double.valueOf(r.getRating());
            double rem=Double.valueOf(rating);
            if(rem >= num){
                temp1.add(r.getMovieId());
            }
        }
        for (Pelicula p : peliculas){
            int i=0;
            String k=(String) temp1.get(i);
            if(p.getId().contains(k)){
                String m= p.getId() + ";" + p.getMovie() + ";" + p.getGenre();
                ejercicio4.add(m);
                
            }
            i++;
        }
        for(int i=0; i<ejercicio4.size(); i++){
            FuenteDeDatos.escribirArchivo("C:\\Users\\IanCarlos\\Desktop\\resultado.csv", ejercicio4, true);
        }
    }
    public void peliculas_X_RankingComedia(String rating2){
        ejercicio5=new ArrayList<>();
        ArrayList temp2=new ArrayList();
        for (Rating r : ratings){
            double num=Double.valueOf(r.getRating());
            double rem=Double.valueOf(rating2);
            if(rem >= num){
                temp2.add(r.getMovieId());
            }
        }
        for (Pelicula p : peliculas){
            int i=0;
            String k=(String) temp2.get(i);
            if(p.getId().contains(k)){
                if(p.getGenre().toUpperCase().contains("COMEDY")){
                    String m= p.getId() + ";" + p.getMovie() + ";" + p.getGenre();
                    ejercicio5.add(m);
                }
            }
            i++;
        }
        for(int i=0; i<ejercicio5.size(); i++){
            FuenteDeDatos.escribirArchivo("C:\\Users\\IanCarlos\\Desktop\\resultado.csv", ejercicio5, true);
        }
    }
}

