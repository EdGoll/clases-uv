import java.util.Scanner;

public class ListaPeliculasPrincipal {

    public static void main(String[] args) {
        ListaPeliculas peli=new ListaPeliculas();
        System.out.println("Bienvenido, por favor espere hasta que el programa termine para ejecutar");
        peli.peliculasAdventure();
        peli.peliculasThrillerCrime();
        System.out.println("Ingrese el año de la pelicula");
        Scanner sc=new Scanner(System.in);
        String ano=sc.next();
        peli.peliculas_X_Ano(ano);
        System.out.println("Ingrese un valor flotante, para conocer las peliculas mejor rankeadas desde el valor dado");
        sc=new Scanner(System.in);
        String rating=sc.next();
        peli.peliculas_X_Ranking(rating);
        System.out.println("Ingrese un valor flotante, para conocer las peliculas mejor rankeadas desde el valor dado que pertenezcan a la comedias");
        sc=new Scanner(System.in);
        String rating2=sc.next();
        peli.peliculas_X_RankingComedia(rating2);
        System.out.println("Gracias por esperar, se creo un nuevo archivo llamado resultado.csv donde esta toda la informacion");
    }
    
}
