public class Rating {
    private String userid;
    private String movieid;
    private String rating;
    
    public Rating(){}
    
    public Rating(String userid, String movieid, String rating){
        this.userid=userid;
        this.movieid=movieid;
        this.rating=rating;
    }
    //metodos get()
    public String getUserId(){
        return userid;
    }
    public String getMovieId(){
        return movieid;
    }
    public String getRating(){
        return rating;
    }
    //metodos set()
    public void setUserId(String userid){
        this.userid=userid;
    }
    public void setMovieId(String movieid){
        this.movieid=movieid;
    }
    public void setRating(String rating){
        this.rating=rating;
    }
}
