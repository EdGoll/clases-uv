public class Pelicula {
    private String id;
    private String movie;
    private String genre;
    
    public Pelicula(){}
    
    public Pelicula(String id, String movie, String genre){
        this.id=id;
        this.movie=movie;
        this.genre=genre;
    }
    //metodos get()
    public String getId(){
        return id;
    }
    public String getMovie(){
        return movie;
    }
    public String getGenre(){
        return genre;
    }
    //metodos set()
    public void setId(String id){
        this.id=id;
    }
    public void setMovie(String movie){
        this.movie=movie;
    }
    public void setGenre(String genre){
        this.genre=genre;
    }
}
