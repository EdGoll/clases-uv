import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Lista {
    private List<Movie> peliculas = null;
    private List<Rating> clasificacion = null;
    private File archivo;
    
    public Lista() {
        peliculas = new ArrayList<>();
        clasificacion = new ArrayList<>();
        archivo = new File("Resultado.csv");
        cargar();
    }
    
    private void cargar() {
        List<String> lineasA = FuenteDeDatos.leerArchivo("movies.csv");
        List<String> lineasB = FuenteDeDatos.leerArchivo("ratings.csv");
        Movie m;
        Rating r;
        StringTokenizer stA;
        StringTokenizer stB;
        StringTokenizer stC;
        List<String> temp;
        String generos;
        int cont = 0;
        for(String lineaA : lineasA) {
            m = new Movie();
            temp = new ArrayList<>();
            stA = new StringTokenizer(lineaA, ";");
            if(stA.hasMoreTokens()) {
                m.setMovieId(stA.nextToken());
                m.setTitle(stA.nextToken());
                generos = stA.nextToken();
                if(generos.contains("|")) {
                    stC = new StringTokenizer(generos, "|");
                    if(stC.hasMoreTokens()) {
                        for(int i = 0; i < stC.countTokens(); i++) {
                            temp.add(stC.nextToken());
                        }
                    }
                }
                else {
                    temp.add(generos);
                }
                m.setGenres(temp);
            }
            peliculas.add(m);
        }
        for(String lineaB : lineasB) {
            r = new Rating();
            stB = new StringTokenizer(lineaB, ";");
            if(stB.hasMoreTokens()) {
                r.setUserId(stB.nextToken());
                r.setMovieId(stB.nextToken());
                if(cont == 0) {
                    String algo = stB.nextToken();
                    cont++;
                }
                else {
                    r.setRating(Double.parseDouble(stB.nextToken()));
                }
                
            }
            clasificacion.add(r);
        }        
    }
    
    public void creacionDelArchivo() {
        try {
            this.archivo = new File("C:\\Users\\Jeremy Villarroel\\Documents\\Programacion 2\\Certamen 2\\Resultado.csv");
            if(this.archivo.createNewFile()) {
                System.out.println("Se a creado el archvo, nombre: Resultado");
            }
        } catch(IOException e) {
            System.err.println("No se a podido crear el archivo " + e);
        }
    }
    
    public void peliculasDeAventura() {
        List<String> aventura = new ArrayList<>();
        for(Movie p : peliculas) {
            for(String g : p.getGenres()) {
                if(g.toUpperCase().contains("ADVENTURE")) {
                    aventura.add(p.getTitle());
                }
            }
        }
        aventura.add("========================================");
        FuenteDeDatos.escribirArchivo("C:\\Users\\Jeremy Villarroel\\Documents\\Programacion 2\\Certamen 2\\Resultado.csv", aventura, true);
    }
    
    public void peliculasDeThrillerCrime() {
        List<String> thrillerCrime = new ArrayList<>();
        List<String> thriller = new ArrayList<>();
        List<String> crime = new ArrayList<>();
        for(Movie p : peliculas) {
            for(String g : p.getGenres()) {
                if(g.toUpperCase().contains("THRILLER")) {
                    thriller.add(p.getTitle());
                }
                if(g.toUpperCase().contains("CRIME")) {
                    crime.add(p.getTitle());
                }
            }
        }
        for(String t : thriller) {
            for(String c : crime) {
                if(t.contains(c)) {
                    thrillerCrime.add(t);
                    
                }
            }
        }
        thrillerCrime.add("========================================");
        FuenteDeDatos.escribirArchivo("C:\\Users\\Jeremy Villarroel\\Documents\\Programacion 2\\Certamen 2\\Resultado.csv", thrillerCrime, true);
    }
    
    public void busquedaPorFecha() {
        List<String> peliculasPorFecha = new ArrayList<>();
        String texto;
        Scanner s = new Scanner(System.in);
        System.out.println("Ingrese el año de las peliculas a buscar: ");
        texto = s.nextLine();
        for(Movie p : peliculas) {
            if(p.getTitle().contains("(" + texto + ")")) {
                peliculasPorFecha.add(p.getTitle());
            }
        }
        peliculasPorFecha.add("========================================");
        FuenteDeDatos.escribirArchivo("C:\\Users\\Jeremy Villarroel\\Documents\\Programacion 2\\Certamen 2\\Resultado.csv", peliculasPorFecha, true);
    }
    
    public void busquedaRating() {
        List<String> temp = new ArrayList<>();
        List<String> rating = new ArrayList<>();
        double numero = 0;
        Scanner escaner = new Scanner(System.in);
        System.out.println("Ingrese el rating a buscar en la lista de peliculas: ");
        numero = escaner.nextDouble();
        for(Rating c : clasificacion) {
            if(numero <= c.getRating()) {
                temp.add(c.getMovieId());
            }
        }
        for(Movie p : peliculas) {
            for(String t : temp) {
                if(Character.isDigit(p.getMovieId().charAt(0))) {
                    if(Integer.parseInt(t) == Integer.parseInt(p.getMovieId())) {
                        rating.add(p.getTitle());
                    }
                }
            }
        }
        rating.add("========================================");
        FuenteDeDatos.escribirArchivo("C:\\Users\\Jeremy Villarroel\\Documents\\Programacion 2\\Certamen 2\\Resultado.csv", rating, true);
        
    }
    
    public void busquedaRatingComedy() {
        List<String> temp = new ArrayList<>();
        List<String> ratingComedy = new ArrayList<>();
        double numero = 0;
        Scanner escaner = new Scanner(System.in);
        System.out.println("Ingrese el rating a buscar en la lista de peliculas: ");
        numero = escaner.nextDouble();
        for(Rating c : clasificacion) {
            if(numero <= c.getRating()) {
                temp.add(c.getMovieId());
            }
        }
        for(Movie p : peliculas) {
            for(String g : p.getGenres()) {
                for(String t : temp) {
                    if(Character.isDigit(p.getMovieId().charAt(0))) {
                        if(Integer.parseInt(t) == Integer.parseInt(p.getMovieId())) {
                            if(g.toUpperCase().contains("COMEDY")) {
                                ratingComedy.add(p.getTitle());
                           }
                        }
                    }
                }
            }
        }
        ratingComedy.add("========================================");
        FuenteDeDatos.escribirArchivo("C:\\Users\\Jeremy Villarroel\\Documents\\Programacion 2\\Certamen 2\\Resultado.csv", ratingComedy, true);
    }
    
}
