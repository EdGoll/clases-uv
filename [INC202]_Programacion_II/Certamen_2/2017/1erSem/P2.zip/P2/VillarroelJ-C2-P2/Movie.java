import java.util.ArrayList;
import java.util.List;

public class Movie implements java.io.Serializable {
    private String movieId;
    private String title;
    private List<String> genres;
    
    public Movie() {}

    public Movie(String movieId, String title, List<String> genres) {
        this.movieId = movieId;
        this.title = title;
        this.genres = genres;
    }

    public String getMovieId() {
        return movieId;
    }

    public String getTitle() {
        return title;
    }

    public List<String> getGenres() {
        return genres;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setGenres(List<String> genres) {
        this.genres = genres;
    }
    
    @Override
    public String toString() {
        return String.format("%s %s %s", movieId, title, genres);
    }
}