public class Principal {
    public static void main(String[] args) {
        Lista pelis = new Lista();
        pelis.creacionDelArchivo();
        pelis.peliculasDeAventura();
        pelis.peliculasDeThrillerCrime();
        pelis.busquedaPorFecha();
        pelis.busquedaRating();
        pelis.busquedaRatingComedy();
    }
    
}
