import java.io.FileReader;
import java.util.Arrays;
import com.opencsv.CSVReader;
import java.io.IOException;

public class asd {
    
    
    
   public static final char SEPARATOR=';';
   public static final char QUOTE='"';

   public static void main(String[] args) {

      CSVReader reader = null;
      try {
         reader = new CSVReader(new FileReader("movies.csv"),SEPARATOR,QUOTE);
         String[] nextLine=null;
         
         while ((nextLine = reader.readNext()) != null) {
            System.out.println(Arrays.toString(nextLine));
         }
         
      } catch (IOException e) {
         System.out.println("error"+e.getMessage());
      } finally {
         if (null != reader) {
            reader.close();
         } 
      }
   }
    
}
