import java.util.List;

public class PruebaFuenteDeDatos {

    public static void main(String[] args) {
        String nombreArchivo = "movie.csv";        
        List<String> lineas = FuenteDeDatos.leerArchivo(nombreArchivo);
        FuenteDeDatos.escribirArchivo(nombreArchivo, lineas, false);
    }
}