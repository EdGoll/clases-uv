public class Tda {
  
    String movieid;
    String title;
    String genres;
    String userId;
    String rating;


    
    Tda()
    {
        this.movieid=null;
        this.title=null;
        this.genres=null;
        this.userId=null;
        this.rating=null;
                
    }
    
    Tda(String movieid,String title,String genres,String userid,String rating)
    {
        this.movieid=movieid;
        this.title=title;
        this.genres=genres;
        this.userId=userid;
        this.rating=rating;
    }         
         
    
}
