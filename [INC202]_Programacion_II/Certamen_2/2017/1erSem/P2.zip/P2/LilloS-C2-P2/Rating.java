
public class Rating {
	private String UserId;
	private String MovieId;
	private String Rating;
	public Rating(String userId, String movieId, String rating) {
		UserId = userId;
		MovieId = movieId;
		Rating = rating;
	}
	public Rating(){}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getMovieId() {
		return MovieId;
	}
	public void setMovieId(String movieId) {
		MovieId = movieId;
	}
	public String getRating() {
		return Rating;
	}
	public void setRating(String rating) {
		Rating = rating;
	}
	
}
