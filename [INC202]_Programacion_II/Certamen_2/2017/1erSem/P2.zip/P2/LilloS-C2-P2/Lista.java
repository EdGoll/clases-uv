import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Lista {
	private List <Movies> movies;
	private List <Rating> rating;
	private Scanner s;
	private Scanner s2;
 	public Lista() {
		movies = new ArrayList<>();
		rating = new ArrayList<>();
		Cargar();
		MoviesAdventure();
		MoviesThrillerCrime();
		Anio();
		Rating();
		Rating2();
	}
	private void Cargar(){
		List <String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
		List <String> lineas1 = FuenteDeDatos.leerArchivo("ratings.csv");
		StringTokenizer st;
		for (String l : lineas){
			st = new StringTokenizer(l, ";");
			if (st.hasMoreElements()){
				Movies m = new Movies();
				m.setID(st.nextToken());
				m.setTittle(st.nextToken());
				m.setGenres(st.nextToken());
				movies.add(m);
			}
		}
		for (String l1 : lineas1){
			st = new StringTokenizer(l1, ";");
			if (st.hasMoreElements()){
				Rating r = new Rating();
				r.setUserId(st.nextToken());
				r.setMovieId(st.nextToken());
				r.setRating(st.nextToken());
				rating.add(r);
			}
		}
	}
	public void MoviesAdventure(){
		List <String> movies1 = new ArrayList<>();
		movies1.add("-------------------------------------------------------Peliculas del genero Adventure: ");
		for (Movies m : movies){
			if(m.getGenres().contains("Adventure")){
				movies1.add(m.getTittle());
			}
		}
		FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", movies1, false);
	}
	public void MoviesThrillerCrime(){
		List <String> movies1 = new ArrayList<>();
		movies1.add("-------------------------------------------------------Peliculas del genero Thriller|Crime: ");
		for (Movies m : movies){
			if(m.getGenres().contains("Thriller") && m.getGenres().contains("Crime")){
				movies1.add(m.getTittle());
			}
		}
		FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", movies1, true);
	}
	public void Anio(){
		List <String> movies1 = new ArrayList<>();
		s2 = new Scanner(System.in);
		String anio;
		System.out.println("Ingrese el anio de las peliculas a buscar");
		anio=s2.nextLine();
		movies1.add("-------------------------------------------------------Peliculas del anio solicitado: ");
		for (Movies m : movies){
			if(m.getTittle().contains(anio)){
				movies1.add(m.getTittle());
			}
		}
		FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", movies1, true);
	}
	public void Rating(){
		List <String> movies1 = new ArrayList<>();
		String movies2 = null;
		String movies3 = null;
		String movies4 = null;
		s = new Scanner(System.in);
		String ra;
		System.out.println("Ingrese el Rating de las peliculas a buscar: ");
		ra=s.nextLine();
		movies1.add("------------------------------------------------------Peliculas del Rating solicitado: ");
		int bandera = 0;
		for (Rating r : rating){
			movies2 = r.getRating();
			movies4 = r.getMovieId();
			if (movies2.contains(ra)){
				bandera++;
			}
			if (bandera > 0){
				for (Movies m : movies){
					movies3 = m.getID();
					if (movies3.contains(movies4)){
						movies1.add(m.getTittle());
				
					}
				}	
			}	
		}
		System.out.println(bandera);
		FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", movies1, true);
	}
	public void Rating2(){
		List <String> movies1 = new ArrayList<>();
		String movies2 = null;
		String movies3 = null;
		String movies4 = null;
		s = new Scanner(System.in);
		String ra;
		System.out.println("Ingrese el Rating de las peliculas a buscar: ");
		ra=s.nextLine();
		movies1.add("------------------------------------------------------Peliculas del Rating solicitado y que sean del Genero Comedy: ");
		int bandera = 0;
		for (Rating r : rating){
			movies2 = r.getRating();
			movies4 = r.getMovieId();
			if (movies2.contains(ra)){
				bandera++;
			}
			if (bandera > 0){
				for (Movies m : movies){
					movies3 = m.getID();
					if (movies3.contains(movies4) && m.getGenres().contains("Comedy")){
						movies1.add(m.getTittle());
					}
				}	
			}	
		}
		FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", movies1, true);
	}
}