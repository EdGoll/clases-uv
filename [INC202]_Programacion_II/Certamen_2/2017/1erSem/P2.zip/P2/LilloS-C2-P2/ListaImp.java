
public class ListaImp {
	public static void main (String [] args){
		Lista l = new Lista();
	}
}
