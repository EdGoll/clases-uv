
public class Movies {
	private String ID;
	private String Tittle;
	private String Genres;
	
	public Movies(String iD, String tittle, String genres) {
		this.ID = iD;
		this.Tittle = tittle;
		this.Genres = genres;
	}
	public Movies() {}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getTittle() {
		return Tittle;
	}
	public void setTittle(String tittle) {
		Tittle = tittle;
	}
	public String getGenres() {
		return Genres;
	}
	public void setGenres(String genres) {
		Genres = genres;
	}
	
}
