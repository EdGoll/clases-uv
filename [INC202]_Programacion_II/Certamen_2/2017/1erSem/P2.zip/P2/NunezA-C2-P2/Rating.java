
public class Rating {
    public String userId;
    public String movieId;
    public String rating;

    public Rating(String userId, String movieId, String rating) {
        this.userId = userId;
        this.movieId = movieId;
        this.rating = rating;
    }

    public Rating() {}
    
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }  
}
