
public class Movies{
    public String movieId;
    public String title;
    public String genres;

    public Movies(String movieId, String title, String genres){
        this.movieId = movieId;
        this.title = title;
        this.genres = genres;
    }

    public Movies() {}
    
    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenres() {
        return genres;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }
}
