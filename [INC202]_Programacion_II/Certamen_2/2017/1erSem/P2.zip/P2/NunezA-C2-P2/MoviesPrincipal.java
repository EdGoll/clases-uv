
import java.io.IOException;

public class MoviesPrincipal {
    public static void main(String[] args) throws IOException {
        ListaPeliculas pelis = new ListaPeliculas();
    }
}
