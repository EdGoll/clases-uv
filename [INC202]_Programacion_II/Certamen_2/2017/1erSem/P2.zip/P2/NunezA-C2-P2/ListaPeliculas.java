
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;

public final class ListaPeliculas {
    public List<Movies> listaMovies;
    public List<Rating> listaRating;
    
    public ListaPeliculas() throws IOException{
        listaMovies = new ArrayList<>();
        listaRating = new ArrayList<>();
        cargar();
        listarPeliculasAdventure();
        listarPeliculasThriller_Crime();
        listarPeliculaAnio();
        listarRatingUsuario();
        listarRatingUsuarioComedy();
    }
    
    public void cargar(){
        List <String> lineasMovies = FuenteDeDatos.leerArchivo("movies.csv");
        List <String> lineasRating = FuenteDeDatos.leerArchivo("ratings.csv");
        Movies a;
        Rating b;
        StringTokenizer st;
        for (String l : lineasMovies){
            st = new StringTokenizer(l, ";");
            if(st.hasMoreElements()){
                a = new Movies();
                a.setMovieId(st.nextToken());
                a.setTitle(st.nextToken());
                a.setGenres(st.nextToken());
                listaMovies.add(a);
            }
        }
        for (String l : lineasRating){
            st = new StringTokenizer(l, ";");
            if(st.hasMoreElements()){
                b = new Rating();
                b.setUserId(st.nextToken());
                b.setMovieId(st.nextToken());
                b.setRating(st.nextToken());
                listaRating.add(b);
            }
        }
    }
    
    public void listarPeliculasAdventure(){
        List<String> adventure = new ArrayList<>();
        adventure.add("--------------------------Peliculas Adventure--------------------------");
        for(Movies r : listaMovies){
            if(r.getGenres().contains("Adventure")){
                adventure.add(r.getTitle());
            }
        }
        FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", adventure, false);
    }
    
    public void listarPeliculasThriller_Crime(){
        List<String> Thriller_Crime = new ArrayList<>();
        Thriller_Crime.add("--------------------------Peliculas Thriller y Crime--------------------------");
        for(Movies r : listaMovies){
            if(r.getGenres().contains("Thriller") && r.getGenres().contains("Crime")){
                Thriller_Crime.add(r.getTitle());
            }
        }
        FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", Thriller_Crime, true);
    }
    
    public void listarPeliculaAnio() throws IOException{
        List<String> peliculaAnio = new ArrayList<>();
        InputStreamReader valor1 = new InputStreamReader(System.in);
        BufferedReader valor2 = new BufferedReader(valor1);
        System.out.println("Introduce el año que deseas buscar: ");
        String anio = valor2.readLine();
        peliculaAnio.add("--------------------------Peliculas del año "+ anio + "--------------------------");
        for(Movies r : listaMovies){
            if(r.getTitle().contains(anio)){
                peliculaAnio.add(r.getTitle());
            }
        }
        FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", peliculaAnio, true);
    }
    
    public void listarRatingUsuario() throws IOException{
        List<String> pelicula_User = new ArrayList<>();
        InputStreamReader valor1 = new InputStreamReader(System.in);
        BufferedReader valor2 = new BufferedReader(valor1);
        System.out.println("Introduce el piso de rating que deseas buscar (en decimal): ");
        String rating_buscar = valor2.readLine();
        pelicula_User.add("--------------------------Peliculas de Rating "+ rating_buscar +" o superior --------------------------");
        for(Rating r : listaRating){
            if(r.getRating().contains(rating_buscar)){
                for(Movies m : listaMovies){
                    if(r.getMovieId().equals(m.getMovieId())){
                        pelicula_User.add(m.getTitle());
                    }
                }
            }
        }
        FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", pelicula_User, true);
    }
    
    public void listarRatingUsuarioComedy() throws IOException{
        List<String> pelicula_User = new ArrayList<>();
        InputStreamReader valor1 = new InputStreamReader(System.in);
        BufferedReader valor2 = new BufferedReader(valor1);
        System.out.println("Introduce el piso de rating que deseas buscar (en decimal): ");
        String rating_buscar = valor2.readLine();
        pelicula_User.add("--------------------------Peliculas de Rating "+ rating_buscar +" o superior y Comedy --------------------------");
        for(Rating r : listaRating){
            if(r.getRating().contains(rating_buscar)){
                for(Movies m : listaMovies){
                    if(r.getMovieId().equals(m.getMovieId()) && m.getGenres().contains("Comedy")){
                        pelicula_User.add(m.getTitle());
                    }
                }
            }
        }
        FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", pelicula_User, true);
    }
}
