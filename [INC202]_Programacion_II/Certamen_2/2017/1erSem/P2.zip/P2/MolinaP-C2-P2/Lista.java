import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Lista{
    private List<Movie> peliculas;
    private List<Ratings> ratings;
    
    public Lista(){
	peliculas= new ArrayList<>();
	ratings= new ArrayList<>();
        cargarMovie();
        cargarRatings();
    }
    private void cargarMovie(){
	List<String> lineas=FuenteDeDatos.leerArchivo("movies.csv");
	Movie P;
	StringTokenizer st;
        for(String linea:lineas){
            st= new StringTokenizer(linea,";");
            if(st.hasMoreTokens()){
                P=new Movie();
                P.setId(st.nextToken());
                P.setNombre(st.nextToken());
                P.setGenero(st.nextToken());
                peliculas.add(P);
            }
        }
    }
    private void cargarRatings(){
	List<String> lineas=FuenteDeDatos.leerArchivo("ratings.csv");
	Ratings R;
	StringTokenizer st;
        for(String linea:lineas){
            st= new StringTokenizer(linea,";");
            if(st.hasMoreTokens()){
                R=new Ratings();
                R.setUserID(st.nextToken());
                R.setMovieID(st.nextToken());
                R.setRating(st.nextToken());
                ratings.add(R);
            }
        }
    }
    public void listarGeneroAdventure(){
        String generos;
        List<String> nombres=new ArrayList<String>();

        for(Movie linea:peliculas){
            generos=linea.getGenero().toUpperCase();

            if(generos.contains("ADVENTURE")){
                nombres.add(linea.getNombre());
            }
        }
        nombres.add("---------Fin lista de peliculas de genero adventure---------");
        FuenteDeDatos.escribirArchivo("lista.txt", nombres,true);
    }
    
    public void listarGeneroThrillerCrime(){
        String generos;
        List<String> nombres=new ArrayList<String>();

        for(Movie linea:peliculas){
            generos=linea.getGenero().toUpperCase();
            
            if(generos.contains("THRILLER")){
                if(generos.contains("CRIME")){
                    nombres.add(linea.getNombre());
                }
            }
        }
        nombres.add("---------Fin lista de peliculas de genero thriller y crime---------");
        FuenteDeDatos.escribirArchivo("lista.txt", nombres,true);
    }
    public void listarPeliculasPorAnno(int anno){
        String texto, nombre, aux;
        List<String> nombres=new ArrayList<String>();
        int annoPelicula = 0;
        StringTokenizer st;
        for(Movie linea:peliculas){
            st=new StringTokenizer(linea.getNombre(),"()");
            nombre=st.nextToken();
            while(st.countTokens()!=1){
                if(st.countTokens()==1){
                    annoPelicula=Integer.parseInt(st.nextToken());
                }else{
                    st.nextToken();
                }
            }
            if(annoPelicula==anno){
                nombres.add(nombre);
            }
        }
        texto=("---------Fin lista de peliculas del anno "+anno+"---------");
        nombres.add(texto);
        FuenteDeDatos.escribirArchivo("lista.txt", nombres,true);
    }
    public void listarPeliculasPorRating(double rating){
        String ID, peliculaID,texto;
        double aux;
        List<String> nombres=new ArrayList<String>();

        for(Ratings linea:ratings){
            aux=Double.parseDouble(linea.getRating());
            
            if(aux>=rating){
                peliculaID=linea.getMovieID();
                
                for(Movie linea2:peliculas){
                    ID=linea2.getId();
                    
                    if(peliculaID.equals(ID)){
                        nombres.add(linea2.getNombre());
                    }
                }
            }
        }
        texto=("---------Fin lista de peliculas con rating mayor a "+rating+"---------");
        nombres.add(texto);
        FuenteDeDatos.escribirArchivo("lista.txt", nombres,true);
    }
    public void comediasPorRating(double rating){
        String ID, peliculaID,texto,generos;
        double aux;
        List<String> nombres=new ArrayList<String>();

        for(Ratings linea:ratings){
            aux=Double.parseDouble(linea.getRating());
            
            if(aux>=rating){
                peliculaID=linea.getMovieID();
                
                for(Movie linea2:peliculas){
                    ID=linea2.getId();
                   
                    if(peliculaID.equals(ID)){
                        generos=linea2.getGenero().toUpperCase();
                        if(generos.contains("COMEDY")){
                            nombres.add(linea2.getNombre());
                        }
                    }
                }
            }
        }
        texto=("---------Fin lista de peliculas de comedia con rating mayor a "+rating+"---------");
        nombres.add(texto);
        FuenteDeDatos.escribirArchivo("lista.txt", nombres,true);
    }
}