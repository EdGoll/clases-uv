public class Ratings{
    private String userID;
    private String movieID;
    private String rating;

    public Ratings() {}
    public Ratings(String userID, String movieID, String rating) {
        this.userID = userID;
        this.movieID = movieID;
        this.rating = rating;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getMovieID() {
        return movieID;
    }

    public void setMovieID(String movieID) {
        this.movieID = movieID;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
    @Override
    public String toString() {
        return String.format("%s %s %s",userID ,movieID ,rating );
    }
}