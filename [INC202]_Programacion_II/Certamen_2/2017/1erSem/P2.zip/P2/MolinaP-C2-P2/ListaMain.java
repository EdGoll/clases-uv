import java.util.Scanner;

public class ListaMain{
    public static void main(String[] args){
        Lista lista=new Lista();
        Scanner teclado = new Scanner (System.in);
        int anno;
        double rating ,rating2;
        lista.listarGeneroAdventure();
        lista.listarGeneroThrillerCrime();
        
        System.out.println ("Escriba el anno de las peliculas a buscar ");
        anno = teclado.nextInt();        
        lista.listarPeliculasPorAnno(anno);
        
        System.out.println ("Escriba el rating minimo de las peliculas a buscar ");
        rating= teclado.nextDouble();
        lista.listarPeliculasPorRating(rating);
        
        
        System.out.println ("Escriba el rating minimo de las peliculas de comedia a buscar ");
        rating2= teclado.nextDouble();
        lista.comediasPorRating(rating2);
    }
}