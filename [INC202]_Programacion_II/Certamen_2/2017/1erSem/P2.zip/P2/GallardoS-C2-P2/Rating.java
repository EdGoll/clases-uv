public class Rating{
	private String userId;
	private String movieId;
	private float rating;

	public Rating(){}

	public Rating(String userId, String movieId, float rating){
		this.userId = userId;
		this.movieId = movieId;
		this.rating = rating;
	}
	
	public String getUserId(){
		return userId;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getMovieId(){
		return movieId;
	}

	public void setMovieId(String movieId){
		this.movieId = movieId;
	}

	public float getRating(){
		return rating;
	}

	public void setRating(float rating){
		this.rating = rating;
	}

	@Override
	public String toString(){
		return String.format("%s %s %f", userId, movieId, rating);
	}
}