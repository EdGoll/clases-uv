import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Lista{
    private List<Movie> movies;
    private List<Rating> ratings;
    Scanner sc = new Scanner(System.in);
    
    public Lista(){
		movies = new ArrayList<>();
		cargar();
    }
    
    public Rating(){
    	ratings = new ArrayList<>();
    	cargar2();
    }
	
    private void cargar(){
        List<String> lineas = FuenteDeDatos.leerArchivo("C:\\Users\\Sofia\\Documents\\NetBeansProjects\\Movie\\src\\movies.csv");
        Movie m;
        String[] datos;
        String[] gen;
        
        for(String l:lineas){
            List<String> generos = new ArrayList<>();
            datos = l.split(";");
            gen = datos[2].split("[|]");
            
            for(int i = 0; i < gen.length; i++){
                generos.add(gen[i]);
            }
            m = new Movie(datos[0], datos[1], generos);
        }

    }
	
	private void cargar2(){
        List<String> lineas2 = FuenteDeDatos.leerArchivo("C:\\Users\\Sofia\\Documents\\NetBeansProjects\\Movie\\src\\ratings.csv");
        Rating r;
        String[] datos2;
        
        for(String l:lineas2){
            datos2 = l.split(";");
            r = new Rating(datos2[0], datos2[1], datos2[2]);
            ratings.add(r);
        }
        System.out.println(datos2[2]);
	}
	
    public void genero_adventure(){
		
		for(Movie m : movies){
			System.out.println(m);
            if(m.getGeneros().contains("Adventure")){
                System.out.println(m.getTitle());
            }
        }
        //FuenteDeDatos.escribirArchivo("Adventure.txt", List<String> lineas, false);
	}

	public void genero_thriller_crime(){
 
		for(Movie m : movies){
			
            if(m.getGeneros().contains("Thriller") && m.getGeneros().contains("Crime")){
                System.out.println(m.getTitle());
            }
        }
        //FuenteDeDatos.escribirArchivo("TyC.txt", List<String> lineas, false);
	}
	
	public void anio(){
		
		int anio;
		System.out.print("Por favor introduzca el anio: ");
		anio = sc.nextInt();

        for( Movie m : movies ){
			if (m.getTitle().contains(anio)){
				System.out.println(m.getTitle());
			}
		}
		//FuenteDeDatos.escribirArchivo("Anio.txt", List<String> lineas, false);
	}
	
	public void rating_user(){

		float n;
		System.out.print("Por favor introduzca el rating: ");
		n = sc.nextInt();

		for(Rating r : ratings){
			if(n >= r.getRating() && m.getMovieId.contains(r.getMovieId())){
					System.out.print(m.getTitle());
				
			}
		}
		//FuenteDeDatos.escribirArchivo("RatingUser.txt", List<String> lineas, false);
    }

	
	public void rating_user_comedy(){

		float nc;
		System.out.print("Por favor introduzca el rating de comedia: ");
		nc = sc.nextInt();

		for (Rating r : ratings){
			if (nc >= r.getRating && m.getGeneros().contains("Comedy")){
				System.out.print(m.getTitle());
			}
		}
		//FuenteDeDatos.escribirArchivo("RatingComedia.txt", List<String> lineas, false);

	}
	
	
}