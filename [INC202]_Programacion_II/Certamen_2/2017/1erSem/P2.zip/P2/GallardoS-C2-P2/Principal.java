public class Principal {
	public static void main(String[] args) {
		Lista li = new Lista();
		
		li.genero_adventure();
		li.genero_thriller_crime();
		li.anio();
		li.rating_user();
		li.rating_user_comedy();
		
	}
}