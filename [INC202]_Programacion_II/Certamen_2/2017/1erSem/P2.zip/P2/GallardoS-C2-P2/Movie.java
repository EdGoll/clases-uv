import java.util.List;
public class Movie{
	private String movieId;
	private String title;
	private List<String> generos;

	public Movie(){}

	public Movie(String movieId, String title, List<String> generos){
		this.movieId = movieId;
		this.title = title;
		this.generos = generos;
	}
	
	public String getMovieId(){
		return movieId;
	}

	public void setMovieId(String movieId){
		this.movieId = movieId;
	}

	public String getTitle(){
		return title;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public List<String> getGeneros(){
		return generos;
	}

	public void setGeneros(List<String> generos){
		this.generos = generos;
	}

	@Override
	public String toString(){
		return String.format("%s %s %s", movieId, title, generos);
	}
}