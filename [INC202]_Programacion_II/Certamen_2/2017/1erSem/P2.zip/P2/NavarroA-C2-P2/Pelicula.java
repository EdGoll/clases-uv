import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Scanner;


public class Pelicula {
	private List <Lista> peli=null;
	private List <Rating> rate = null;
	private StringTokenizer J,K,L;
	public Pelicula(){
		peli = new ArrayList<>();
		rate = new ArrayList<>();
		cargar();		
	}
	
	public void cargar(){
            
		Lista A;
		Rating B;
                URL location = Pelicula.class.getProtectionDomain().getCodeSource().getLocation();                
		List<String> lineas1=FuenteDeDatos.leerArchivo(location.getFile()+"/movies");
		List <String> lineas2=FuenteDeDatos.leerArchivo(location.getFile()+"/ratings");
		int i=0;
                for (String l: lineas2){
                    J=new StringTokenizer(l, ";");
                    B=new Rating(J.nextToken(),J.nextToken(),J.nextToken());
                    rate.add(B);
                }
		for(String l: lineas1 ){
			if (i!=0){
				J = new StringTokenizer(l, ";");
               			A= new Lista(J.nextToken(),J.nextToken(),J.nextToken(),rate.get(i).getUserId(),rate.get(i).getMovieId(),rate.get(i).getRating());
                                peli.add(A); 
				
				
			}
			i+=1;
		}			
	}
	/*public void escribir(){
		List<String> write = FuenteDeDatos.escribirArchivo("Historial");
	}*/
	
	public void sortGenreAdventure(){
		String A;
		for (Lista l: peli){
			A = l.getGenre();
			K = new StringTokenizer(A, "|");
			while (K.hasMoreTokens()){
				if(K.nextToken().equals("Adventure")){
					System.out.println(l.toString());
                                        FuenteDeDatos.escribir("Historial", l.toString());
				}
			}
		}
	}
	
	public void sortGenreThrillerCrime(){
		String A;
		for (Lista l: peli){
			A = l.getGenre();
			K = new StringTokenizer(A, "|");
			String esta;
			boolean count1=false,count2=false;
			
			while (K.hasMoreTokens()){
				esta=K.nextToken();
				if(esta.equals("Thriller")){
					count1=true;
					}
				if(esta.equals("Crime")){
					count2=true;
				}
				if (count1==true && count2==true){
					System.out.println(l.toString());
                                        FuenteDeDatos.escribir("Historial", l.toString());
				}
			}
		}
	}

	public void sortYear(){
		String A;
		String año;
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca año: ");
		año=sc.nextLine();
		for (Lista l: peli){
			A = l.getTitle();
			K = new StringTokenizer(A, "(");
                        String esta;
			while (K.hasMoreTokens()){
				if(K.nextToken().equals(año+")")){
					System.out.println(l.toString());
                                        FuenteDeDatos.escribir("Historial", l.toString());
				}
			}
		}
	}
	
	public void sortRating(){
		String A;
		float rating,f;
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca rating: ");
		rating=sc.nextFloat();
                for (Lista l : peli){
                    A=l.getRating();
                    f=Float.parseFloat(A);
                        if(f >= rating){
                            System.out.println(l.toString());
                            FuenteDeDatos.escribir("Historial", l.toString());
                    }
                }
            }
 
        public void sortRatingComedy(){
		String A,B;
		float rating,f;
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca rating: ");
		rating=sc.nextFloat();
                String movieid;
                for (Lista l : peli){
                    A=l.getRating();
                    B=l.getGenre();
                    K = new StringTokenizer(B, "|");
                    f=Float.parseFloat(A);
                    String esta;
                    while (K.hasMoreTokens()){
                        if(K.nextToken().equals("Comedy") && f >= rating){
                             System.out.println(l.toString());
                             FuenteDeDatos.escribir("Historial", l.toString());
                            }
                        }                       
                    }
                }
            
	
	public void mostrarMovieid(){
		
		for (Lista l: peli){
			System.out.println(l.getMovieid());
		}
	}
	public void mostrarTitle(){
		
		for (Lista l: peli){
			System.out.println(l.getTitle());
		}
	}
	public void mostrarGenre(){
		
		for (Lista l: peli){
			System.out.println(l.getGenre());
		}
	}
}
