import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

public class FuenteDeDatos{
	
	public static List<String> leerArchivo(String nombreArchivo){
		File file = null;
		FileReader fileReader = null;
		String linea=null;
		List<String> lineas = null;
		try{
			file = new File(nombreArchivo);
			fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			lineas = new ArrayList<>();
			while((linea = bufferedReader.readLine()) != null){
				lineas.add(linea);
			}
		} catch (IOException ex){
			System.out.println(ex.getCause()); 
		} finally{
			if (fileReader != null){
				try{
					fileReader.close();
				} catch(IOException ex){
					System.out.println(ex.getCause());
				}
			}
		}
		return lineas;

	}

	
        public static void escribir(String nombreArchivo,String linea){
            File historial = new File(nombreArchivo);
            try{
                if(!historial.exists()){
                    System.out.println("Se ha creado un nuevo archivo");
                    historial.createNewFile();
                }       
        FileWriter fileWriter = new FileWriter(historial, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write( linea + "\n");
        bufferedWriter.close();

        System.out.println("Hecho!");
            } catch(IOException e) {
        System.out.println("NO SE GUARDO EL HISTORIAL!");
}

        }


}

