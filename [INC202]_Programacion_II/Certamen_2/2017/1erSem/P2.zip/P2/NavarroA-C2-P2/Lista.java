
public class Lista extends Rating{
	String movieid;
	String title;
	String genre;
	
	
	
	public Lista(String movieid, String title, String genre,String userId, String movieId, String rating ) {
		super(userId,movieId,rating);
		this.movieid = movieid;
		this.title = title;
		this.genre = genre;
	
		}
	
	public String getMovieid() {
		return movieid;
	}
	public void setMovieid(String movieid) {
		this.movieid = movieid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}

    @Override
    public String toString() {
        return "Lista{" + "movieid=" + movieid + ", title=" + title + ", genre=" + genre + ", rating=" + super.rating + '}';
    }

	
	
}
