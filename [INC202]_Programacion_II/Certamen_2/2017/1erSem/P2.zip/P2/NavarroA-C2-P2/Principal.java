
public class Principal {
	public static void main(String[] args){
		Pelicula a = new Pelicula();
		//a.mostrarMovieid();
		//a.mostrarTitle();
		//a.mostrarGenre();
                FuenteDeDatos.escribir("Historial", "Pregunta a): "+ "\n\n");
		a.sortGenreAdventure();
                FuenteDeDatos.escribir("Historial", "Pregunta b): "+ "\n\n");
		a.sortGenreThrillerCrime();
                FuenteDeDatos.escribir("Historial", "Pregunta c): "+ "\n\n");
		a.sortYear();
                FuenteDeDatos.escribir("Historial", "Pregunta d): "+ "\n\n");
                a.sortRating();
                FuenteDeDatos.escribir("Historial", "Pregunta e): "+ "\n\n");
                a.sortRatingComedy();
	}
}
