public class Rating {
    private String userid;
    private String idmovie;
    private String rating ;
    
    public Rating(){}
    public Rating(String userid, String movieid,String rating){
    
        this.userid = userid;
        this.idmovie = movieid;
        this.rating = rating;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getIdMovie() {
        return idmovie;
    }

    public void setIdMovie(String movieid) {
        this.idmovie = movieid;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
    
}
