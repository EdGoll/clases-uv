import java.io.IOException;

public class PeliculasIMP{
    
    public static void main(String[] args) throws IOException{
        Peliculas p = new Peliculas();
        p.PelAdventure();
        p.PelTrCr();
        p.PelFecha();
        p.RatingSup();
        p.RatingSupCom();
    }
}
