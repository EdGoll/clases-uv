import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Peliculas {
    private List<Movies> pelicula ;
    private List<Rating> rating;
    private Object FileWriter;
    
    public Peliculas() {
         pelicula = new ArrayList<>() ;
         rating = new ArrayList<>();
         cargar();
         cargar2();
    }      
    private void cargar(){
	List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
	Movies j;
	StringTokenizer st;	
        lineas.remove(0);
	for(String l: lineas){
	st = new StringTokenizer(l,";");
	if(st.hasMoreTokens()){
            j = new Movies (st.nextToken(), st.nextToken(), st.nextToken());
		pelicula.add(j);
	}	
    }
}
    private void cargar2(){
	List<String> lineas = FuenteDeDatos.leerArchivo("ratings.csv");
	Rating k;
	StringTokenizer st;	
        lineas.remove(0);
	for(String l: lineas){
            st = new StringTokenizer(l,";");
	if(st.hasMoreTokens()){
            k = new Rating (st.nextToken(), st.nextToken(), st.nextToken());
		rating.add(k);
	}	
    }
}
    public void Filewriter(FileWriter archivo){
        FileWriter = null;
        PrintWriter printWriter = null;
        
            try {
                archivo = new FileWriter ("archivo.txt");
            } catch (Exception ex) {
                Logger.getLogger(Peliculas.class.getName()).log(Level.SEVERE, null, ex);
            }
        printWriter = new PrintWriter (archivo);
        
    }
    public void PelAdventure(){
        
        String [] k;
     
        for (Movies m : pelicula){
            
            m.getGenres();
            k = m.getGenres().split("\\|");
            int n = k.length; 
            
            for(int i = 0;n>i;i++)
                if(k[i].equals("Adventure")){
               // System.out.println(m.getTitle());
           try{
               try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Archivo.txt")))) {
                   bw.write(m.getTitle());
               }
                
            } catch (IOException ex) {
                Logger.getLogger(Peliculas.class.getName()).log(Level.SEVERE, null, ex);
            }
             }
            
            

}
    }

    public void PelTrCr(){
        
        String [] k;
     
        for (Movies m : pelicula){

            m.getGenres();
            k = m.getGenres().split("\\|");
            int n = k.length; 
           
            for (int i = 0; n>i ; i++)
                for(int j = 0;n>j;j++)
                    if(k[i].equals("Thriller") && k[j].equals("Crime")){
                 //       System.out.println(m.getTitle());
              /* try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Archivo.txt")));
            bw.write(m.getTitle());
            bw.close();
                
            } catch (IOException ex) {
                Logger.getLogger(Peliculas.class.getName()).log(Level.SEVERE, null, ex);
            } */
                    }
             
            
           
}
    }
    public void PelFecha(){
    
    Scanner a = new Scanner(System.in);
        System.out.println("ingrese un año");
        int ano = a.nextInt();
        String palabra = "";
        palabra = String.valueOf(ano);
        for(Movies m : pelicula )
            if(m.getTitle().contains(palabra)){
                //System.out.println(m.getTitle());
          try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Archivo.txt")));
            bw.write(m.getTitle());
            bw.close();
                
            } catch (IOException ex) {
                Logger.getLogger(Peliculas.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
             
            
        
    }
    public void RatingSup(){
    Scanner b = new Scanner(System.in);
    System.out.println("Ingrese un Rating:");
        float rat = b.nextFloat();
        for(Rating r : rating){
            String numero = r.getRating();
            float asdf = Float.parseFloat(numero);
            if(asdf >= rat){
            String w = r.getIdMovie();
            for(Movies m : pelicula){
                String o = m.getMovieid();
                if(o.equals(w)){
                  try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Archivo.txt")));
            bw.write(m.getTitle());
            bw.close();
                
            } catch (IOException ex) {
                Logger.getLogger(Peliculas.class.getName()).log(Level.SEVERE, null, ex);
            }  
                }
                 
            
                  //  System.out.println(m.getTitle());   
                }
               
              }
    }    
            
    }
    
    
    public void RatingSupCom(){
    Scanner b = new Scanner(System.in);
    System.out.println("Ingrese un Rating: para peliculas de comedia");
        float rat = b.nextFloat();
         String [] k = null;
         
        for(Rating r : rating){
            String numero = r.getRating();
            float asdf = Float.parseFloat(numero);
            if(asdf >= rat){
            String w = r.getIdMovie();
            for(Movies m : pelicula)
            {m.getGenres();
            
                String o = m.getMovieid();
                if(o.equals(w)){
                //System.out.println(m.getTitle());
                k = m.getGenres().split("\\|");
                int asdasd = k.length;
                        
                if (asdasd == 1){
                    
                    if(m.getGenres().equals("Comedy") ){
                     //   System.out.println(m.getTitle());
                      try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Archivo.txt")));
            bw.write(m.getTitle());
            bw.close();
                
            } catch (IOException ex) {
                Logger.getLogger(Peliculas.class.getName()).log(Level.SEVERE, null, ex);
            }
            
                    }
                }
                    
                    }
                 
              }
    }    
            
    }
}
}

    
    
        
   

