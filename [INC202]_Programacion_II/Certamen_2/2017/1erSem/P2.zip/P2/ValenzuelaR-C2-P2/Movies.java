
public class Movies {
 
 private String movieid;
 private String title;
 private String genres;

 
 public Movies(){}
 
 public Movies(String movieid,String title, String genres){
     this.movieid = movieid;
     this.title = title;
     this.genres = genres;
             
 }

    public String getMovieid() {
        return movieid;
    }

    public void setMovieid(String movieid) {
        this.movieid = movieid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenres() {
        return genres;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }
 
}

