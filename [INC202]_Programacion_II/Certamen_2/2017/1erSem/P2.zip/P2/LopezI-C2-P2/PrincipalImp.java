public class PrincipalImp {
    public static void main(String[] args) {
        
        Lista l = new Lista();
        l.iniciarM();
        l.iniciarR();
        l.genAdventure();
        l.thrillerCrime();
        l.anioEspe();
        l.ratingUsuario();
        l.ratingComedy();
    }
 
}
