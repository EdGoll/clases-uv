import java.util.ArrayList;
import java.util.List;
public class Movies {

    private String movieIdM;
    private String title;
    private List<String> genres;

    public String getMovieIdM() {
        return movieIdM;
    }

    public void setMovieIdM(String movieIdM) {
        this.movieIdM = movieIdM;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getGenres() {
        return genres;
    }

    public void setGenres(List<String> genres) {
        this.genres = genres;
    }

    public Movies(String movieIdM, String title, List<String> genres) {
        this.movieIdM = movieIdM;
        this.title = title;
        this.genres = genres;
    }
    
    

    
    


    
    
    


}
