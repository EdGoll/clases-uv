
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Lista {

    private List<Movies> movies = null;
    private List<Ratings> ratings = null;

    public Lista() {
        movies = new ArrayList<>();
        ratings = new ArrayList<>();
    }

    public void iniciarM() {
        List<String> lineas = FuenteDeDatos.leerArchivo("movies.txt");
        String[] a;
        Movies se;
        List<String> g = null;
        int conta = 0;
        for (String linea : lineas) {
            a = linea.split(";");
            g = new ArrayList<>();
            if (a[2].toLowerCase().contains("adventure")) {
                g.add("adventure");
            }
            if (a[2].toLowerCase().contains("animation")) {
                g.add("animation");
            }
            if (a[2].toLowerCase().contains("children")) {
                g.add("children");
            }
            if (a[2].toLowerCase().contains("comedy")) {
                g.add("comedy");
            }
            if (a[2].toLowerCase().contains("fantasy")) {
                g.add("fantasy");
            }
            if (a[2].toLowerCase().contains("romance")) {
                g.add("romance");
            }
            if (a[2].toLowerCase().contains("sci-fi")) {
                g.add("sci-Fi");
            }
            if (a[2].toLowerCase().contains("crime")) {
                g.add("crime");
            }
            if (a[2].toLowerCase().contains("thriller")) {
                g.add("thriller");
            }
            if (a[2].toLowerCase().contains("action")) {
                g.add("action");
            }
            if (a[2].toLowerCase().contains("drama")) {
                g.add("Drama");
            }
            if (a[2].toLowerCase().contains("action")) {
                g.add("action");
            }
            if (a[2].toLowerCase().contains("mystery")) {
                g.add("mystery");
            }
            if (a[2].toLowerCase().contains("imax")) {
                g.add("imax");
            }
            if (a[2].toLowerCase().contains("musical")) {
                g.add("musical");
            }
            if (a[2].toLowerCase().contains("horror")) {
                g.add("Horror");
            }
            if (a[2].toLowerCase().contains("war")) {
                g.add("war");
            }
            if (a[2].toLowerCase().contains("documentary")) {
                g.add("documentary");
            }
            if (a[2].toLowerCase().contains("film-noir")) {
                g.add("film-Noir");
            }
            if (a[2].toLowerCase().contains("western")) {
                g.add("western");
            }
            if (a[2].toLowerCase().contains("no genres listed")) {
                g.add("no genres listed");
            }
            se = new Movies(a[0], a[1], g);
            
            if (conta > 0) {
                movies.add(se);

            }
            conta++;

        }

    }

    public void iniciarR() {
        List<String> lineas = FuenteDeDatos.leerArchivo("ratings.txt");
        String[] a;
        Ratings r;
        int conta = 0;
        for (String linea : lineas) {
            a = linea.split(";");
            r = new Ratings(a[0], a[1], a[2]);
            if (conta > 0) {
                ratings.add(r);
            }
            conta++;
        }

    }

    public void genAdventure() {
        System.out.println("----------------------------------------------------");
        List<String> a;
        for (Movies m : movies) {
            a = m.getGenres();
            List<String> t = new ArrayList<>();
            
            for (int i = 0; i < a.size(); i++) {
                if (a.get(i).contains("adventure")) {
                    System.out.println(m.getTitle());
                    t.add(m.getTitle());
                }

            }
            FuenteDeDatos.escribirArchivo("NuevoArchivo.txt", t, true);
            

        }
    }

    public void thrillerCrime() {
        System.out.println("--------------------------------------------------------------------");
        List<String> a;

        for (Movies m : movies) {
            a = m.getGenres();
            boolean c1 = false;
            boolean c2 = false;
            List<String> ls =  new ArrayList<>();
            for (int i = 0; i < a.size(); i++) {
                if (a.get(i).contains("thriller")) {
                    c1 = true;
                }
                if (a.get(i).contains("crime")) {
                    c2 = true;
                }

            }
            if (c1 == true && c2 == true) {
                System.out.println(m.getTitle());
                ls.add(m.getTitle());

            }
            FuenteDeDatos.escribirArchivo("NuevoArchivo.txt", ls, true);
            
        }
    }

    public void anioEspe() {
        System.out.println("----------------------------------------------------");
        boolean salida = false;
        while (salida == false) {
            List<String> ad = new ArrayList<>();
            String a;
            String s;
            Scanner sc = new Scanner(System.in);
            System.out.print("Introduzca el año:   ");
            a = sc.nextLine();
            System.out.println("----------------------------------------------");
            System.out.println("usted ingreso el año:  " + a);
            if (Integer.parseInt(a) > 1000) {
                for (Movies m : movies) {
                    if (m.getTitle().contains(a)) {
                        System.out.println(m.getTitle());
                        ad.add(m.getTitle());
                    }
                }
            } else {
                System.out.println("----------------------------------------------------------------");
                System.out.println("la fecha ingresada no es valida o no se encuentra en el listado.");
            }
            System.out.println("----------------------------------------------");
            System.out.println("¿Desea buscar con otra fecha?");
            System.out.println("----------------------------------------------");
            System.out.println("para ingresar otra fecha ingrese  'no' ");
            System.out.println("----------------------------------------------");
            System.out.println("para salir ingrese 'si'  ");
            System.out.println("----------------------------------------------");
            s = sc.nextLine();
            s = s.toLowerCase();
            FuenteDeDatos.escribirArchivo("NuevoArchivo.txt", ad, true);
            if (s.equals("si")) {
                salida = true;
            }

        }
    }

    public void ratingUsuario() {
        List<String> st = new ArrayList<>();
        System.out.println("---------------------------------------------------");
        Scanner sc = new Scanner(System.in);
        double a;
        System.out.println("ingrese el rating de la pelicula (recuerde que el rating es un punto flotante EL PUNTO FLOTANTE SE HACE CON 'COMA'(,)");
        a = sc.nextDouble();
        String id;
        ArrayList<String> n = new ArrayList<String>();
        for (Ratings r : ratings) {
            if (a <= Double.parseDouble(r.getRatings())) {
                id = r.getMovieIdR();
                if (n.size() == 0) {
                    n.add(id);
                } else {

                    int conta = 0;
                    for (int i = 0; i < n.size(); i++) {
                        if (!n.get(i).equals(id)) {
                            conta++;
                        }

                    }
                    if (conta == n.size()) {
                        n.add(id);
                    }
                }
                
            }
        }
        for (Movies m : movies) {
            for (int i = 0; i < n.size(); i++) {
                if (n.get(i).equals(m.getMovieIdM())) {
                    System.out.println(m.getTitle());
                    st.add(m.getTitle());
                }
            }
        }
       FuenteDeDatos.escribirArchivo("NuevoArchivo.txt", st, true); 
    }

    public void ratingComedy() {
        List<String> st = new ArrayList<>();
        System.out.println("-----------------------------------------------------");
        Scanner sc = new Scanner(System.in);
        double a;
        System.out.println("ingrese el rating de la pelicula (recuerde que el rating es un punto flotante(EL PUNTO FLOTANTE SE HACE CON 'COMA'-','))");
        a = sc.nextDouble();
        String id;
        ArrayList<String> n = new ArrayList<String>();
        for (Ratings r : ratings) {
            if (a <= Double.parseDouble(r.getRatings())) {
                id = r.getMovieIdR();
                if (n.size() == 0) {
                    n.add(id);
                } else {

                    int conta = 0;
                    for (int i = 0; i < n.size(); i++) {
                        if (!n.get(i).equals(id)) {
                            conta++;
                        }

                    }
                    if (conta == n.size()) {
                        n.add(id);
                    }
                }
                
            }
        }
        for (Movies m : movies) {
            List<String> r = m.getGenres();

            for (int i = 0; i < n.size(); i++) {
                if (n.get(i).equals(m.getMovieIdM())) {
                    for (int j = 0; j < r.size(); j++) {
                        if (r.get(j).toLowerCase().contains("comedy")) {
                            System.out.println(m.getTitle());
                            st.add(m.getTitle());
                        }

                    }
                }
            }
        }
        FuenteDeDatos.escribirArchivo("NuevoArchivo.txt", st, true);
    }
    
}
