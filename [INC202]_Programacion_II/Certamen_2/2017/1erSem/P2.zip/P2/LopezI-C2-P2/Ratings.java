
public class Ratings {
    private String userId;
    private String movieIdR;
    private String ratings;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMovieIdR() {
        return movieIdR;
    }

    public void setMovieIdR(String movieIdR) {
        this.movieIdR = movieIdR;
    }

    public String getRatings() {
        return ratings;
    }

    public void setRatings(String ratings) {
        this.ratings = ratings;
    }

    public Ratings(String userId, String movieIdR, String ratings) {
        this.userId = userId;
        this.movieIdR = movieIdR;
        this.ratings = ratings;
    }
    
    
}
