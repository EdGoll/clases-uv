public class Movie {
    private String id;
    private String titulo;
    private String genero;
    
    public Movie() {
    }
    
    public Movie(String id, String titulo, String genero) {
    this.id = id.trim();
    this.titulo = titulo.trim();
    this.genero = genero.trim();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }


    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
