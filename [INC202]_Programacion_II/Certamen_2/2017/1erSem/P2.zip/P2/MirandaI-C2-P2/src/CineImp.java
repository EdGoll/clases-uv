import java.util.Scanner;
public class CineImp{
public static void main(String [] args){
        Lista resultados = new Lista();
        resultados.Aventura();
        resultados.Crimen();
        
        Scanner y = new Scanner(System.in);
        System.out.println("Ingrese el año de las peliculas: ");
        String g = y.next();
        resultados.Año(g);
        
        Scanner calificacion = new Scanner(System.in);
        System.out.println("Ingrese el rating de la pelicula: ");
        String f = calificacion.next();
        resultados.Rating(f);
        
        Scanner calificacioncomedia = new Scanner(System.in);
        System.out.println("Ingrese el rating de la pelicula de genero comedia");
        String c = calificacioncomedia.next();
        resultados.RatingComedy(c);
}
}