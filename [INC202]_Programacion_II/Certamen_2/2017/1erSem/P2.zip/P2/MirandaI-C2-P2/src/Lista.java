import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Lista {
    private List<Movie> peliculas;
    private List<Rating> ratings;
    
    public Lista(){
        peliculas = new ArrayList<>();
        ratings = new ArrayList<>();
        cargarPeliculas();
        cargarRatings();
    }
    
    private void cargarPeliculas(){
		List<String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
		Movie j;
		StringTokenizer st;
		lineas.remove(0);
		for(String l: lineas){
			st = new StringTokenizer(l,";");
			if(st.hasMoreTokens()){
				j = new Movie (st.nextToken(), st.nextToken(), st.nextToken());
				peliculas.add(j);
			}
		}
    }
    private void cargarRatings() {
        List<String> lineas = FuenteDeDatos.leerArchivo("ratings.csv");
        Rating j;
		StringTokenizer st;
		lineas.remove(0);
		for(String l: lineas){
			st = new StringTokenizer(l,";");
			if(st.hasMoreTokens()){
				j = new Rating (st.nextToken(), st.nextToken(), st.nextToken());
				ratings.add(j);
			}
		}
        
    } 
            
    public void Aventura(){
        List<String> aventura = new ArrayList<>();
        String j;
        aventura.add("Peliculas de Aventura");
        aventura.add("");
        for(Movie p : peliculas){
            if(p.getGenero().contains("Adventure")){
                j = p.getTitulo();
                aventura.add(j);
            } 
        }
        FuenteDeDatos.escribirArchivo("Lista_Resultado.txt", aventura, true);
}
    public void Crimen(){
        List<String> crimen = new ArrayList<>();
        String j;
        crimen.add("----------------------------------------------------------");
        crimen.add("Peliculas de Crimen y Thriller");
        crimen.add("");
        for(Movie p : peliculas){
            if(p.getGenero().contains("Crime") & (p.getGenero().contains("Thriller"))){;
                j = p.getTitulo();
                crimen.add(j);
            }   
        }
        FuenteDeDatos.escribirArchivo("Lista_Resultado.txt", crimen, true);
}
    public void Año(String g) {
       List<String> año = new ArrayList<>();
       String j;
       año.add("--------------------------------------------------------------");
       año.add("Años de Pelicula");
       año.add("");
       for(Movie p : peliculas) {
           if(p.getTitulo().contains(g)) {
               j = p.getTitulo();
               año.add(j);               
           }
       }
    FuenteDeDatos.escribirArchivo("Lista_Resultado.txt", año, true);   
    }
    public void Rating(String f) {
       List<String> rating = new ArrayList<>();
       String j;
       String k;
       rating.add("--------------------------------------------------------------");
       rating.add("Peliculas con calificacion");
       rating.add("");
       for(Rating r : ratings) {
           if(r.getRating().contains(f)){
               j = r.getPeliculaID();
               for(Movie p : peliculas) {
                    if(p.getId().contains(j)){
                        k = p.getTitulo();
                        rating.add(k);
                    }
                }    
            }
        }
    FuenteDeDatos.escribirArchivo("Lista_Resultado.txt", rating, true);   
    }
    public void RatingComedy(String c) {
        List<String> rating2 = new ArrayList<>();
        String j;
        String k;
        rating2.add("--------------------------------------------------------------");
        rating2.add("Peliculas con calificacion del genero comedia");
        rating2.add("");
        for(Rating r : ratings) {
            if(r.getRating().contains(c)){
                j = r.getPeliculaID();
                for(Movie p : peliculas) {
                    if((p.getId().contains(j)) && (p.getGenero().contains("Comedy"))){
                            k = p.getTitulo();
                            rating2.add(k);
                        }
                    }
                }
            }
        FuenteDeDatos.escribirArchivo("Lista_Resultado.txt", rating2, true);
        }
    }
