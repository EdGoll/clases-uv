public class Rating {
    private String usuarioId;
    private String PeliculaID;
    private String Rating;
    
    public Rating(){
        
    }

    public Rating(String usuarioId, String PeliculaID, String Rating) {
        this.usuarioId = usuarioId.trim();
        this.PeliculaID = PeliculaID.trim();
        this.Rating = Rating.trim();
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getPeliculaID() {
        return PeliculaID;
    }

    public void setPeliculaID(String PeliculaID) {
        this.PeliculaID = PeliculaID;
    }

    public String getRating() {
        return Rating;
    }

    public void setRating(String Rating) {
        this.Rating = Rating;
    }
}
