import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.List;

public class Lista {
   private List<Movie> listaMovie;
   private List<Rating> listaRating;
   List<String> lineas;
   FuenteDeDatos fd = new FuenteDeDatos();
   Movie movie;
   Rating rating;
       
   public void leerPelis() {
       lineas = fd.leerArchivo("movies.csv");
       listaMovie = new ArrayList();
       StringTokenizer st = null;				
       for (String linea : lineas){				
           st = new StringTokenizer(linea, ";");		
           try{
                if(st.hasMoreElements()){		 
                     movie = new Movie();		
                     movie.setMovieId(st.nextToken());
                     movie.setTitle(st.nextToken());
                     movie.setGenres(st.nextToken());
                     listaMovie.add(movie);		
                 }
            }catch(Exception e){}				
       }
   }
   public void leerRating(){
       List<String> lineas;
       lineas = fd.leerArchivo("ratings.csv");
       listaRating = new ArrayList();
       StringTokenizer st = null;
       for (String linea : lineas){
           st = new StringTokenizer(linea, ";");
           try{
                if(st.hasMoreElements()){ 
                     rating = new Rating();
                     rating.setUserId(st.nextToken());
                     rating.setMovieId(st.nextToken());
                     rating.setRating(st.nextToken());
                     listaRating.add(rating);
                 }
           }catch(Exception e){} 
       }
   }

}
