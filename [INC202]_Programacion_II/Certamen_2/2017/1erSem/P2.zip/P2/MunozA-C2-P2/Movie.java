import java.util.List;

public class Movie {
    private String movieID;
    private String titulo;
    private List<String> generos;
    public Movie(){}
    
    public Movie(String movieID, String titulo, List<String> generos){
        this.movieID=movieID;
        this.titulo=titulo;
        this.generos=generos;
    }
    
    public void setMovieID(String movieID){
        this.movieID=movieID;
    }
    
    public String getMovieID(){
        return movieID;
    }
    
    public void setTitulo(String titulo){
        this.titulo=titulo;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public void setGeneros(List<String> generos){
        this.generos=generos;
    }
    
    public List<String> getGeneros(){
        return generos;
    }
}
