import java.util.List;

public class Rating {
    private String userID;
    private String movieID;
    private String rating;
    public Rating(){}
    
    public Rating(String userID, String movieID, String rating){
        this.userID=userID;
        this.movieID=movieID;
        this.rating=rating;
    }
    
    public void setUserID(String userID){
        this.userID=userID;
    }
    
    public String getUserID(){
        return userID;
    }
    
    public void setMovieID(String movieID){
        this.movieID=movieID;
    }
    
    public String getMovieID(){
        return movieID;
    }
    
    public void setRating(String rating){
        this.rating=rating;
    }
    
    public String getRating(){
        return rating;
    }
    
}
