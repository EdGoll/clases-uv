import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FuenteDeDatos {
    static FileWriter ficheroResultados = null;
    static PrintWriter printWriter = null;
    public FuenteDeDatos() throws IOException{
        
    ficheroResultados = new FileWriter("resultados.txt",true);
    printWriter = new PrintWriter(ficheroResultados,true);
    }
    
    public static List<String> getMovies(String nombreArchivo) {
        File file = null;
        FileReader fileReader = null;
        String linea = null;
        List<String> lineas = null;
        
        try {
            file = new File(nombreArchivo);
            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            lineas = new ArrayList<>();
            linea = bufferedReader.readLine();
            while ((linea = bufferedReader.readLine()) != null) {
                lineas.add(linea);
            }
        }
        catch (IOException ex) {
            System.out.println(ex.getCause());
        }
        finally {
            if (fileReader != null) {
                try {
                    fileReader.close();
                } catch(IOException ex) {
                    System.out.println(ex.getCause());
                }
            }
        }
        return lineas;
    }
    
    public static List<String> getRatings(String nombreArchivo) {
        File file = null;
        FileReader fileReader = null;
        String linea = null;
        List<String> lineas = null;
        
        try {
            file = new File(nombreArchivo);
            fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            lineas = new ArrayList<>();
            linea = bufferedReader.readLine();
            while ((linea = bufferedReader.readLine()) != null) {
                lineas.add(linea);
            }
        }
        catch (IOException ex) {
            System.out.println(ex.getCause());
        }
        finally {
            if (fileReader != null) {
                try {
                    fileReader.close();
                } catch(IOException ex) {
                    System.out.println(ex.getCause());
                }
            }
        }
        return lineas;
    }
    
    public static void printFile(String resultado){
        printWriter.println(resultado);
    }
    
    public static void fileFlush(){
        printWriter.flush();
    }
        
    public static void fileClose() throws IOException{
    ficheroResultados.close();
    }
    
    
}
