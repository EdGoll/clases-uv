import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Lista {
    private List<Movie> movies;
    private List<Rating> ratings;
    
    public Lista() throws IOException{ //error
        movies=new ArrayList<>();
        ratings=new ArrayList<>();
        FuenteDeDatos output = new FuenteDeDatos();
        cargar();
    }
    
    private void cargar(){
        List<String> lineas = FuenteDeDatos.getMovies("movies.txt");
        List<String> lineas2 = FuenteDeDatos.getRatings("ratings.txt");
        
        for(String l:lineas){
            Boolean control_largo = false;
            String temporal = "";
            List<String> lista_generos = new ArrayList<>();
            String datos_divididos[] = l.split(";");
            
            if(datos_divididos.length>3){
                for(int i = 1;i<datos_divididos.length-1;i++){
                    temporal=temporal.concat(datos_divididos[i]);
                    if(i+1<datos_divididos.length-1)
                        temporal=temporal+";";
                }
                datos_divididos[2] = datos_divididos[datos_divididos.length-1];
                control_largo = true;
                
            }
            String generos_divididos[] = datos_divididos[2].split("[|]");
            for(int i=0; i<generos_divididos.length;i++){
                lista_generos.add(generos_divididos[i]);
            }
            if(control_largo==false){
                Movie m = new Movie(datos_divididos[0],datos_divididos[1],lista_generos);
                movies.add(m);
            }
            else{
                Movie m = new Movie(datos_divididos[0],temporal,lista_generos);
                movies.add(m);
            }
            
        }
        
        for(String l:lineas2){
            String datos_divididos[] = l.split(";");
            Rating r = new Rating(datos_divididos[0],datos_divididos[1],datos_divididos[2]);
            ratings.add(r);
        }
    }
    
    public void listarAdventure(){
        for(Movie m:movies){
            if(m.getGeneros().contains("Adventure")){
                System.out.println(m.getTitulo());
                FuenteDeDatos.printFile(m.getTitulo());
            }
        }
    }
    
    public void listarThriller_Crime(){
        for(Movie m:movies){
            if(m.getGeneros().contains("Thriller") && m.getGeneros().contains("Crime")){
                System.out.println(m.getTitulo());
                FuenteDeDatos.printFile(m.getTitulo());
            }
        }
    }
    
    public void listarAnio(String anio){
        for(Movie m:movies){
            if(m.getTitulo().subSequence(m.getTitulo().length()-5, m.getTitulo().length()-1).toString().contains(anio)){
                System.out.println(m.getTitulo());
                FuenteDeDatos.printFile(m.getTitulo());
            }
        }   
    }
}