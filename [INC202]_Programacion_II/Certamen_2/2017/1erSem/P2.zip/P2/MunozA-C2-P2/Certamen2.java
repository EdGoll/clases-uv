import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Certamen2 {

    public static void main(String[] args) throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader (isr);
        Lista lista=new Lista();
        lista.listarAdventure();
        System.out.println("-----------");
        lista.listarThriller_Crime();
        System.out.println("-----------");
        System.out.println("Ingrese el año a consultar:");
        String cadena = br.readLine();
        lista.listarAnio(cadena);
        //lista.listarAnio("1995"); //Scanner
        System.out.println("-----------");
        FuenteDeDatos.fileFlush();
        FuenteDeDatos.fileClose();

    }
    
}
