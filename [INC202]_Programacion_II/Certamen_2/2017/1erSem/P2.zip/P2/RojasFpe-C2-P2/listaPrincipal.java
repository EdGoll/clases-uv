public class listaPrincipal {
    public static void main(String[] args) {
        lista a = new lista();
        
    }
}
