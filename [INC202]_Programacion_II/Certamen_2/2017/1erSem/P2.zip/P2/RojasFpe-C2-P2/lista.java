import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Scanner;
public class lista{
	private List<Movies> movies;
	private List<Ratings> ratings;
	private StringTokenizer st;
	private Movies b;
	private Ratings r;
	public lista(){
		
		movies=new ArrayList<>();
		ratings=new ArrayList<>();
		cargar();
		moviesAdventures();
	}

	public void cargar(){
		List <String> lineas = FuenteDeDatos.leerArchivo("movies.csv");
        List <String> lineas1 = FuenteDeDatos.leerArchivo("ratings.csv");

        
    	for (String l : lineas){
            st = new StringTokenizer(l, ";");
            if(st.hasMoreElements()){
            	b=new Movies();
            	b.setID(st.nextToken());
            	b.setTittle(st.nextToken());
				b.setGenres(st.nextToken());
				movies.add(b);
			}
    
		}
    
		for(String l1 : lineas1){
			st=new StringTokenizer(l1, ";");
			if(st.hasMoreElements()){
				r=new Ratings();
				r.setUserId(st.nextToken());
				r.setMovieId(st.nextToken());
				r.setRating(st.nextToken());
				rating.add(r);

			}
		}
    }

    public void moviesAdventures(){
    	List <String> x =new ArrayList<>();
    	for(Movies p: movies){
    		if(p.getGenres().contains("Adventures")){
    			x.add(getTittle());
    		}
    	}
    	FuenteDeDatos.escribirArchivo("ArchivoResultado.txt", x, false);
    }	


}

