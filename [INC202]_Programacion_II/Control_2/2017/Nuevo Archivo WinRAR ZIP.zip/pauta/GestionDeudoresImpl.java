
public class GestionDeudoresImpl {

	public static void main(String[] args) {
		GestionDeudores gd = new GestionDeudores();
		gd.getDeudores();
		gd.escribirDeudores();
		gd.getPersonaSinDeuda();
		gd.escribirPersonaSinDeuda();
	}
	
}
