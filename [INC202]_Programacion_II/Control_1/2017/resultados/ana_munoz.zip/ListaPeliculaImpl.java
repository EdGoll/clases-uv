/*Ana Muñoz Fuentes 19.817.247-2*/

import java.util.ArrayList;
import java.io.*;
import java.awt.*;

public class ListaPeliculaImpl{

	ArrayList<Pelicula> listaPelicula = new ArrayList<Pelicula>();
	ArrayList<Pelicula> arrGanancia = new ArrayList<Pelicula>();

	public void agregar() throws IOException {

		Pelicula pel = null;
		String respuesta;
		String nombre;
 		Integer duracion;
 		Integer taquilla;
 		Integer gananciaPel;
 		Integer promedio;

 		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

 		//System.out.println("ingresa hasta que escriba "salir" ");

 		/*do-while porque no está definido el tamaño del arreglo y se termina
 		su tamaño una vez que el usuario ingresa la palabra "salir"*/
 		do{
 			System.out.println("Desea ingresar pelicula? Responda 'Si', de lo contrario, 'Salir'");
 			respuesta = br.readLine();

 			if(respuesta.equals("Si")){
 				System.out.println("Ingrese nombre de la película: ");
 				nombre = br.readLine();
 				System.out.println("Ingrese su duración: ");
 				duracion = Integer.valueOf(br.readLine());
 				System.out.println("Ingrese taquilla: ");
 				taquilla = Integer.valueOf(br.readLine());

 				pel = new Pelicula(nombre,duracion,taquilla);

 				listaPelicula.add(pel);
 			}
 		}
 		while(!respuesta.equals("Salir"));

	}

	public void mostrar() {
		Pelicula lista = null;

		/*obtiene los datos ingresados en el metodo anterior y los muestra
		usando la clase Pelicula*/
		for(int i = 0; i<listaPelicula.size();i++){
			lista = listaPelicula.get(i);
			System.out.println(lista.getNombre());
			System.out.println(lista.getDuracion());
			System.out.println(lista.getTaquilla());
		}
	}

	public void reporteGanancia()  {

		//sumar todas las ganancias x pelicula y dividirlas por el total
		
		/*gananciaPel = gananciaPel.getTaquilla();
		arrGanancia.add(gananciaPel);*/

		/**********faltó: ingresar a cada taquilla para sumarla y dividirla por 
		arrGanancia.size()*/



	}

	public void buscarTiempoMayor()  {

	}
}