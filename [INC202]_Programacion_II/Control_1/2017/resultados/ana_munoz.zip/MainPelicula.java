/*Ana Muñoz Fuentes 19.817.247-2*/
import java.io.*;

public class MainPelicula {

	public static void main(String[] args) throws IOException {

		ListaPeliculaImpl ingreso = new ListaPeliculaImpl();

			ingreso.agregar();
			ingreso.mostrar();
			ingreso.reporteGanancia();
			ingreso.buscarTiempoMayor();
	}
}