import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ListaPeliculaImpl{

	ArrayList<Pelicula> listaPelicula = new ArryList<Peicula>();

	public static void main(String[] args) throws IOException {
		ListaPeliculaImpl crear = new ListaPeliculaImpl()
		crear.agregar();
		crear.mostrar();
		crear.repoteGanancia();
		crear.buscarTiempoMayor();
	}
	
	public void agregar() throws IOException{
		Pelicula pl = null;
		String nombre;
		Integer duracion;
		Integer taquilla;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		for(int i=0;i<2;i++){
			System.out.println("Ingresa el nombre de la pelicula");
			nombre = br.ReadLine();
			System.out.println("Ingresa los minutos de duracion de la pelicula");
			duracion = Integer.valueOf(br.readLine());
			System.out.println("Ingresa las ganacias");
			taquilla = Integer.valueOf(br.readLine());

			pl = new Pelicula(nombre,duracion,taquilla);
			listaPelicula.add(pl);	
		}
	}
	
	public void mostrar() {
		Pelicula plc = null;
		for(int i=0;i<2;i++) {
			plc=listaPelicula.get(i);
			System.out.println(plc.getNombre());
			System.out.println(plc.getDuracion());
			System.out.println(plc.getTaquilla());
		}	
	}

	






}
