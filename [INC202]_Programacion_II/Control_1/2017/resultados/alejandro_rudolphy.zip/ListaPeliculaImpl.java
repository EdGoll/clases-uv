// Alejandro Rudolphy Fernandez //
// 19.490.110-0 //

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ListaPeliculaImpl{
 
        ArrayList<Pelicula> arrPelicula = new ArrayList<Pelicula>();

        public static void main(String[] args) throws IOException{
                ListaPeliculaImpl crear = new ListaPeliculaImpl();
                crear.agregar();
                crear.mostrar();
                crear.reporteGanancia();
                crear.buscarTiempoMayor();
        }

	public void agregar() throws IOException{
                Pelicula p = null;
                String nombre;
                Integer duracion;       
                Integer taquilla;
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.println("ingrese los datos de la pelicula que desea agregar: ");
                System.out.println("ingrese la palabra Fin para finalizar el programa");
                do{
                   	System.out.println("ingrese nombre de la pelicula: ");
                        nombre = br.readLine();
                        System.out.println("ingrese duracion de la pelicula en minutos: ");
                        duracion = Integer.valueOf(br.readLine());
                        System.out.println("ingrese taquilla de la pelicula: ");
                        taquilla = Integer.valueOf(br.readLine());
                        p = new Pelicula(nombre, duracion, taquilla);
			                        arrPelicula.add(p);
                }while(!nombre.equals("Fin"));
                System.out.println("Fin del programa");
        }
	public void mostrar(){
                Pelicula per = null;
                for(int i = 0; i < arrPelicula.size(); i++){
                        per = arrPelicula.get(i);
                        System.out.println("Su pelicula es "+per.getNombre()+" dura "+per.getDuracion()+" y cuesta "+per.getTaquilla());
                }
        }
	public void reporteGanancia(){

       	}
	public void buscarTiempoMayor(){

       	}
}


