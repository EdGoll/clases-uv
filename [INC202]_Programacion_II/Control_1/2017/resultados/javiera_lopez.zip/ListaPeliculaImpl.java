//Javiera Lopez Malbran
//19773465-5

import java.io.IOException;     //LIBRERIAS
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ArrayList;

public static class ListaPeliculaImpl{

	ArrayList<Pelicula> arregloListaPeliculas = new ArrayList<Pelicula();

	private ListaPeliculaImpl[] =  new Pelicula [10];

	public static void main ( String[] args ) throws IOException{
		ListaPeliculaImpl Pelicula = new ListaPeliculaImpl();
		Pelicula.agregar();
		Pelicula.mostrar();

	}

	public void agregar() throws IOException {
		ListaPeliculaImpl p = null ;
		String nombre ;
		Integer duracion ;
		Integer taquilla ;
		int x = 0 ;

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); //INGRESAR PELICULAS

		do{
			for ( int i = 0; i<10 ; i++){
			System.out.println(" REGISTRO DE PELICULAS :");
			System.out.println(" ");
			System.out.print("Ingrese Nombre de pelicula : ");
			nombre = br.readLine();
			System.out.print("Ingrese Duracion: ");
			duracion = Integer.valueOf(br.readLine());
			System.out.print("Ingrese Taquilla: ");
			taquilla = Integer.valueOf(br.readLine());
			p = new ListaPeliculas (nombre, duracion , taquilla);
			arregloListaPeliculas[i] = p ;
			}

		}while(x==1);
		System.ouy.println("Desea Ingresar una pelicula SI = 1  NO = 2 :");
		x = Integer.valueOf(br.readLine());

	
	}

	public void mostrar(){
		ListaPeliculaImpl p = null ;

		System.out.println( '\n' + "PELICULAS INGRESADAS :" + '\n');
		/System.out.println("");

		for(int i = 0; i < 10; i++){
			arregloListaPeliculas p = arreglo[i];
			System.out.println("Nombre:" +p.getNombre());
			System.out.println("Duracion:" +p.getDuracion());
			System.out.println("Taquilla:" +p.getTaquilla());
			
		}


	}

	public void buscarTiempoMayor{

	}

	public void reporteGanancia{
		
	}

}

























