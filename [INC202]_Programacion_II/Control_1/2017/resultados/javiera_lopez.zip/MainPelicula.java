//Javiera Lopez Mlabran 
//19773465-5

public class MainPelicula{ //Se crea la clase MainPelicula

	private String nombre;    //Define sus atributos
	private Integer duracion; //int se transforma a Integer
	private Integer taquilla;
	
}

public MainPelicula (String nombre , Integer duracion , Integer taquilla){
	
	this.nombre = nombre;   //Se llama a tales variables para guardarlas
	this.duracion = duracion;
	this.taquilla = taquilla;
}

public String getNombre(){
	return nombre;   
}
public void setNombre(String nombre){	
	this.nombre = nombre;
}
public Integer getDuracion(){	
	return duracion;
}
public void setDuracion(Integer duracion){	
	this.duracion = duracion;
}
public Integer gettaquilla(){	
	return taquilla;
}
public void setTaquilla(Integer taquilla){	
	this.taquilla = taquilla;
}
