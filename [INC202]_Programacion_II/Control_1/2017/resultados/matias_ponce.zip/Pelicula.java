//Matias Ponce R.
//19.590.013-2

public class Pelicula{
	private String nombre;
	private Integer taquilla;
	private Integer duracion;
	
	public Pelicula(String nombre, Integer taquilla, Integer duracion){
		this.nombre=nombre;
		this.taquilla=taquilla;
		this.duracion=duracion;
	}
	
	public String getNombre(){
		return nombre;
	}
	public void setNombre(String nombre){
		this.nombre = nombre;
	}
	public Integer getTaquilla(){
		return taquilla;
	}
	public void setTaquilla(Integer taquilla){
		this.taquilla = taquilla;
	}
	public Integer getDuracion(){
		return duracion;
	}
	public void setDuracion(Integer duracion){
		this.duracion = duracion;
	}
}
