//Matias Ponce R.
//19.590.013-2

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ListaPeliculaImpl{

	ArrayList<Pelicula> arrPelicula = new ArrayList<Pelicula>();	
	
	public static void main(String[] args) throws IOException{
		ListaPeliculaImpl crear = new ListaPeliculaImpl();
		crear.llenar();
		crear.mostrar();
	} 	

	public void llenar() throws IOException{
		Pelicula p = null;
		String nombre;
		Integer duracion;
		Integer taquilla;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
		System.out.println("Ingrese la cantidad de peliculas: ");
		Integer CantPeli = Integer.valueOf(br.readLine());
	
		
		for(int i = 0; i < CantPeli; i++){
			System.out.println("Ingrese nombre de la pelicula: ");
			nombre = br.readLine();
			System.out.println("Ingrese valor: ");
			taquilla = Integer.valueOf(br.readLine());
			System.out.println("Ingrese duracion (en minutos): ");
			duracion = Integer.valueOf(br.readLine());
			p = new Pelicula(nombre, taquilla, duracion);
			arrPelicula.add(p);
		}
	}	
	public void mostrar(){
		
		Pelicula per = null;
	
		for(int i = 0; i < arrPelicula.size(); i++){	
			
			per = arrPelicula.get(i);
			System.out.println("Pelicula: "+per.getNombre()+" Su duracion es: "+per.getDuracion()+" Su valor es: "+per.getTaquilla());			
			
		}

	}
}
