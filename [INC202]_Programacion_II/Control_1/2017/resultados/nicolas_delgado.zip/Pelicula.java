


public class Pelicula{
	private String nombre;
	private Integer duracion;
	private Integer taquilla;
