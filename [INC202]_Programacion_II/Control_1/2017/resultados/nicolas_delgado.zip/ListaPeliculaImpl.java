//Nicolas Delgado Oyarce 19.329.196-1


public class Pelicula{

	private String nombre;
	private Integer duracion;
	private Integer taquilla;
	
	public void agregar(){
		
		
		int ganancia = 0;

		for(int i = 0; i < arregloPelicula.length; i++){
			System.out.println("ingrese nombre: ");
			nombre = br.readLine();

			System.out.println("ingrese duracion: ");
			duracion = Integer.valueOf(br.readLine());

			System.out.println("ingrese taquilla: ");
			taquilla = Integer.valueOf(br.readLine());
			
			ganancia = ganancia + taquilla;
			
			p = new Pelicula(nombre, duracion, taquilla);
			arregloPelicula[i] = p;
	}
	
	public void mostrar(){
		for(int i = 0; i < arregloPelicula.length; i++){

			System.out.println("La pelicula es: "+peli.getNombre());		
			System.out.println("La duracion es: "+peli.getDuracion());	
			System.out.println("La taquilla es: "+peli.getTaquilla());
		}
	}
	public void reporteGanancia(){
		reportganan = ganancia / arregloPelicula.length;
		System.out.println("La ganancia media de las peliculas ingresadas es: " reportganan);
	}
	public void buscarTiempoMayor(){
	
	}
}
