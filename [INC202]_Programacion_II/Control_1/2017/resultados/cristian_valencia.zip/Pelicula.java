//Cristian Valencia 19.760.909-5
public class Pelicula{
	public String nombre;
	public Integer duracion;
	public Integer taquilla;

	public Pelicula(String nombre, Integer duracion, Integer taquilla){
		this.nombre=nombre;
		this.duracion=duracion;
		this.taquilla=taquilla;
	}
	public String getNombre(){
		return nombre;
	}
	public void setNombre(String nombre){
		this.nombre = nombre;
	}
	/*public Integer getDuracion(){
		return duracion;
	}
	public void setDuracion(Integer duracion){
		this.duracion = duracion;
	}
	public Integer getTaquilla(){
		return taquilla;
	}
	public void Integer setTaquilla(Integer taquilla){
		this.taquilla = taquilla;
	}*/
}

