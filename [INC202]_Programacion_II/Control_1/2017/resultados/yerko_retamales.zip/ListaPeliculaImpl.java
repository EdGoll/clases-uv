import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public 	class ListaPeliculaImpl{

	Integer duracion,taquilla;
	String nombre;

	ArrayList<Pelicula> listaPelicula = new ArrayList<Pelicula>();


	public static void main(String[] args)throws IOException{
		ListaPeliculaImpl list=new ListaPeliculaImpl();
		list.agregar();
		list.mostrar();	
	}

	public void agregar()throws IOException{
		Pelicula p=null;
		String nombre;
		Integer duracion,taquilla;
		String resp=null;//respuesta a continuar
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do {
     		System.out.println("Ingrese Nombre:");
			nombre = br.readLine();
			System.out.println("Ingrese duracion:");
			duracion = Integer.valueOf(br.readLine());	
			System.out.println("Ingrese taquilla:");
			taquilla = Integer.valueOf(br.readLine());		
			p=new Pelicula(nombre,duracion,taquilla);
			listaPelicula.add(p);
			System.out.println("¿Desea Continuar? s/n");
			resp = br.readLine();
		} while (resp == "s");
	}
	
	public void mostrar()throws IOException{
		Pelicula pel=null;
		for(int i=0;i<listaPelicula.size();i++){
			
			System.out.println("Pelicula:"+(i+1));
			System.out.println("Nombre: "+pel.getNombre());
			System.out.println("Duracion:"+pel.getDuracion());
			System.out.println("Taquilla:"+pel.getTaquilla());
		}
	}

	public void reporteGanancia()throws IOException{
		float sum=0;
		float prom=0;
		for(int i=1;i<listaPelicula.size();i++){
			
		}
	}

}