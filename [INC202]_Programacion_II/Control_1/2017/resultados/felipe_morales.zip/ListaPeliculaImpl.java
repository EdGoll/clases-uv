//Felipe Morales 18.585.131-1 
import java.util.*;
import java.io.*;

public class ListaPeliculaImpl{
	private ArrayList<Pelicula> listaPelicula = new ArrayLista<Pelicula>();
	private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	private String nombre;
	private Integer duracion;
	private Integer taquilla;
	private Pelicula pelicula;
	private String pregunta;
	
	public void agregar() throws IOException {
		System.out.println("Ingrese los datos de la Pelicula :");
		do{
		System.out.print("Nombre : ");
		nombre = br.readLine();
		System.out.print("Duracion : ");
		duracion = Integer.valueOf(br.readLine());
		System.out.print("Taquilla : ");
		taquilla = Integer.valueOf(br.readLine());

		pelicula(nombre, duracion, taquilla);
		listaPelicula.add(pelicula);

		System.out.println("Desea agregar una pelicula a la lista?, Si/No : ");
		pregunta = br.readLine();

		}while(!pregunta.equals("No"));
	}

	public void mostrar(){
		Pelicula p = null;
		System.out.println('\n' + "Lista de Peliculas Actualizada : ");
		for(int i = 0; i < listaPelicula.size(); i++){
			p = listaPelicula.get(i);
			System.out.println("El nombre de la pelicula en el espacio " + (i+1) + " es : " + p.getNombre());
			System.out.println("La duracion de la pelicula en el espacio " + (i+1) + " es : " + p.getDuracion());
			System.out.println("La taquilla de la pelicula en el espacio " + (i+1) + " es : " + p.getTaquilla());
		}
	}

	public void reporteGanancia(){
		Pelicula p = null;
		Integer ganancia = 0;
		for(int i = 0; i < listaPelicula.size(); i++){
			p = listaPelicula.get(i);
			ganancia = ganancia + p.getTaquilla();
		}
		System.out.println("La ganancia del cine es : " +  ganancia);
	}

	public void buscarTiempoMayor(){
		Pelicula p = null;
		Integer tiempoMayor;


	}
}