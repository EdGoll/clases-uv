//Felipe Morales 18.585.131-1 
import java.util.*;
import java.io.*;

public class Pelicula{
	private String nombre;
	private Integer duracion;
	private Integer taquilla;

	public Pelicula(){
		this.nombre = nombre;
		this.duracion = duracion;
		this.taquilla = taquilla;
	}

	public void setNombre(String nombre){
		this.nombre = nombre;
	}
	public String getNombre(){
		return nombre;
	}

	public void setDuracion(Integer duracion){
		this.duracion = duracion;
	}
	public Integer getDuracion(){
		return duracion;
	}

	public void setTaquilla(Integer taquilla){
		this.taquilla = taquilla;
	}
	public Integer getTaquilla(){
		return taquilla;
	}
}