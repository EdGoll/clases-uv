//Felipe Morales 18.585.131-1 
import java.util.*;
import java.io.*;

public class MainPelicula {
	
	public static void main(String[] args) throws IOException {
		ListaPeliculaImpl lp = new ListaPeliculaImpl();
		BufferedReader br = new BufferedReader();
		System.out.println("Bienvenido al gestionador de peliculas : ");
		String pregunta2;
		do{
			lp.agregar();
			lp.mostrar();
			lp.reporteGanancia();
			System.out.println("Desea agregar otra pelicula? : Si/No");
			pregunta2 = br.readLine();
		}while(!pregunta2.equals("No"));

	}
}