package gestionbodegaimpl;

public class Producto {
    //Atributos
   int codigo;
   String nombre;
   int stock;
   double precio;
   
   //Metodos
   
   public Producto(int codigo, String nombre, int stock, double precio){
       this.codigo = codigo;
       this.nombre = nombre;
       this.stock = stock;
       this.precio = precio;
   }
   
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }   
}

