
public class Alumno {
    int alumnoId;
    public Alumno(int /* Arreglo del grupo A o B */){
        AlumnoId = arreglo[/*posicion que se quiere revisar*/];
    }
    public int mostrarInfo(){
            System.out.println("La id del alumno es " + alumnnoId);  
    }
    public int comparacionAlumnos(){
        System.out.println("La id del Alumno de la posicion " + i + "es " + arreglo[i]);
        System.out.pritnln("La id del Alumno de la posicion " + (i+1) + "es" + arreglo[i]);
    }
}
