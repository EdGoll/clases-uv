
import java.util.Random;

public class Lista {
    int desde;
    int numeroDeAlumnos; //Sera el limite
    int[] arreglo;
    public Lista(int d, int numAleatorio) {
        desde = d;
        numeroDeAlumnos = numAleatorio;
    }
    public static int[] llenar(int desde, int numeroDeAlumnos) {
            Random r = new Random();
            int[] arreglo = new int[numeroDeAlumnos];
            int n;
            for(int i = 0; i < arreglo.length;i++){
                do {
                    n = r.nextInt(100 - desde + 1) + desde;
                } while (comprobarSiContiene(arreglo, i, n));
                arreglo[i] = n;
            }
            return arreglo;
        }
    public static boolean comprobarSiContiene(int[] arreglo,int numeroDeAlumnos,int n) {
        for(int i = 0; i < numeroDeAlumnos; i++) {
            if(arreglo[i] != n) {
                return true;
            }
        }
        return false;
    }
    public void mostrar(){
            System.out.println("La lista contiene " + arreglo + " Alumnos");
        }
    }     

    

