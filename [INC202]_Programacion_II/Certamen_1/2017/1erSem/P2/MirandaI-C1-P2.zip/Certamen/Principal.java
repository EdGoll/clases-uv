public class Principal {
    public static void main(String[] args) {
        int numAleatorio = (int)(Math.random()*75+41); //numero de alumnos en total
        int r1 = (int)(Math.random()*numAleatorio+1);
        int r2 = numAleatorio - r1;
        Lista A = new Lista(1, r1);
        Lista B = new Lista(r1, r2);
        //Alumno 1 = new Alumno(arreglo[i]);
        A.mostrar();
        B.mostrar();
    }    
}
